package com.tm.jsonwebtoken.service.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessResourceUsageException;
import org.springframework.stereotype.Service;

import com.tm.jsonwebtoken.entity.ApplicationDetails;
import com.tm.jsonwebtoken.entity.TokenDetails;
import com.tm.jsonwebtoken.entity.TransacTokenDetails;
import com.tm.jsonwebtoken.exception.CustomJwtException;
import com.tm.jsonwebtoken.pojo.TokenGenerationPOJO;
import com.tm.jsonwebtoken.repository.ApplicationDetailsRepository;
import com.tm.jsonwebtoken.repository.TokenDetailsRepository;
import com.tm.jsonwebtoken.repository.TransacTokenDetailsRepository;
import com.tm.jsonwebtoken.request.ApplicationDetailsRequest;
import com.tm.jsonwebtoken.request.RefreshTokenRequest;
import com.tm.jsonwebtoken.request.TokenGenerationRequest;
import com.tm.jsonwebtoken.request.TokenValidationRequest;
import com.tm.jsonwebtoken.service.JwtService;
import com.tm.jsonwebtoken.util.JwtUtil;

/**
 * This class provides the implementation of the JwtService interface. It
 * contains methods to handle JSON web token operations and saving token details
 * in database. This class interacts with JwtUtil to generate and validate
 * tokens.
 */
@Service
public class JwtServiceImpl implements JwtService {

	@Autowired
	private TokenDetailsRepository tokenDetailsRepository;

	@Autowired
	private TransacTokenDetailsRepository transacTokenDetailsRepository;

	@Autowired
	private ApplicationDetailsRepository applicationDetailsRepository;

	@Autowired
	private JwtUtil jwtUtil;

	Logger logger = LoggerFactory.getLogger(JwtServiceImpl.class);

	/**
	 * This method is used to save application details in database
	 * 
	 * @param applicationDetailsRequest
	 * @return boolean
	 */
	@Override
	public boolean saveApplicationDetails(ApplicationDetailsRequest applicationDetailsRequest) {
		logger.info("Received the request to save the application details");
		boolean isSaved = false;
		try {
			logger.info("Application details saving process started!..");
			ApplicationDetails applicationDetails = new ApplicationDetails();
			applicationDetails.setApplicationName(applicationDetailsRequest.getApplicationName());
			applicationDetails.setSecretKey(applicationDetailsRequest.getSecretKey());
			applicationDetails.setCreatedAt(new Date());
			applicationDetails.setUpdatedAt(new Date());
			ApplicationDetails applicationDetailsResponse = applicationDetailsRepository.save(applicationDetails);
		    isSaved = applicationDetailsResponse.getApplicationId() > 0;
			logger.info("Return the application details saved response as boolean");
		} catch (Exception exception) {
			logger.error("An Error occur while application details saved request", exception);
		}
		return isSaved;
	}

	/**
	 * This method is used to get the access and refresh token from JWT utility
	 * class method and pass the access token and refresh token in database storing
	 * process
	 * 
	 * @param tokenGenerationRequest
	 * @return TokenGenerationPOJO
	 */
	@Override
	public TokenGenerationPOJO generateToken(TokenGenerationRequest tokenGenerationRequest) throws CustomJwtException {
		logger.info("Received request to get the access token and refresh token");
		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		try {
			logger.info("Get the access and refresh token from util class");
			String accessToken = jwtUtil.generateAccessToken(tokenGenerationRequest);
			String refreshToken = jwtUtil.generateRefreshToken(tokenGenerationRequest);
			String uniqueId = tokenGenerationRequest.getUniqueId();
			saveTokenDetails(uniqueId, accessToken, refreshToken);
			saveTransactionTokenDetails(uniqueId, accessToken, refreshToken);
			logger.info("Display the access and refresh token in response");
			tokenGenerationPOJO.setUniqueId(uniqueId);
			tokenGenerationPOJO.setAccessToken(accessToken);
			tokenGenerationPOJO.setRefreshToken(refreshToken);
			return tokenGenerationPOJO;
		} catch (Exception exception) {
			logger.error("Unable to get the token details!...", exception);
			throw new CustomJwtException("Unable to get the token details!..");
		}

	}

	/**
	 * This method is used to save or update the token details with created date and
	 * updated date in database
	 * 
	 * @param uniqueId
	 * @param accessToken
	 * @param refreshToken
	 * @return boolean
	 */
	public boolean saveTokenDetails(String uniqueId, String accessToken, String refreshToken) {
		logger.info("Received the request to save/update the token details");
		try {
			logger.info("Find the token details based on unique id");
			TokenDetails existingTokenDetails = tokenDetailsRepository.findByUniqueId(uniqueId);
			if (existingTokenDetails != null) {
				logger.info("Checking the unique id details is available or not");
				existingTokenDetails.setAccessToken(accessToken);
				existingTokenDetails.setRefreshToken(refreshToken);
				existingTokenDetails.setUpdatedAt(new Date());
				logger.info("Token details updated based on unique id in the database");
				tokenDetailsRepository.save(existingTokenDetails);
				return true;
			} else {
				logger.info("Received the request to save the new token details");
				TokenDetails newTokenDetails = new TokenDetails();
				newTokenDetails.setUniqueId(uniqueId);
				newTokenDetails.setAccessToken(accessToken);
				newTokenDetails.setRefreshToken(refreshToken);
				newTokenDetails.setCreatedAt(new Date());
				newTokenDetails.setUpdatedAt(new Date());
				logger.info("New token details saved in the database");
				tokenDetailsRepository.save(newTokenDetails);
				return true;
			}
		} catch (InvalidDataAccessResourceUsageException exception) {
			logger.error("Token details table is not exist", exception);
			return false;
		}
	}

	/**
	 * This method is used to save the transaction token details in database
	 * 
	 * @param uniqueId
	 * @param accessToken
	 * @param refreshToken
	 * @return boolean
	 */
	public boolean saveTransactionTokenDetails(String uniqueId, String accessToken, String refreshToken) {
		logger.info("Received the request to save the transaction token details");
		try {
			logger.info("Set the transac token details");
			TransacTokenDetails saveTransacTokenDetails = new TransacTokenDetails();
			saveTransacTokenDetails.setUniqueId(uniqueId);
			saveTransacTokenDetails.setAccessToken(accessToken);
			saveTransacTokenDetails.setRefreshToken(refreshToken);
			saveTransacTokenDetails.setCreatedAt(new Date());
			saveTransacTokenDetails.setUpdatedAt(new Date());
			logger.info("Transaction token details are saved in database");
			transacTokenDetailsRepository.save(saveTransacTokenDetails);
			return true;
		} catch (InvalidDataAccessResourceUsageException exception) {
			logger.error("Transaction token details table is not exist", exception);
			return false;
		}
	}

	/**
	 * This method is used to validate the user and access token is expire or not
	 * 
	 * @param tokenValidationRequest
	 * @return boolean
	 */
	@Override
	public boolean validateToken(TokenValidationRequest tokenValidationRequest) {
		logger.info("Received the request to validate the access token");
		boolean isTokenValid = false;
		try {
			logger.info("Check the accesstoken is expired or not");
			isTokenValid = jwtUtil.isTokenExpired(tokenValidationRequest.getSecretKey(),tokenValidationRequest.getAccessToken());
		} catch (Exception exception) {
			logger.error("An error occur while validate the token");
		}
		return isTokenValid;
	}

	/**
	 * This method is used to valid the user and refresh token and if token is valid
	 * regenerate the tokens
	 * 
	 * @param refreshTokenRequest
	 * @return TokenGenerationPOJO
	 */
	@Override
	public TokenGenerationPOJO regenerateTokens(RefreshTokenRequest refreshTokenRequest) {
		logger.info("Received the request to validate the access and refresh token");
		TokenGenerationPOJO refreshTokenResponse = new TokenGenerationPOJO();
		try {
			logger.info("Check the access token is expired or not");
			boolean isRefreshTokenValid = jwtUtil.isTokenExpired(refreshTokenRequest.getSecretKey(),
					 refreshTokenRequest.getRefreshToken());
			if (isRefreshTokenValid) {
				logger.info("Token is not expired, So regenrate tokens and return in response");
				TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
				tokenGenerationRequest.setUniqueId(refreshTokenRequest.getUniqueId());
				tokenGenerationRequest.setSecretKey(refreshTokenRequest.getSecretKey());
				tokenGenerationRequest.setAccessTokenTime(refreshTokenRequest.getAccessTokenTime());
				tokenGenerationRequest.setRefreshTokenTime(refreshTokenRequest.getRefreshTokenTime());

				TokenGenerationPOJO generateToken = generateToken(tokenGenerationRequest);
				refreshTokenResponse.setUniqueId(refreshTokenRequest.getUniqueId());
				refreshTokenResponse.setAccessToken(generateToken.getAccessToken());
				refreshTokenResponse.setRefreshToken(generateToken.getRefreshToken());
			} else {
				logger.error("Invalid user and refresh Token");
			}
		} catch (Exception exception) {
			logger.error("An error occur while refresh the token", exception);
			throw new CustomJwtException("An error occur while refresh the token");
		}
		return refreshTokenResponse;
	}

	/**
	 * This method is used to check the application name and secret key is exist
	 * 
	 * @param applicationName
	 * @param secreteKey
	 * @return boolean
	 */
	public boolean checkApplicationNameAndKeyExist(String applicationName, String secreteKey) {
		logger.info("Received the request to check the name and secret key is match");
		boolean isNameAndKeyExist = false;
		try {
			logger.info("Checking Application name and secret key has match in database");
			isNameAndKeyExist = applicationDetailsRepository.existsByApplicationNameAndSecretKey(applicationName,
					secreteKey);
		} catch (Exception exception) {
			logger.error("An error occur while validating name and key", exception);
		}
		logger.info("Return the response as boolean");
		return isNameAndKeyExist;
	}

}
