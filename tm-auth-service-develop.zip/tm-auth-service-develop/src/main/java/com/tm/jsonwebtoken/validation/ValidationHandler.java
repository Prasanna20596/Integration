package com.tm.jsonwebtoken.validation;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.tm.jsonwebtoken.response.JwtResponsePOJO;

/**
 * Global exception handler for handling validation exceptions in the JSON web token
 * application. This class uses Spring's `@RestControllerAdvice` to provide
 * centralized exception handling for MethodArgumentNotValidException
 * (validation errors).
 * 
 */
@RestControllerAdvice
public class ValidationHandler {

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public JwtResponsePOJO handleValidationExceptions(MethodArgumentNotValidException ex) {
        JwtResponsePOJO jwtResponsePOJO=new JwtResponsePOJO();
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach(error -> {
			String fieldName = ((FieldError) error).getField();
			String message = error.getDefaultMessage();
			errors.put(fieldName, message);
		});

		jwtResponsePOJO.setMessage("Not a valid request");
		jwtResponsePOJO.setResponseData(errors);
		jwtResponsePOJO.setIsSuccess(false);
		
		return jwtResponsePOJO;
	}

}