package com.tm.jsonwebtoken.request;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class RefreshTokenRequest {

	@Size(max = 50, message = "Unique id maximum characters: 50")
	@NotBlank(message =  "Unique id cannot be blank")
	private String uniqueId;

	@Size(max = 50, message = "Application name maximum characters: 50")
	@NotBlank(message = "Application name cannot be blank")
	private String applicationName;

	@Size(max = 25, message = "Secret key maximum characters: 25")
	@NotBlank(message = "Secret key cannot be blank")
	private String secretKey;

	@Size(max = 750, message = "Access token maximum characters: 750")
	@NotBlank(message = "Access token cannot be blank")
	private String accessToken;

	@Size(max = 750, message = "Refresh token maximum characters: 750")
	@NotBlank(message = "Refresh token cannot be blank")
	private String refreshToken;

	@Min(value = 300000, message = "Access token time must be greater than or equal to 5 min")
	private int accessTokenTime;

	@Min(value = 300000, message = "Refresh token time must be greater than or equal to 5 min")
	private int refreshTokenTime;

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId.trim();
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName.trim();
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey.trim();
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken.trim();
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken.trim();
	}

	public int getAccessTokenTime() {
		return accessTokenTime;
	}

	public void setAccessTokenTime(int accessTokenTime) {
		this.accessTokenTime = accessTokenTime;
	}

	public int getRefreshTokenTime() {
		return refreshTokenTime;
	}

	public void setRefreshTokenTime(int refreshTokenTime) {
		this.refreshTokenTime = refreshTokenTime;
	}

}
