package com.tm.jsonwebtoken.service;

import com.tm.jsonwebtoken.pojo.TokenGenerationPOJO;
import com.tm.jsonwebtoken.request.ApplicationDetailsRequest;
import com.tm.jsonwebtoken.request.RefreshTokenRequest;
import com.tm.jsonwebtoken.request.TokenGenerationRequest;
import com.tm.jsonwebtoken.request.TokenValidationRequest;

/**
 * This interface defines the method to generate the token's and validate the
 * token is expire or not
 * 
 */
public interface JwtService {

	/**
	 * This method is used to save the application details in database
	 * 
	 * @param applicationDetailsRequest
	 * @return boolean
	 */
	public boolean saveApplicationDetails(ApplicationDetailsRequest applicationDetailsRequest);

	/**
	 * This method is used to check the application name and secret key is exist
	 * 
	 * @param tokenGenerationRequest
	 * @return boolean
	 */
	public boolean checkApplicationNameAndKeyExist(String applicationName,String secreteKey);

	/**
	 * This method is used to get the access and refresh token from JWT utility
	 * class method and pass the access token and refresh token in database storing
	 * process
	 * 
	 * @param tokenGenerationRequest
	 * @return TokenGenerationPOJO
	 */
	public TokenGenerationPOJO generateToken(TokenGenerationRequest tokenGenerationRequest);

	/**
	 * This method is used to validate the user and access token is expire or not
	 * 
	 * @param tokenValidationRequest
	 * @return boolean
	 */
	public boolean validateToken(TokenValidationRequest tokenValidationRequest);

	/**
	 * This method is used to valid the user and refresh token and if token is valid
	 * regenerate the tokens
	 * 
	 * @param refreshTokenRequest
	 * @return TokenGenerationPOJO
	 */
	public TokenGenerationPOJO regenerateTokens(RefreshTokenRequest refreshTokenRequest);

}
