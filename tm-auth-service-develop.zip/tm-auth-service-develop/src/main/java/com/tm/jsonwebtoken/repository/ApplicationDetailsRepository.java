package com.tm.jsonwebtoken.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tm.jsonwebtoken.entity.ApplicationDetails;

public interface ApplicationDetailsRepository extends JpaRepository<ApplicationDetails, Integer>{

	public boolean existsByApplicationNameAndSecretKey(String applicationName, String secretKey);
}
