package com.tm.jsonwebtoken.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class TokenValidationRequest {

	@Size(max = 50, message = "Application name maximum characters: 50")
	@NotBlank(message = "Application name cannot be blank")
	private String applicationName;
	
	@Size(max = 25, message = "Secret key maximum characters: 25")
	@NotBlank(message = "Secret key cannot be blank")
	private String secretKey;

	@Size(max = 750, message = "Access token maximum characters: 750")
	@NotBlank(message = "Access token cannot be blank")
	private String accessToken;

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName.trim();
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey.trim();
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken.trim();
	}

}
