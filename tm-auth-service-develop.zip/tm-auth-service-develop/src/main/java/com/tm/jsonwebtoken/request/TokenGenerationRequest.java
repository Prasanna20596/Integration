package com.tm.jsonwebtoken.request;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class TokenGenerationRequest {

	@Size(max = 50, message = "Unique ID maximum characters: 50")
	@NotBlank(message = "Unique id cannot be blank")
	private String uniqueId;

	@Size(max = 50, message = "Application name maximum characters: 50")
	@NotBlank(message = "Application name cannot be blank")
	private String applicationName;
	
	@Size(max = 25, message = "Secret key maximum characters: 25")
	@NotBlank(message = "Secret key cannot be blank")
	private String secretKey;

	@Min(value = 300000, message = "Access token time must be greater than or equal to 5 min")
	private int accessTokenTime;

	@Min(value = 300000, message = "Refresh token time must be greater than or equal to 5 min")
	private int refreshTokenTime;

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId.trim();
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName.trim();
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey.trim();
	}

	public int getAccessTokenTime() {
		return accessTokenTime;
	}

	public void setAccessTokenTime(int accessTokenTime) {
		this.accessTokenTime = accessTokenTime;
	}

	public int getRefreshTokenTime() {
		return refreshTokenTime;
	}

	public void setRefreshTokenTime(int refreshTokenTime) {
		this.refreshTokenTime = refreshTokenTime;
	}

}
