package com.tm.jsonwebtoken.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.tm.jsonwebtoken.pojo.TokenGenerationPOJO;
import com.tm.jsonwebtoken.request.ApplicationDetailsRequest;
import com.tm.jsonwebtoken.request.RefreshTokenRequest;
import com.tm.jsonwebtoken.request.TokenGenerationRequest;
import com.tm.jsonwebtoken.request.TokenValidationRequest;
import com.tm.jsonwebtoken.response.JwtResponsePOJO;
import com.tm.jsonwebtoken.service.JwtService;

/**
 * Controller class for handling JSON web token generation and validation
 * requests.
 */
@RestController
@RequestMapping(value = "/jwt")
public class JwtController {

	@Autowired
	private JwtService jwtService;

	Logger logger = LoggerFactory.getLogger(JwtController.class);

	/**
	 * Handles the application details based on the received request.
	 * 
	 * @param tokenGenerationRequest
	 * @return JwtResponsePOJO
	 */
	@PostMapping("/saveApplicationDetails")
	public JwtResponsePOJO saveApplicationDetails(
			@RequestBody @Valid ApplicationDetailsRequest applicationDetailsRequest) {
		logger.info("Received request to save the application details");
		JwtResponsePOJO jwtResponsePOJO = new JwtResponsePOJO();
		try {
			logger.info("Application details request is received");
			if (jwtService.checkApplicationNameAndKeyExist(applicationDetailsRequest.getApplicationName(),
					applicationDetailsRequest.getSecretKey())) {
				logger.info("Application name and key is already exist");
				jwtResponsePOJO.errorResponse("Application name and key is already exist");
			} else {
				logger.info("Application name and key is valid");
				if (jwtService.saveApplicationDetails(applicationDetailsRequest)) {
					logger.info("Application details are saved");
					jwtResponsePOJO.response("Application details are saved", null, true);
				} else {
					logger.error("Unable to save application details");
					jwtResponsePOJO.errorResponse("Unable to save application details");
				}
			}
		} catch (Exception exception) {
			logger.error("An error occur while saving application details request", exception);
			jwtResponsePOJO.errorResponse("An error occur while saving application details request");
		}
		return jwtResponsePOJO;
	}

	/**
	 * Handles the generation of access and refresh tokens based on the received
	 * request.
	 * 
	 * @param tokenGenerationRequest
	 * @return JwtResponsePOJO
	 */
	@PostMapping("/generateToken")
	public JwtResponsePOJO generateToken(@RequestBody @Valid TokenGenerationRequest tokenGenerationRequest) {
		logger.info("Received request to generate token");
		JwtResponsePOJO jwtResponsePOJO = new JwtResponsePOJO();
		try {
			logger.info("Token generation request received successfully");
			if (jwtService.checkApplicationNameAndKeyExist(tokenGenerationRequest.getApplicationName(),
					tokenGenerationRequest.getSecretKey())) {
				logger.info("Application name and secret key are valid");
				TokenGenerationPOJO tokenGenerationPOJO = jwtService.generateToken(tokenGenerationRequest);
				if (StringUtils.hasText(tokenGenerationPOJO.getAccessToken())
						&& StringUtils.hasText(tokenGenerationPOJO.getRefreshToken())) {
					jwtResponsePOJO.response("Token is generated successfully", tokenGenerationPOJO, true);
				} else {
					logger.error("Unable to get the generate token details");
					jwtResponsePOJO.errorResponse("Unable to get the generate token details");
				}
			} else {
				logger.error("Application name and secret key does not match in database");
				jwtResponsePOJO.errorResponse("Name and key does not match");
			}
		} catch (Exception exception) {
			logger.error("An error occured while generate token request");
			jwtResponsePOJO.errorResponse("An error occured while generate token request");
		}
		return jwtResponsePOJO;
	}

	/**
	 * Handles the token validation expiration based on the received request.
	 * 
	 * @param tokenValidationRequest
	 * @return ResponseEntity<String>
	 */
	@PostMapping("/validateToken")
	public ResponseEntity<String> validateToken(@RequestBody @Valid TokenValidationRequest tokenValidationRequest) {
		logger.info("Received the request to validate the token");
		try {
			if (jwtService.checkApplicationNameAndKeyExist(tokenValidationRequest.getApplicationName(),
					tokenValidationRequest.getSecretKey())) {
				logger.info("Valid Application name and secret key");
				boolean isAccessTokenValid = jwtService.validateToken(tokenValidationRequest);
				if (isAccessTokenValid) {
					logger.info("Valid user and Token");
					return ResponseEntity.ok("Valid user and Token");
				} else {
					logger.error("Invalid user and Token");
					return new ResponseEntity<>("Invalid user and token", HttpStatus.UNAUTHORIZED);
				}
			} else {
				logger.error("Invalid Application name and secret key");
				return new ResponseEntity<>("Invalid Application name and secret key", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception exception) {
			logger.error("Unable to validate token");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unable to validate token");
		}
	}

	/**
	 * Handles the new access and refresh token generation based on the received
	 * request
	 * 
	 * @param refreshTokenRequest
	 * @return JwtResponsePOJO
	 */
	@PostMapping("/regenerateTokens")
	public JwtResponsePOJO regenerateTokens(@RequestBody @Valid RefreshTokenRequest refreshTokenRequest) {
		logger.info("Received new access and refresh token generation request");
		JwtResponsePOJO jwtResponsePOJO = new JwtResponsePOJO();
		try {
			logger.info("Token validation and regenerate tokens request received successfully");
			if (jwtService.checkApplicationNameAndKeyExist(refreshTokenRequest.getApplicationName(), 
					refreshTokenRequest.getSecretKey())) {
				logger.info("Application name and secret key is valid");
				TokenGenerationPOJO tokenGenerationPOJO = jwtService.regenerateTokens(refreshTokenRequest);
				if (StringUtils.hasText(tokenGenerationPOJO.getAccessToken())
						&& StringUtils.hasText(tokenGenerationPOJO.getRefreshToken())) {
					logger.info("Token is regenerated successfully");
					jwtResponsePOJO.response("Token is regenerated successfully", tokenGenerationPOJO, true);
				} else {
					logger.error("Unable to get the regenerate token response");
					jwtResponsePOJO.errorResponse("Unable to get the regenerate token response");
				}
			}else {
				logger.error("Application name and secret key does not match in database");
				jwtResponsePOJO.errorResponse("Application name and secret key is mismatch");
			}
		} catch (Exception exception) {
			logger.error("An error occured while regenerate token request");
			jwtResponsePOJO.errorResponse("An error occured while regenerate token request");
		}
		return jwtResponsePOJO;
	}

}
