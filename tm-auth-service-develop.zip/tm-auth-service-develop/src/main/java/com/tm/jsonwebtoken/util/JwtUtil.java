package com.tm.jsonwebtoken.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.tm.jsonwebtoken.exception.CustomJwtException;
import com.tm.jsonwebtoken.request.TokenGenerationRequest;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * This Utility class handles the JSON Web token operation like generate the
 * access and refresh token, validate the tokens
 */
@Component
public class JwtUtil {

	private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);

	/**
	 * This method is used to generate the access token with expire date
	 * 
	 * @param tokenGenerationRequest
	 * @return String
	 */
	public String generateAccessToken(TokenGenerationRequest tokenGenerationRequest) {
		logger.info("Received request to generate the access token");
		try {
			logger.info("Access token generated process start");
			Map<String, Object> claims = new HashMap<>();

			return Jwts.builder().setClaims(claims).setSubject(tokenGenerationRequest.getUniqueId())
					.setIssuedAt(new Date(System.currentTimeMillis()))
					.setExpiration(new Date(System.currentTimeMillis() + tokenGenerationRequest.getAccessTokenTime()))
					.signWith(SignatureAlgorithm.HS512, tokenGenerationRequest.getSecretKey()).compact();

		} catch (Exception exception) {
			logger.error("Unable to generate the access token", exception);
			throw new CustomJwtException("Unable to generate the access token");
		}
	}

	/**
	 * This method is used to generate the refresh token with expire date and time
	 * 
	 * @param tokenGenerationRequest
	 * @return String
	 */
	public String generateRefreshToken(TokenGenerationRequest tokenGenerationRequest) {
		logger.info("Received the request to generate the refresh token");
		try {
			logger.info("Refresh token generated process start");
			Map<String, Object> claims = new HashMap<>();

			return Jwts.builder().setClaims(claims).setSubject(tokenGenerationRequest.getUniqueId())
					.setIssuedAt(new Date(System.currentTimeMillis()))
					.setExpiration(new Date(System.currentTimeMillis() + tokenGenerationRequest.getRefreshTokenTime()))
					.signWith(SignatureAlgorithm.HS512, tokenGenerationRequest.getSecretKey()).compact();
		} catch (Exception exception) {
			logger.error("Unable to generate the refresh token", exception);
			throw new CustomJwtException("Unable to generate the refresh token");
		}
	}

	/**
	 * This method is used to check the token is expired or not
	 * 
	 * @param secretKey
	 * @param token
	 * @return boolean
	 */
	public boolean isTokenExpired(String secretKey, String token) {
		logger.info("Received the request to validate the access token");
		try {
			Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody();
			logger.info("Token is not expired");
			return true;
		} catch (ExpiredJwtException exception) {
			logger.error("Token is expired", exception);
			throw new CustomJwtException("Token is expired");
		} catch (Exception exception) {
			logger.error("Error occur while validating token", exception);
			throw new CustomJwtException("Error occur while validating token");
		}
	}

}
