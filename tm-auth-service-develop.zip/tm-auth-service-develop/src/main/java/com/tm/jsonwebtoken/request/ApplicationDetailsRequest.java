package com.tm.jsonwebtoken.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class ApplicationDetailsRequest {

	@Size(max = 50, message = "Application maximum characters: 50")
	@NotBlank(message = "Application name cannot be blank")
	private String applicationName;
	
	@Size(max = 25, message = "Secret key maximum characters: 25")
	@NotBlank(message = "Secret key cannot be blank")
	private String secretKey;

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName.trim();
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey.trim();
	}

}
