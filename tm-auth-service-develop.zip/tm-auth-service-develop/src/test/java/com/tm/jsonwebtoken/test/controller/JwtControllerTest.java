package com.tm.jsonwebtoken.test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.tm.jsonwebtoken.controller.JwtController;
import com.tm.jsonwebtoken.exception.CustomJwtException;
import com.tm.jsonwebtoken.pojo.TokenGenerationPOJO;
import com.tm.jsonwebtoken.request.ApplicationDetailsRequest;
import com.tm.jsonwebtoken.request.RefreshTokenRequest;
import com.tm.jsonwebtoken.request.TokenGenerationRequest;
import com.tm.jsonwebtoken.request.TokenValidationRequest;
import com.tm.jsonwebtoken.response.JwtResponsePOJO;
import com.tm.jsonwebtoken.service.JwtService;

@ExtendWith(MockitoExtension.class)
class JwtControllerTest {

	@Mock
	private JwtService jwtService;

	private JwtController jwtController;

	@Test
	void testApplicationDetailsSuccess() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		ApplicationDetailsRequest applicationDetailsRequest = new ApplicationDetailsRequest();
		applicationDetailsRequest.setApplicationName("Assessment");
		applicationDetailsRequest.setSecretKey("Key");
		
		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "key")).thenReturn(false);

		when(jwtService.saveApplicationDetails(applicationDetailsRequest)).thenReturn(true);

		JwtResponsePOJO jwtResponsePOJO = jwtController.saveApplicationDetails(applicationDetailsRequest);

		assertEquals(true, jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testApplicationDetailsError() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		ApplicationDetailsRequest applicationDetailsRequest = new ApplicationDetailsRequest();
		applicationDetailsRequest.setApplicationName("name");
		applicationDetailsRequest.setSecretKey("key");
		
		when(jwtService.checkApplicationNameAndKeyExist("name", "key")).thenReturn(true);

		JwtResponsePOJO jwtResponsePOJO = jwtController.saveApplicationDetails(applicationDetailsRequest);

		assertFalse(jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testApplicationDetailsIsExist() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		ApplicationDetailsRequest applicationDetailsRequest = new ApplicationDetailsRequest();
		applicationDetailsRequest.setApplicationName("name");
		applicationDetailsRequest.setSecretKey("key");

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "key")).thenReturn(false);

		when(jwtService.saveApplicationDetails(applicationDetailsRequest)).thenReturn(false);

		JwtResponsePOJO jwtResponsePOJO = jwtController.saveApplicationDetails(applicationDetailsRequest);

		assertFalse(jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testGenerateTokenSuccess() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		tokenGenerationRequest.setApplicationName("name");
		tokenGenerationRequest.setUniqueId("123");
		tokenGenerationRequest.setSecretKey("key");
		tokenGenerationRequest.setAccessTokenTime(1234);
		tokenGenerationRequest.setRefreshTokenTime(456);

		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		tokenGenerationPOJO.setUniqueId("unique");
		tokenGenerationPOJO.setAccessToken("dummyAccessToken");
		tokenGenerationPOJO.setRefreshToken("dummyRefreshToken");

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "key")).thenReturn(true);

		when(jwtService.generateToken(tokenGenerationRequest)).thenReturn(tokenGenerationPOJO);

		JwtResponsePOJO jwtResponsePOJO = jwtController.generateToken(tokenGenerationRequest);

		assertEquals(true, jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testGenerateTokenNameAndKeyNotExist() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		tokenGenerationRequest.setUniqueId("123");
		tokenGenerationRequest.setSecretKey("secretKey");
		tokenGenerationRequest.setAccessTokenTime(1234);
		tokenGenerationRequest.setRefreshTokenTime(456);

		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		tokenGenerationPOJO.setUniqueId("unique");
		tokenGenerationPOJO.setAccessToken("dummyAccessToken");
		tokenGenerationPOJO.setRefreshToken("dummyRefreshToken");

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "secretKey")).thenReturn(false);

		JwtResponsePOJO jwtResponsePOJO = jwtController.generateToken(tokenGenerationRequest);

		assertFalse(jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testGenerateTokenFailure() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		tokenGenerationRequest.setUniqueId("123");
		tokenGenerationRequest.setApplicationName("name");
		tokenGenerationRequest.setSecretKey("secretKey");
		tokenGenerationRequest.setAccessTokenTime(1234);
		tokenGenerationRequest.setRefreshTokenTime(456);

		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		tokenGenerationPOJO.setAccessToken(null);
		tokenGenerationPOJO.setRefreshToken(null);

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "secretKey")).thenReturn(true);
		
		when(jwtService.generateToken(tokenGenerationRequest)).thenReturn(tokenGenerationPOJO);

		JwtResponsePOJO jwtResponsePOJO = jwtController.generateToken(tokenGenerationRequest);

		assertEquals(false, jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testGeneratokenError() {

		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		tokenGenerationRequest.setUniqueId("123");
		tokenGenerationRequest.setApplicationName("name");
		tokenGenerationRequest.setSecretKey("secretKey");
		tokenGenerationRequest.setAccessTokenTime(1234);
		tokenGenerationRequest.setRefreshTokenTime(456);

		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		tokenGenerationPOJO.setAccessToken("dummyAccessToken");
		tokenGenerationPOJO.setRefreshToken("dummyRefreshToken");

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "secretKey")).thenReturn(true);
		
		when(jwtService.generateToken(tokenGenerationRequest))
				.thenThrow(new CustomJwtException("An error occured while generate token request"))
				.thenReturn(tokenGenerationPOJO);

		JwtResponsePOJO jwtResponsePOJO = jwtController.generateToken(tokenGenerationRequest);

		assertNotNull(jwtResponsePOJO);

	}

	@Test
	void testValidateTokenSuccess() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		TokenValidationRequest tokenValidationRequest = new TokenValidationRequest();
		tokenValidationRequest.setApplicationName("name");
		tokenValidationRequest.setSecretKey("secretKey");
		tokenValidationRequest.setAccessToken("dummyAccessToken");

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "secretKey")).thenReturn(true);

		when(jwtService.validateToken(tokenValidationRequest)).thenReturn(true);

		ResponseEntity<String> validateToken = jwtController.validateToken(tokenValidationRequest);

		assertEquals(HttpStatus.OK, validateToken.getStatusCode());

	}

	@Test
	void testValidateTokenNameAndKeyError() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		TokenValidationRequest tokenValidationRequest = new TokenValidationRequest();
		tokenValidationRequest.setApplicationName("name");
		tokenValidationRequest.setSecretKey("secretKey");
		tokenValidationRequest.setAccessToken("dummyAccessToken");

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "secretKey")).thenReturn(false);

		ResponseEntity<String> validateToken = jwtController.validateToken(tokenValidationRequest);

		assertEquals(HttpStatus.BAD_REQUEST, validateToken.getStatusCode());

	}

	@Test
	void testValidateTokenFailure() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		TokenValidationRequest tokenGenerationRequest = new TokenValidationRequest();
		tokenGenerationRequest.setApplicationName("name");
		tokenGenerationRequest.setSecretKey("key");
		tokenGenerationRequest.setAccessToken("dummyAccessToken");
        
		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "key")).thenReturn(true);
		
		when(jwtService.validateToken(tokenGenerationRequest)).thenReturn(false);

		ResponseEntity<String> validateToken = jwtController.validateToken(tokenGenerationRequest);

		assertNotEquals(HttpStatus.OK, validateToken.getStatusCode());
	}

	@Test
	void testValidateTokenError() {

		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		TokenValidationRequest tokenValidationRequest = null;

		lenient(). when(jwtService.validateToken(tokenValidationRequest)).thenThrow(new NullPointerException("Error"))
				.thenReturn(false);

		ResponseEntity<String> responseEntity = jwtController.validateToken(tokenValidationRequest);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
	}

	@Test
	void testRegenerateTokenSuccess() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
		refreshTokenRequest.setUniqueId("123");
		refreshTokenRequest.setApplicationName("name");
		refreshTokenRequest.setSecretKey("secretKey");
		refreshTokenRequest.setAccessToken("dummyAccessToken");
		refreshTokenRequest.setRefreshToken("dummyRefreshToken");
		refreshTokenRequest.setAccessTokenTime(1234);
		refreshTokenRequest.setRefreshTokenTime(456);

		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		tokenGenerationPOJO.setAccessToken("dummyAccessToken");
		tokenGenerationPOJO.setRefreshToken("dummyRefreshToken");

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "secretKey")).thenReturn(true);

		when(jwtService.regenerateTokens(refreshTokenRequest)).thenReturn(tokenGenerationPOJO);

		JwtResponsePOJO jwtResponsePOJO = jwtController.regenerateTokens(refreshTokenRequest);

		assertEquals(true, jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testRegenerateTokenNameAndKeyError() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
		refreshTokenRequest.setUniqueId("123");
		refreshTokenRequest.setApplicationName("name");
		refreshTokenRequest.setSecretKey("secretKey");
		refreshTokenRequest.setAccessToken("dummyAccessToken");
		refreshTokenRequest.setRefreshToken("dummyRefreshToken");
		refreshTokenRequest.setAccessTokenTime(1234);
		refreshTokenRequest.setRefreshTokenTime(456);

		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		tokenGenerationPOJO.setAccessToken("dummyAccessToken");
		tokenGenerationPOJO.setRefreshToken("dummyRefreshToken");

		lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "secretKey")).thenReturn(false);

		JwtResponsePOJO jwtResponsePOJO = jwtController.regenerateTokens(refreshTokenRequest);

		assertFalse(jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testRegenerateTokenFailure() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
		refreshTokenRequest.setUniqueId("123");
		refreshTokenRequest.setApplicationName("name");
		refreshTokenRequest.setSecretKey("key");
		refreshTokenRequest.setAccessToken("dummyAccessToken");
		refreshTokenRequest.setRefreshToken("dummyRefreshToken");
		refreshTokenRequest.setAccessTokenTime(1234);
		refreshTokenRequest.setRefreshTokenTime(456);

		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		tokenGenerationPOJO.setAccessToken(null);
		tokenGenerationPOJO.setRefreshToken(null);

	   lenient().when(jwtService.checkApplicationNameAndKeyExist("name", "key")).thenReturn(true);
		
		when(jwtService.regenerateTokens(refreshTokenRequest)).thenReturn(tokenGenerationPOJO);

		JwtResponsePOJO jwtResponsePOJO = jwtController.regenerateTokens(refreshTokenRequest);

		assertEquals(false, jwtResponsePOJO.getIsSuccess());
	}

	@Test
	void testRegeneraTokenError() {
		jwtController = new JwtController();
		jwtService = mock(JwtService.class);
		ReflectionTestUtils.setField(jwtController, "jwtService", jwtService);

		RefreshTokenRequest refreshTokenRequest = null;

		TokenGenerationPOJO tokenGenerationPOJO = new TokenGenerationPOJO();
		tokenGenerationPOJO.setAccessToken("dummyAccessToken");
		tokenGenerationPOJO.setRefreshToken("dummyRefreshToken");

		lenient(). when(jwtService.regenerateTokens(refreshTokenRequest))
				.thenThrow(new NullPointerException("An error occure while regenerate token request"))
				.thenReturn(tokenGenerationPOJO);

		JwtResponsePOJO jwtResponsePOJO = jwtController.regenerateTokens(refreshTokenRequest);

		assertNotNull(jwtResponsePOJO);

	}

}
