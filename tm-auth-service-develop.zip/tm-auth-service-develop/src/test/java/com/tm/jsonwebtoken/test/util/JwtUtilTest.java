package com.tm.jsonwebtoken.test.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.StringUtils;

import com.tm.jsonwebtoken.exception.CustomJwtException;
import com.tm.jsonwebtoken.repository.TokenDetailsRepository;
import com.tm.jsonwebtoken.request.TokenGenerationRequest;
import com.tm.jsonwebtoken.util.JwtUtil;

@ExtendWith(MockitoExtension.class)
class JwtUtilTest {

	@Mock
	private TokenDetailsRepository tokenDetailsRepository;
	
	private JwtUtil jwtUtil;
	
	@Test
	void testGenerateAccesssToken() {
		jwtUtil = new JwtUtil();
		
		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		tokenGenerationRequest.setUniqueId("123");
		tokenGenerationRequest.setSecretKey("secretKey");
		tokenGenerationRequest.setAccessTokenTime(1234);
		tokenGenerationRequest.setRefreshTokenTime(456);
		
		String accessToken=jwtUtil.generateAccessToken(tokenGenerationRequest);
		
		assertTrue(StringUtils.hasText(accessToken));
	}
	
	@Test
	void testGenerateAccesssTokenError() {
		jwtUtil = new JwtUtil();
		
		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		
		Exception exception = assertThrows(CustomJwtException.class, ()-> jwtUtil.generateAccessToken(tokenGenerationRequest));
		
		assertEquals("Unable to generate the access token",exception.getMessage());
	}
	
	@Test
	void testGenerateRefreshToken() {
		jwtUtil = new JwtUtil();
		
		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		tokenGenerationRequest.setUniqueId("123");
		tokenGenerationRequest.setSecretKey("secretKey");
		tokenGenerationRequest.setAccessTokenTime(1234);
		tokenGenerationRequest.setRefreshTokenTime(456);
		
		String refreshToken=jwtUtil.generateRefreshToken(tokenGenerationRequest);
		
		assertTrue(StringUtils.hasText(refreshToken));
	}
	
	@Test
	void testGenerateRefreshTokenError() {
		jwtUtil = new JwtUtil();
		
		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		
		CustomJwtException exception = assertThrows(CustomJwtException.class,
				 ()-> jwtUtil.generateRefreshToken(tokenGenerationRequest));
		
		assertEquals("Unable to generate the refresh token",exception.getMessage());
	}
	
	@Test
	void testIsTokenNotExpired() {
		
		jwtUtil = new JwtUtil();
		
		String secretKey = "jsonwebtoken";
		String accessToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxM2I2MjZmZi0xZjAwLTQ3MzYtYjViMC03NzI3MmUwY2UwOTAiLCJleHAiOjE3MTcwNDkxNTUsImlhdCI6MTcxNTMyMTE1NX0.ahQBCJfVFOrDI-8Dfi-5vU-HCbWZ3sWoryqcj42CRkRUrql4xaokBIDpvCXobJy_0Fdz0ZYp_0KISz3KqGr0tw";
		
		boolean result = jwtUtil.isTokenExpired(secretKey,accessToken);
	
		assertTrue(result);
	}
	
	@Test
	void testIsTokenExpired() {
		
		jwtUtil = new JwtUtil();
		
		String secretKey = "jsonwebtoken";
		String accessToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxM2I2MjZmZi0xZjAwLTQ3MzYtYjViMC03NzI3MmUwY2UwOTAiLCJleHAiOjE3MTUzMjMwNTksImlhdCI6MTcxNTMyMjc1OX0.3O_w1po6yOPWHYOBIwR0eAOQSe_-xVKvWmPyvOMj0nGXG7BIBweLfylCB0Wd-flW3ojb2k9CPiRmBCiMdDnQbA";
		
		Exception exception = assertThrows(CustomJwtException.class,
				() -> jwtUtil.isTokenExpired(secretKey,accessToken));
		
		assertEquals("Token is expired", exception.getMessage());
	}
	
	@Test
	void testTokenSignatureError() {
		jwtUtil = new JwtUtil();
		
		String secretKey = "jsonweb";
		String token = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxM2I2MjZmZi0xZjAwLTQ3MzYtYjViMC03NzI3MmUwY2UwOTAiLCJleHAiOjE3MTUzMjE3ODYsImlhdCI6MTcxNTMyMTQ4Nn0.HP5viBlKCYKYW9eOfEBUVusyYm_y1jS5MjYWBgFDMJsxZhxF8QNvc7zsnTEpGMqdc3NblAiMcvMqdSwopTi8rw";
		
		Exception exception = assertThrows(CustomJwtException.class,
				() -> jwtUtil.isTokenExpired(secretKey,token));
		
		assertEquals("Error occur while validating token", exception.getMessage());
	}
	
}
