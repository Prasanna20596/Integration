package com.tm.jsonwebtoken.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.InvalidDataAccessResourceUsageException;
import org.springframework.test.util.ReflectionTestUtils;

import com.tm.jsonwebtoken.entity.ApplicationDetails;
import com.tm.jsonwebtoken.entity.TokenDetails;
import com.tm.jsonwebtoken.entity.TransacTokenDetails;
import com.tm.jsonwebtoken.exception.CustomJwtException;
import com.tm.jsonwebtoken.pojo.TokenGenerationPOJO;
import com.tm.jsonwebtoken.repository.ApplicationDetailsRepository;
import com.tm.jsonwebtoken.repository.TokenDetailsRepository;
import com.tm.jsonwebtoken.repository.TransacTokenDetailsRepository;
import com.tm.jsonwebtoken.request.ApplicationDetailsRequest;
import com.tm.jsonwebtoken.request.RefreshTokenRequest;
import com.tm.jsonwebtoken.request.TokenGenerationRequest;
import com.tm.jsonwebtoken.request.TokenValidationRequest;
import com.tm.jsonwebtoken.service.impl.JwtServiceImpl;
import com.tm.jsonwebtoken.util.JwtUtil;

import io.jsonwebtoken.SignatureException;

@ExtendWith(MockitoExtension.class)
class JwtServiceImplTest {

	@Mock
	private JwtUtil jwtUtil;

	@Mock
	private TokenDetailsRepository tokenDetailsRepository;

	@Mock
	private TransacTokenDetailsRepository transacTokenDetailsRepository;

	@Mock
	private ApplicationDetailsRepository applicationDetailsRepository;
	
	private JwtServiceImpl jwtServiceImpl;

	@Test
	void testApplicatonDetailsSuccess() {
		jwtServiceImpl = new JwtServiceImpl();
		applicationDetailsRepository=mock(ApplicationDetailsRepository.class);
		
		ReflectionTestUtils.setField(jwtServiceImpl, "applicationDetailsRepository", applicationDetailsRepository);
		
		ApplicationDetails applicationDetails=new ApplicationDetails();
		applicationDetails.setApplicationId(1);
		applicationDetails.setApplicationName("name");
		applicationDetails.setSecretKey("key");
		
		when(applicationDetailsRepository.save(any())).thenReturn(applicationDetails);
		
		ApplicationDetailsRequest applicationDetailsRequest=new ApplicationDetailsRequest();
		applicationDetailsRequest.setApplicationName("name");
		applicationDetails.setSecretKey("key");
		
	    boolean isApplicationSaved=jwtServiceImpl.saveApplicationDetails(applicationDetailsRequest);
	    
	    assertTrue(isApplicationSaved);
	}
	
	@Test
	void testApplicatonDetailsError() {
		jwtServiceImpl = new JwtServiceImpl();
		applicationDetailsRepository=mock(ApplicationDetailsRepository.class);
		
		ReflectionTestUtils.setField(jwtServiceImpl, "applicationDetailsRepository", applicationDetailsRepository);
		
		ApplicationDetails applicationDetails=new ApplicationDetails();
		applicationDetails.setApplicationId(1);
		applicationDetails.setApplicationName("name");
		applicationDetails.setSecretKey("key");
		
		when(applicationDetailsRepository.save(any()))
		.thenThrow(new NullPointerException("An Error occur while application details saved request"))
		.thenReturn(applicationDetails);
		
		ApplicationDetailsRequest applicationDetailsRequest=new ApplicationDetailsRequest();
		applicationDetailsRequest.setApplicationName("name");
		applicationDetails.setSecretKey("key");
		
	    boolean isApplicationDetailsError=jwtServiceImpl.saveApplicationDetails(applicationDetailsRequest);
	    
	    assertFalse(isApplicationDetailsError);
	}
	
	@Test
	void testGenerateTokenSuccess() {

		jwtServiceImpl = new JwtServiceImpl();
		jwtUtil = mock(JwtUtil.class);
		tokenDetailsRepository = mock(TokenDetailsRepository.class);
        transacTokenDetailsRepository = mock(TransacTokenDetailsRepository.class);
        
		ReflectionTestUtils.setField(jwtServiceImpl, "jwtUtil", jwtUtil);
		ReflectionTestUtils.setField(jwtServiceImpl, "tokenDetailsRepository", tokenDetailsRepository);
		ReflectionTestUtils.setField(jwtServiceImpl, "transacTokenDetailsRepository", transacTokenDetailsRepository);
		
		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		tokenGenerationRequest.setUniqueId("123");
		tokenGenerationRequest.setSecretKey("secretKey");
		tokenGenerationRequest.setAccessTokenTime(1234);
		tokenGenerationRequest.setRefreshTokenTime(456);

		String uniqueId = "123";
		String accessToken = "dummyAccessToken";
		String refreshToken = "dummyRefreshToken";
		
		TokenDetails tokenDetails=new TokenDetails();
		tokenDetails.setUniqueId(uniqueId);
		tokenDetails.setAccessToken(accessToken);
		tokenDetails.setRefreshToken(refreshToken);

		TransacTokenDetails transacTokenDetails=new TransacTokenDetails();
		transacTokenDetails.setUniqueId(uniqueId);
		transacTokenDetails.setAccessToken(accessToken);
		transacTokenDetails.setRefreshToken(refreshToken);
		
		when(jwtUtil.generateAccessToken(tokenGenerationRequest)).thenReturn("Success");

		when(jwtUtil.generateRefreshToken(tokenGenerationRequest)).thenReturn("Success");

		TokenGenerationPOJO tokenGenerationPOJO = jwtServiceImpl.generateToken(tokenGenerationRequest);

		assertNotNull(tokenGenerationPOJO);
	}

	@Test
	void testExistingTokenDetailsUpdated() {
		jwtServiceImpl = new JwtServiceImpl();
		tokenDetailsRepository = mock(TokenDetailsRepository.class);
		ReflectionTestUtils.setField(jwtServiceImpl, "tokenDetailsRepository", tokenDetailsRepository);

		String uniqueId = "123";
		String accessToken = "dummyAccessToken";
		String refreshToken = "dummyRefreshToken";

		TokenDetails tokenDetails = new TokenDetails();
		tokenDetails.setUniqueId("123");
		tokenDetails.setAccessToken("dummyAccessToken");

		when(tokenDetailsRepository.findByUniqueId(anyString())).thenReturn(tokenDetails);

		boolean isExistingTokenSaved = jwtServiceImpl.saveTokenDetails(uniqueId, accessToken, refreshToken);

		assertTrue(isExistingTokenSaved);
	}

	@Test
	void testNewTokenDetailsSaved() {
		jwtServiceImpl = new JwtServiceImpl();
		tokenDetailsRepository = mock(TokenDetailsRepository.class);
		ReflectionTestUtils.setField(jwtServiceImpl, "tokenDetailsRepository", tokenDetailsRepository);

		String uniqueId = "123";
		String accessToken = "dummyAccessToken";
		String refreshToken = "dummyRefreshToken";

		TokenDetails tokenDetails = new TokenDetails();
		tokenDetails.setTokenId(1);
		tokenDetails.setAccessToken(accessToken);
		tokenDetails.setRefreshToken(refreshToken);

		boolean isTokenSaved = jwtServiceImpl.saveTokenDetails(uniqueId, accessToken, refreshToken);

		assertTrue(isTokenSaved);
	}

	@Test
	void testTokenDetailsTableisExist() {
		jwtServiceImpl = new JwtServiceImpl();
		tokenDetailsRepository = mock(TokenDetailsRepository.class);
		ReflectionTestUtils.setField(jwtServiceImpl, "tokenDetailsRepository", tokenDetailsRepository);

		String uniqueId = "123";
		String accessToken = "dummyAccessToken";
		String refreshToken = "dummyRefreshToken";

		TokenDetails tokenDetails = new TokenDetails();
		tokenDetails.setUniqueId("123");
		tokenDetails.setAccessToken("dummyAccessToken");

		when(tokenDetailsRepository.findByUniqueId(anyString()))
				.thenThrow(new InvalidDataAccessResourceUsageException("Token details table is not exist"))
				.thenReturn(tokenDetails);

		boolean isExistingTokenSaved = jwtServiceImpl.saveTokenDetails(uniqueId, accessToken, refreshToken);

		assertFalse(isExistingTokenSaved);
	}

	@Test
	void testSaveTransactionTokenDetails() {
		jwtServiceImpl = new JwtServiceImpl();
		transacTokenDetailsRepository = mock(TransacTokenDetailsRepository.class);
		ReflectionTestUtils.setField(jwtServiceImpl, "transacTokenDetailsRepository", transacTokenDetailsRepository);

		String uniqueId = "123";
		String accessToken = "dummyAccessToken";
		String refreshToken = "dummyRefreshToken";

		TransacTokenDetails transacTokenDetails = new TransacTokenDetails();
		transacTokenDetails.setTokenId(1);
		transacTokenDetails.setAccessToken(accessToken);
		transacTokenDetails.setRefreshToken(refreshToken);

		boolean isTransacTokenSaved = jwtServiceImpl.saveTransactionTokenDetails(uniqueId, accessToken, refreshToken);

		assertTrue(isTransacTokenSaved);
	}

	@Test
	void testTransactionTokenTableIsExist() {

		jwtServiceImpl = new JwtServiceImpl();
		transacTokenDetailsRepository = mock(TransacTokenDetailsRepository.class);
		ReflectionTestUtils.setField(jwtServiceImpl, "transacTokenDetailsRepository", transacTokenDetailsRepository);

		String uniqueId = "123";
		String accessToken = "dummyAccessToken";
		String refreshToken = "dummyRefreshToken";

		when(transacTokenDetailsRepository.save(any(TransacTokenDetails.class)))
				.thenThrow(new InvalidDataAccessResourceUsageException("Table does not exist"));

		boolean result = jwtServiceImpl.saveTransactionTokenDetails(uniqueId, accessToken, refreshToken);

		assertFalse(result);
	}

	@Test
	void testGenerateTokenError() {

		jwtServiceImpl = new JwtServiceImpl();
		jwtUtil = mock(JwtUtil.class);
		tokenDetailsRepository = mock(TokenDetailsRepository.class);
		transacTokenDetailsRepository = mock(TransacTokenDetailsRepository.class);

		ReflectionTestUtils.setField(jwtServiceImpl, "jwtUtil", jwtUtil);
		ReflectionTestUtils.setField(jwtServiceImpl, "tokenDetailsRepository", tokenDetailsRepository);
		ReflectionTestUtils.setField(jwtServiceImpl, "transacTokenDetailsRepository", transacTokenDetailsRepository);

		TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
		tokenGenerationRequest.setUniqueId("123");
		tokenGenerationRequest.setSecretKey("secretKey");
		tokenGenerationRequest.setAccessTokenTime(1234);
		tokenGenerationRequest.setRefreshTokenTime(456);

		when(jwtUtil.generateAccessToken(tokenGenerationRequest)).thenThrow(new CustomJwtException("Error"))
				.thenReturn("Error");

		CustomJwtException exception = assertThrows(CustomJwtException.class, () -> jwtServiceImpl.generateToken(tokenGenerationRequest));
		
		assertEquals("Unable to get the token details!..", exception.getMessage());
	}

	@Test
	void testValidateTokenSuccess() {

		jwtServiceImpl = new JwtServiceImpl();
		jwtUtil = mock(JwtUtil.class);
		ReflectionTestUtils.setField(jwtServiceImpl, "jwtUtil", jwtUtil);

		String secretKey = "jsonwebtoken";
		String accessToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxM2I2MjZmZi0xZjAwLTQ3MzYtYjViMC03NzI3MmUwY2UwOTAiLCJleHAiOjE3MTcwNDkxNTUsImlhdCI6MTcxNTMyMTE1NX0.ahQBCJfVFOrDI-8Dfi-5vU-HCbWZ3sWoryqcj42CRkRUrql4xaokBIDpvCXobJy_0Fdz0ZYp_0KISz3KqGr0tw";
		
		TokenValidationRequest tokenValidationRequest=new TokenValidationRequest();
		tokenValidationRequest.setSecretKey(secretKey);
		tokenValidationRequest.setAccessToken(accessToken);
		
		when(jwtUtil.isTokenExpired(secretKey, accessToken)).thenReturn(true);

		boolean result = jwtServiceImpl.validateToken(tokenValidationRequest);

		assertTrue(result);
	}
	
	@Test
	void testValidateTokenError() {

		jwtServiceImpl = new JwtServiceImpl();
		jwtUtil = mock(JwtUtil.class);
		ReflectionTestUtils.setField(jwtServiceImpl, "jwtUtil", jwtUtil);

		String secretKey = "gffggsdsdsdsdsdds";
		String accessToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxM2I2MjZmZi0xZjAwLTQ3MzYtYjViMC03NzI3MmUwY2UwOTAiLCJleHAiOjE3MTUzMjMwNTksImlhdCI6MTcxNTMyMjc1OX0.3O_w1po6yOPWHYOBIwR0eAOQSe_-xVKvWmPyvOMj0nGXG7BIBweLfylCB0Wd-flW3ojb2k9CPiRmBCiMdDnQbA";
		
		TokenValidationRequest tokenValidationRequest = new TokenValidationRequest();
		tokenValidationRequest.setSecretKey(secretKey);
		tokenValidationRequest.setAccessToken(accessToken);

		when(jwtUtil.isTokenExpired(secretKey,accessToken)).thenThrow(new SignatureException("An error occur while validate the token")).thenReturn(false);

		boolean result = jwtServiceImpl.validateToken(tokenValidationRequest);

		assertFalse(result);

	}
	
	@Test
	void testRegenerateTokenSuccess() {
	    jwtServiceImpl = new JwtServiceImpl();
	    jwtUtil = mock(JwtUtil.class);
	    tokenDetailsRepository = mock(TokenDetailsRepository.class);
	    transacTokenDetailsRepository = mock(TransacTokenDetailsRepository.class);

	    ReflectionTestUtils.setField(jwtServiceImpl, "jwtUtil", jwtUtil);
	    ReflectionTestUtils.setField(jwtServiceImpl, "tokenDetailsRepository", tokenDetailsRepository);
	    ReflectionTestUtils.setField(jwtServiceImpl, "transacTokenDetailsRepository", transacTokenDetailsRepository);

	    String uniqueId = "123";
	    String secretkey = "jsonwebtoken";
	    String accessToken = "dummyAccessToken";
	    String refreshToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxM2I2MjZmZi0xZjAwLTQ3MzYtYjViMC03NzI3MmUwY2UwOTAiLCJleHAiOjE3MTUzMjMwNTksImlhdCI6MTcxNTMyMjc1OX0.3O_w1po6yOPWHYOBIwR0eAOQSe_-xVKvWmPyvOMj0nGXG7BIBweLfylCB0Wd-flW3ojb2k9CPiRmBCiMdDnQbA";

	    RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
	    refreshTokenRequest.setUniqueId(uniqueId);
	    refreshTokenRequest.setSecretKey(secretkey);
	    refreshTokenRequest.setAccessToken(accessToken);
	    refreshTokenRequest.setRefreshToken(refreshToken);
	    refreshTokenRequest.setAccessTokenTime(1234);
	    refreshTokenRequest.setRefreshTokenTime(456);

	    TokenDetails tokenDetails=new TokenDetails();
	    tokenDetails.setUniqueId(uniqueId);
	    tokenDetails.setAccessToken(accessToken);
	    tokenDetails.setRefreshToken(refreshToken);

	    TransacTokenDetails transacTokenDetails=new TransacTokenDetails();
	    transacTokenDetails.setUniqueId(uniqueId);
	    transacTokenDetails.setAccessToken(accessToken);
	    transacTokenDetails.setRefreshToken(refreshToken);

	    TokenGenerationRequest tokenGenerationRequest = new TokenGenerationRequest();
	    tokenGenerationRequest.setUniqueId("123");
	    tokenGenerationRequest.setSecretKey("secretKey");
	    tokenGenerationRequest.setAccessTokenTime(1234);
	    tokenGenerationRequest.setRefreshTokenTime(456);

	    when(jwtUtil.isTokenExpired(secretkey,refreshToken)).thenReturn(true);

	    when(jwtUtil.generateAccessToken(any(TokenGenerationRequest.class))).thenReturn("ActualAccessToken");
	    when(jwtUtil.generateRefreshToken(any(TokenGenerationRequest.class))).thenReturn("ActualRefreshToken");

	    TokenGenerationPOJO tokenGenerationPOJO = jwtServiceImpl.regenerateTokens(refreshTokenRequest);

	    assertEquals("ActualAccessToken", tokenGenerationPOJO.getAccessToken());
	}

	@Test
	void testRegenerateTokenFailure() {

		jwtServiceImpl = new JwtServiceImpl();
		jwtUtil = mock(JwtUtil.class);
       
		ReflectionTestUtils.setField(jwtServiceImpl, "jwtUtil", jwtUtil);
		
		String uniqueId = "123";
		String secretKey = "jsonwebtoken";
		String accessToken = "dummyAccessToken";
		String refreshToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxM2I2MjZmZi0xZjAwLTQ3MzYtYjViMC03NzI3MmUwY2UwOTAiLCJleHAiOjE3MTUzMjMwNTksImlhdCI6MTcxNTMyMjc1OX0.3O_w1po6yOPWHYOBIwR0eAOQSe_-xVKvWmPyvOMj0nGXG7BIBweLfylCB0Wd-flW3ojb2k9CPiRmBCiMdDnQbA";
		
		RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
		refreshTokenRequest.setUniqueId(uniqueId);
		refreshTokenRequest.setSecretKey("secretKey");
		refreshTokenRequest.setAccessToken(accessToken);
		refreshTokenRequest.setRefreshToken(refreshToken);
		refreshTokenRequest.setAccessTokenTime(1234);
		refreshTokenRequest.setRefreshTokenTime(456);
		
		lenient().when(jwtUtil.isTokenExpired(secretKey,accessToken)).thenReturn(false);
	
		TokenGenerationPOJO tokenGenerationPOJO = jwtServiceImpl.regenerateTokens(refreshTokenRequest);

		assertNull(tokenGenerationPOJO.getAccessToken());
	}
	
	@Test
	void testRegenerateTokenError() {

		jwtServiceImpl = new JwtServiceImpl();
		jwtUtil = mock(JwtUtil.class);

		ReflectionTestUtils.setField(jwtServiceImpl, "jwtUtil", jwtUtil);

		String uniqueId = "123";
		String secretKey = "secretKey";
		String accessToken = "dummyAccessToken";
		String refreshToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxM2I2MjZmZi0xZjAwLTQ3MzYtYjViMC03NzI3MmUwY2UwOTAiLCJleHAiOjE3MTUzMjMwNTksImlhdCI6MTcxNTMyMjc1OX0.3O_w1po6yOPWHYOBIwR0eAOQSe_-xVKvWmPyvOMj0nGXG7BIBweLfylCB0Wd-flW3ojb2k9CPiRmBCiMdDnQbA";

		RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
		refreshTokenRequest.setUniqueId(uniqueId);
		refreshTokenRequest.setSecretKey("secretKey");
		refreshTokenRequest.setAccessToken(accessToken);
		refreshTokenRequest.setRefreshToken(refreshToken);
		refreshTokenRequest.setAccessTokenTime(1234);
		refreshTokenRequest.setRefreshTokenTime(456);

		when(jwtUtil.isTokenExpired(secretKey,refreshToken)).thenThrow(new CustomJwtException("Error"))
				.thenReturn(false);

		CustomJwtException exception = assertThrows(CustomJwtException.class,
				() -> jwtServiceImpl.regenerateTokens(refreshTokenRequest));

		assertEquals("An error occur while refresh the token", exception.getMessage());
	}
	
	@Test
	void testNameAndKeyisExist() {
		jwtServiceImpl = new JwtServiceImpl();
		applicationDetailsRepository= mock(ApplicationDetailsRepository.class);
		
		ReflectionTestUtils.setField(jwtServiceImpl, "applicationDetailsRepository", applicationDetailsRepository);
		String name = "name";
		String secretKey = "secretKey";
		
		when(applicationDetailsRepository.existsByApplicationNameAndSecretKey(name, secretKey)).thenReturn(true);
		
		boolean isNameAndKeyIsExist = jwtServiceImpl.checkApplicationNameAndKeyExist(name, secretKey);
		
		assertTrue(isNameAndKeyIsExist);
	}
	
	@Test
	void testNameAndKeyExistError() {
		jwtServiceImpl = new JwtServiceImpl();
		applicationDetailsRepository= mock(ApplicationDetailsRepository.class);
		
		ReflectionTestUtils.setField(jwtServiceImpl, "applicationDetailsRepository", applicationDetailsRepository);
		
		String name = "name";
		String secretKey = "secretKey";
		
		when(applicationDetailsRepository.existsByApplicationNameAndSecretKey(name, secretKey))
		  .thenThrow(new InvalidDataAccessResourceUsageException("Error"))
		  .thenReturn(false);
		
		boolean isNameAndKeyIsExist = jwtServiceImpl.checkApplicationNameAndKeyExist(name, secretKey);
		
		assertFalse(isNameAndKeyIsExist);
	}
	
}
