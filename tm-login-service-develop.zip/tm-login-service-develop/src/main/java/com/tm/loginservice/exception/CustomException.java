package com.tm.loginservice.exception;

public class CustomException extends RuntimeException{

	public CustomException(String message) {
		super(message);
	}
	
}
