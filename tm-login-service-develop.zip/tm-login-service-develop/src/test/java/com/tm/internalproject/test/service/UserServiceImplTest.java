package com.tm.internalproject.test.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.InvalidDataAccessResourceUsageException;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tm.loginservice.entity.UserDetails;
import com.tm.loginservice.exception.CustomException;
import com.tm.loginservice.pojo.TokenPropertiesPOJO;
import com.tm.loginservice.pojo.TokenResponsePOJO;
import com.tm.loginservice.pojo.request.LoginRequest;
import com.tm.loginservice.repository.UserRepository;
import com.tm.loginservice.service.impl.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

	@Mock
	private UserRepository userRepository;

	@Mock
	private RestTemplate restTemplate;

	private UserServiceImpl userServiceImpl;

	@Test
	void testGenerateTokenResponse() throws Exception {

		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		restTemplate = mock(RestTemplate.class);

		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);
		
		ReflectionTestUtils.setField(userServiceImpl, "restTemplate", restTemplate);
				
		String email = "abc@gmail.com";
		String uniqueId = "1234";

		UserDetails userDetails = new UserDetails();
		userDetails.setUserId(1);
		userDetails.setName("abcde");
		userDetails.setEmail(email);
		userDetails.setPassword("abc@123");
		userDetails.setCreatedAt(Timestamp.valueOf("2024-02-10 20:36:00.559"));
		userDetails.setUpdatedAt(Timestamp.valueOf("2024-04-16 22:44:00.352"));
		userDetails.setCreatedBy("abcde");
		userDetails.setUpdatedBy("abcde");
		userDetails.setUniqueId(uniqueId);

		when(userRepository.findByEmail(email)).thenReturn(userDetails);

		String accessToken = "dummyAccessToken";
		String refreshToken = "dummyRefreshToken";

		ObjectMapper objectMapper = new ObjectMapper();
		ObjectNode responseBodyNode = objectMapper.createObjectNode();
		ObjectNode responseDataNode = objectMapper.createObjectNode();
		responseDataNode.put("uniqueId", uniqueId);
		responseDataNode.put("accessToken", accessToken);
		responseDataNode.put("refreshToken", refreshToken);
		responseBodyNode.set("responseData", responseDataNode);

		when(restTemplate.postForObject(anyString(), any(), any())).thenReturn(responseBodyNode);

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail(email);

		TokenResponsePOJO tokenResponsePOJO = userServiceImpl.generateToken(loginRequest);

		assertNotNull(tokenResponsePOJO);
	}

	@Test
	void testgenerateTokenIllegalArgumentError() throws Exception {
		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);

		String email = "abc@gmail.com";

		UserDetails userDetails = new UserDetails();
		userDetails.setUserId(1);
		userDetails.setName("Prasanna");
		userDetails.setEmail(email);
		userDetails.setPassword("12345");
		userDetails.setCreatedAt(Timestamp.valueOf("2024-02-10 20:36:00.559"));
		userDetails.setUpdatedAt(Timestamp.valueOf("2024-04-16 22:44:00.352"));
		userDetails.setCreatedBy("Prasanna");
		userDetails.setUpdatedBy("Prasanna");
		userDetails.setUniqueId("12345");

		userDetails.getUserId();
		userDetails.getName();
		userDetails.getEmail();
		userDetails.getPassword();
		userDetails.getCreatedAt();
		userDetails.getUpdatedAt();
		userDetails.getCreatedBy();
		userDetails.getUpdatedBy();
		userDetails.getUniqueId();

		when(userRepository.findByEmail(anyString()))
				.thenThrow(new IllegalArgumentException("Given input are invalid data type")).thenReturn(userDetails);

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail(email);

		Exception exception = assertThrows(CustomException.class, () -> userServiceImpl.generateToken(loginRequest));

		assertEquals("An error occur while generate token request", exception.getMessage());
	}

	@Test
	void testGenerateTokenInvalidJsonFormat() throws Exception {
		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		restTemplate = mock(RestTemplate.class);

		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);
		ReflectionTestUtils.setField(userServiceImpl, "restTemplate", restTemplate);
		
		String email = "abc@gmail.com";

		UserDetails userDetails = new UserDetails();
		userDetails.setUserId(1);
		userDetails.setName("abcde");
		userDetails.setEmail(email);
		userDetails.setPassword("abc@123");
		userDetails.setCreatedAt(Timestamp.valueOf("2024-02-10 20:36:00.559"));
		userDetails.setUpdatedAt(Timestamp.valueOf("2024-04-16 22:44:00.352"));
		userDetails.setCreatedBy("abcde");
		userDetails.setUpdatedBy("abcde");
		userDetails.setUniqueId("1234");

		when(userRepository.findByEmail(email)).thenReturn(userDetails);

		when(restTemplate.postForObject(anyString(), any(), any())).thenReturn(new Object());

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail(email);

		assertThrows(CustomException.class, () -> userServiceImpl.generateToken(loginRequest),
				"Invalid json format structure");
	}

	@Test
	void testEmailIdisExist() {
		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);

		when(userRepository.existsByEmail(anyString())).thenReturn(true);

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail("abc@gmail.com");

		boolean result = userServiceImpl.checkEmailExistorNot(loginRequest);
		assertEquals(true, result);
	}

	@Test
	void testEmailIdTableIstExist() {
		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);

		when(userRepository.existsByEmail(anyString())).thenThrow(new InvalidDataAccessResourceUsageException("Error"))
				.thenReturn(false);

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail("abc@gmail.com");

		boolean isTableNotExist = userServiceImpl.checkEmailExistorNot(loginRequest);

		assertFalse(isTableNotExist);
	}

	@Test
	void testPassIllegalEmailError() {
		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);

		when(userRepository.existsByEmail(anyString())).thenThrow(new IllegalArgumentException("Error"))
				.thenReturn(false);

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail("abc@gmail.com");

		boolean isIllegalArgumentError = userServiceImpl.checkEmailExistorNot(loginRequest);

		assertFalse(isIllegalArgumentError);
	}

	@Test
	void testEmailAndPasswrordisExist() {
		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);

		when(userRepository.existsByEmailAndPassword(anyString(), anyString())).thenReturn(true);

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail("abc@gmail.com");
		loginRequest.setPassword("abc@123");

		boolean result = userServiceImpl.checkEmailAndPasswordExistOrNot(loginRequest);
		
		assertEquals(true, result);
	}

	@Test
	void testEmailIdAndPasswordTableIsExist() {

		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);

		when(userRepository.existsByEmailAndPassword(anyString(), anyString()))
				.thenThrow(new InvalidDataAccessResourceUsageException("Error")).thenReturn(false);

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail("abc@gmail.com");
		loginRequest.setPassword("abc@123");

		boolean isEmailandPasswordError = userServiceImpl.checkEmailAndPasswordExistOrNot(loginRequest);

		assertFalse(isEmailandPasswordError);
	}

	@Test
	void testPassIllegalEmailIdAndPasswordError() {

		userServiceImpl = new UserServiceImpl();
		userRepository = mock(UserRepository.class);
		ReflectionTestUtils.setField(userServiceImpl, "userRepository", userRepository);

		when(userRepository.existsByEmailAndPassword(anyString(), anyString()))
				.thenThrow(new IllegalArgumentException("Error")).thenReturn(false);

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setEmail("abc@gmail.com");
		loginRequest.setPassword("abc@123");

		boolean isIllegalError = userServiceImpl.checkEmailAndPasswordExistOrNot(loginRequest);

		assertFalse(isIllegalError);
	}

}
