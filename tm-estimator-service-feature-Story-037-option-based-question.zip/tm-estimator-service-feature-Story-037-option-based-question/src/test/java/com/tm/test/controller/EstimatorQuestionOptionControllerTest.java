package com.tm.test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessException;
import org.springframework.test.util.ReflectionTestUtils;

import com.tm.estimator.controller.QuestionOptionController;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.response.EstimatorResponsePOJO;
import com.tm.estimator.service.EstimatorService;
import com.tm.estimator.service.impl.EstimatorServiceImpl;

@ExtendWith(MockitoExtension.class)
 class EstimatorQuestionOptionControllerTest {

	private EstimatorService estimatorService;

	private QuestionOptionController questionOptionController;

	@Test
	void testFetchQuestionOptionWithValidResponse() {

		questionOptionController = new QuestionOptionController();
		estimatorService = mock(EstimatorServiceImpl.class);
		ReflectionTestUtils.setField(questionOptionController, "estimatorService", estimatorService);

		List<QuestionOptionDTO> questionOptionDTOs = new ArrayList<>();

		QuestionOptionDTO questionOptionDTO = new QuestionOptionDTO();
		questionOptionDTO.setQuestionKey(1);
//		questionOptionDTO.setQuestionId(UUID.randomUUID());
		questionOptionDTO.setQuestion("questions");
		questionOptionDTO.setMaxSelection(4);
//		questionOptionDTO.setQuestionType("CHECKBOX");
		questionOptionDTO.setIsSkippable(false);
		questionOptionDTO.setOptionDescription("option Desctiption");
		questionOptionDTO.setOptionOrder(1);
//		questionOptionDTO.setOptionId(UUID.randomUUID());
		questionOptionDTO.setOptionText("optionText");
		questionOptionDTO.setOptionOrder(1);
		questionOptionDTO.setOptionHours(0);
		questionOptionDTO.setIsOptionAll(false);
		questionOptionDTO.setCost(0);
		questionOptionDTO.setImage("image");
		questionOptionDTOs.add(questionOptionDTO);
		when(estimatorService.fetchQuestionDetails()).thenReturn(questionOptionDTOs);
		EstimatorResponsePOJO estimatorResponsePOJO = questionOptionController.fetchQuestionOption();
		assertEquals(true, estimatorResponsePOJO.getIsSuccess());

	}

	@Test
	void testFetchQuestionOptionWithoutValidResponse() {

		questionOptionController = new QuestionOptionController();
		estimatorService = mock(EstimatorServiceImpl.class);
		ReflectionTestUtils.setField(questionOptionController, "estimatorService", estimatorService);

		List<QuestionOptionDTO> questionOptionDTOs = new ArrayList<>();

		when(estimatorService.fetchQuestionDetails()).thenReturn(questionOptionDTOs);
		EstimatorResponsePOJO estimatorResponsePOJO = questionOptionController.fetchQuestionOption();
		assertEquals(false, estimatorResponsePOJO.getIsSuccess());

	}

	@Test
	void testUserLoginError() {
		String dataError = "DataAccessException";
		try {
			questionOptionController = new QuestionOptionController();
			estimatorService = mock(EstimatorServiceImpl.class);
			ReflectionTestUtils.setField(questionOptionController, "estimatorService", estimatorService);

			List<QuestionOptionDTO> questionOptionDTOs = new ArrayList<>();

			when(estimatorService.fetchQuestionDetails()).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(questionOptionDTOs);

			  questionOptionController.fetchQuestionOption();
		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

}
