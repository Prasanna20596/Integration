package com.tm.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.intThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.hibernate.validator.internal.util.privilegedactions.GetDeclaredMethod;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessException;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tm.estimator.dao.EstimatorDao;
import com.tm.estimator.dao.impl.EstimatorDaoImpl;
import com.tm.estimator.dto.ClientDetailsDTO;
import com.tm.estimator.dto.ClientKeyDTO;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.dto.RequirementDTO;
import com.tm.estimator.dto.RequirementDetailsDTO;
import com.tm.estimator.dto.RequirementInfoDTO;
import com.tm.estimator.dto.RowCountDTO;
import com.tm.estimator.dto.ValuesDTO;
import com.tm.estimator.enums.OrderByColumns;
import com.tm.estimator.enums.QuestionType;
import com.tm.estimator.enums.SortBy;
import com.tm.estimator.pojo.ClientDetailsPOJO;
import com.tm.estimator.pojo.FetchClientDetailsPOJO;
import com.tm.estimator.pojo.RequirementDetailsPOJO;
import com.tm.estimator.pojo.ValuePOJO;
import com.tm.estimator.pojo.request.EstimatorRequestPOJO;
import com.tm.estimator.pojo.request.FetchClientDetailsRequestPOJO;
import com.tm.estimator.pojo.request.LogInRequestPOJO;
import com.tm.estimator.pojo.request.SaveRequirementRequestPOJO;
import com.tm.estimator.service.impl.EstimatorServiceImpl;

@ExtendWith(MockitoExtension.class)
class EstimatorServiceTest {

//	@Mock
	private EstimatorDao estimatorDao;

	private EstimatorServiceImpl estimatorServiceImpl;

	@Test
	void testSaveClientDetails() {

		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);
		EstimatorRequestPOJO requestPOJO = new EstimatorRequestPOJO();
		String uuid = "123456";
		when(estimatorDao.saveClientDetails(eq(requestPOJO), anyString())).thenReturn(uuid);

		String responseUUID = estimatorServiceImpl.saveClientDetails(requestPOJO);
		assertEquals(uuid, responseUUID);

	}

	@Test
	void testSaveClientDetailsError() {
		String dataError = "DataAccessException";
		try {
			estimatorServiceImpl = new EstimatorServiceImpl();
			EstimatorRequestPOJO requestPOJO = new EstimatorRequestPOJO();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			when(estimatorDao.saveClientDetails(eq(requestPOJO), anyString()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(dataError);

			estimatorServiceImpl.saveClientDetails(requestPOJO);
		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	@Test
	void testFetchQuestionDetails() {

		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);
		List<QuestionOptionDTO> mockList = mock(List.class);

		when(estimatorDao.fetchQuestionDetails()).thenReturn(mockList);

		List<QuestionOptionDTO> responseUUID = estimatorServiceImpl.fetchQuestionDetails();
		assertEquals(mockList, responseUUID);

	}

	@Test
	void testFetchQuestionDetailsError() {
		String dataError = "DataAccessException";
		try {
			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			List<QuestionOptionDTO> questionOptionDTOs = new ArrayList<>();
			when(estimatorDao.fetchQuestionDetails()).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(questionOptionDTOs);
			estimatorServiceImpl.fetchQuestionDetails();
		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	/**
	 * This method is used for test the condition of limit and pageNO and sorting,
	 * sortby
	 */
	@Test
	void testFetchclientDetails() {

		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

		FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO = new FetchClientDetailsRequestPOJO();
		fetchClientDetailsRequestPOJO.setLimit(10);
		fetchClientDetailsRequestPOJO.setPageNo(1);
		fetchClientDetailsRequestPOJO.setSortingBy(OrderByColumns.CLIENTNAME);
		fetchClientDetailsRequestPOJO.setSortBy(SortBy.ASC);

		List<ClientDetailsDTO> clientDetailsList = new ArrayList<>();
		ClientDetailsDTO clientDetailsDTO = new ClientDetailsDTO();

		clientDetailsDTO.setClientContact("4554444456");
		clientDetailsDTO.setClientId(UUID.randomUUID());
		clientDetailsDTO.setClientMailid("jason@gmail.com");
		clientDetailsDTO.setClientName("jason");
		clientDetailsDTO.setTotalCost(10);
		clientDetailsDTO.setTotalHours(45);
		clientDetailsList.add(clientDetailsDTO);

		when(estimatorDao.fetchClientDetails(anyInt(), anyInt(), any(), any())).thenReturn(clientDetailsList);
		RowCountDTO rowCountDTO = new RowCountDTO();
		rowCountDTO.setRowCount(1);

		when(estimatorDao.getRowCountClientDetails()).thenReturn(rowCountDTO);

		FetchClientDetailsPOJO fetchClientDetailsPOJO = estimatorServiceImpl
				.fetchClientDetails(fetchClientDetailsRequestPOJO);

		ObjectMapper objectMapper = new ObjectMapper();

		FetchClientDetailsPOJO fetchClientDetails = new FetchClientDetailsPOJO();

		fetchClientDetails.setClientDetails(
				objectMapper.convertValue(clientDetailsList, new TypeReference<List<ClientDetailsPOJO>>() {
				}));
		assertEquals(fetchClientDetails.getClientDetails().get(0).getClientId(),
				fetchClientDetailsPOJO.getClientDetails().get(0).getClientId());

	}

	@Test
	void testFetchclientDetailsWithSearch() {

		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

		FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO = new FetchClientDetailsRequestPOJO();
		fetchClientDetailsRequestPOJO.setLimit(10);
		fetchClientDetailsRequestPOJO.setPageNo(1);
		fetchClientDetailsRequestPOJO.setSortingBy(OrderByColumns.CLIENTNAME);
		fetchClientDetailsRequestPOJO.setSortBy(SortBy.ASC);
		fetchClientDetailsRequestPOJO.setClientSearch("jason");

		List<ClientDetailsDTO> clientDetailsList = new ArrayList<>();
		ClientDetailsDTO clientDetailsDTO = new ClientDetailsDTO();

		clientDetailsDTO.setClientContact("8300012665");
		clientDetailsDTO.setClientId(UUID.randomUUID());
		clientDetailsDTO.setClientMailid("bv@4898");
		clientDetailsDTO.setClientName("bala");
		clientDetailsDTO.setTotalCost(10);
		clientDetailsDTO.setTotalHours(45);
		clientDetailsList.add(clientDetailsDTO);

		when(estimatorDao.clientSearch(anyInt(), anyInt(), anyString())).thenReturn(clientDetailsList);
		RowCountDTO rowCountDTO = new RowCountDTO();
		rowCountDTO.setRowCount(1);

		when(estimatorDao.getRowCountClientSerach(anyString())).thenReturn(rowCountDTO);

		FetchClientDetailsPOJO fetchClientDetailsPOJO = estimatorServiceImpl
				.fetchClientDetails(fetchClientDetailsRequestPOJO);

		ObjectMapper objectMapper = new ObjectMapper();

		FetchClientDetailsPOJO fetchClientDetails = new FetchClientDetailsPOJO();

		fetchClientDetails.setClientDetails(
				objectMapper.convertValue(clientDetailsList, new TypeReference<List<ClientDetailsPOJO>>() {
				}));
		assertEquals(fetchClientDetails.getClientDetails().get(0).getClientId(),
				fetchClientDetailsPOJO.getClientDetails().get(0).getClientId());

	}

	@Test
	void testFetchclientDetailsWithLimitAndPageno() {

		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

		FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO = new FetchClientDetailsRequestPOJO();
		fetchClientDetailsRequestPOJO.setLimit(10);
		fetchClientDetailsRequestPOJO.setPageNo(1);

		List<ClientDetailsDTO> clientDetailsList = new ArrayList<>();
		ClientDetailsDTO clientDetailsDTO = new ClientDetailsDTO();

		clientDetailsDTO.setClientContact("8300012665");
		clientDetailsDTO.setClientId(UUID.randomUUID());
		clientDetailsDTO.setClientMailid("bv@4898");
		clientDetailsDTO.setClientName("bala");
		clientDetailsDTO.setTotalCost(10);
		clientDetailsDTO.setTotalHours(45);
		clientDetailsList.add(clientDetailsDTO);

		when(estimatorDao.fetchClientDetails(anyInt(), anyInt(), any(), any())).thenReturn(clientDetailsList);
		RowCountDTO rowCountDTO = new RowCountDTO();
		rowCountDTO.setRowCount(1);

		when(estimatorDao.getRowCountClientDetails()).thenReturn(rowCountDTO);

		FetchClientDetailsPOJO fetchClientDetailsPOJO = estimatorServiceImpl
				.fetchClientDetails(fetchClientDetailsRequestPOJO);

		ObjectMapper objectMapper = new ObjectMapper();

		FetchClientDetailsPOJO fetchClientDetails = new FetchClientDetailsPOJO();

		fetchClientDetails.setClientDetails(
				objectMapper.convertValue(clientDetailsList, new TypeReference<List<ClientDetailsPOJO>>() {
				}));
		assertEquals(fetchClientDetails.getClientDetails().get(0).getClientId(),
				fetchClientDetailsPOJO.getClientDetails().get(0).getClientId());

	}

	@Test
	void testFetchclientDetailsError() {
		String dataError = "DataAccessException";
		try {
			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO = new FetchClientDetailsRequestPOJO();
			fetchClientDetailsRequestPOJO.setLimit(10);
			fetchClientDetailsRequestPOJO.setPageNo(1);
			fetchClientDetailsRequestPOJO.setSortingBy(any());
			fetchClientDetailsRequestPOJO.setSortBy(any());
			List<ClientDetailsDTO> clientDetailsList = new ArrayList<>();
			when(estimatorDao.fetchClientDetails(10, 1, any(), any())).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(clientDetailsList);

			estimatorServiceImpl.fetchClientDetails(fetchClientDetailsRequestPOJO);
		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	@Test
	void testFetchClientKey() {

		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);
		UUID id = UUID.randomUUID();
		ClientKeyDTO clientKeyDTO = new ClientKeyDTO();
		clientKeyDTO.setClientKey(0);
		clientKeyDTO.setClientName("bala");
		when(estimatorDao.fetchClientKey(id)).thenReturn(clientKeyDTO);

		ClientKeyDTO clientKeyResponse = estimatorServiceImpl.fetchClientKey(id);
		assertEquals(clientKeyDTO, clientKeyResponse);

	}

	@Test
	void testFetchClientKeyError() {
		String dataError = "DataAccessException";
		try {
			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			UUID id = UUID.randomUUID();
			ClientKeyDTO clientKeyDTO = new ClientKeyDTO();
			clientKeyDTO.setClientKey(0);
			clientKeyDTO.setClientName("bala");

			when(estimatorDao.fetchClientKey(id)).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(clientKeyDTO);

			estimatorServiceImpl.fetchClientKey(id);

		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	@Test
	void testSaveClientRequirement() {
		int value = 0;
		SaveRequirementRequestPOJO saveRequirementRequest = new SaveRequirementRequestPOJO();
		List<RequirementDetailsPOJO> requirementDetailsPOJOs = new ArrayList<>();
		RequirementDetailsPOJO requirementDetails = new RequirementDetailsPOJO();
		List<ValuePOJO> valuePOJO = new ArrayList<>();
		ValuePOJO valuePOJOs = new ValuePOJO();

		valuePOJOs.setCost(value);
		valuePOJOs.setHours(value);
		valuePOJOs.setOption("option");
		valuePOJOs.setOptionText("optionText");
		valuePOJO.add(valuePOJOs);

		requirementDetails.setQuestion("questions");
		requirementDetails.setQuestionId(UUID.randomUUID());
		requirementDetails.setQuestionType(QuestionType.CHECKBOX);
		requirementDetails.setValue(valuePOJO);
		requirementDetailsPOJOs.add(requirementDetails);

		saveRequirementRequest.setClientId(UUID.randomUUID());
		saveRequirementRequest.setReqList(requirementDetailsPOJOs);
		saveRequirementRequest.setTotalCost(value);
		saveRequirementRequest.setTotalHours(value);

		ClientKeyDTO clientKeyDTO = new ClientKeyDTO();
		clientKeyDTO.setClientKey(value);
		clientKeyDTO.setClientName("jason");

		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

		when(estimatorDao.saveClientRequirement(any(), any(), anyInt(), anyInt())).thenReturn(value);

		int serviceResponse = estimatorServiceImpl.saveClientRequirement(saveRequirementRequest, clientKeyDTO);
		assertEquals(value, serviceResponse);

	}

	@Test
	void testSaveClientRequirementError() {
		String dataError = "DataAccessException";
		int value = 0;
		try {

			SaveRequirementRequestPOJO saveRequirementRequest = new SaveRequirementRequestPOJO();
			ClientKeyDTO clientKeyDTO = new ClientKeyDTO();

			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			when(estimatorDao.saveClientRequirement(any(), any(), anyInt(), anyInt()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(value);

			estimatorServiceImpl.saveClientRequirement(saveRequirementRequest, clientKeyDTO);

		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	// TODO
	@Test
	void testFetchRequirementDetails() {
		RequirementInfoDTO requirementInfoDTO = new RequirementInfoDTO();
		List<RequirementDetailsDTO> mockRequirementDetailsDTOList = new ArrayList<>();
		List<ValuesDTO> valuesDTOList = new ArrayList<>();
		ValuesDTO valuesDTO = new ValuesDTO();
		valuesDTO.setCost(0);
		valuesDTO.setHours(0);
		valuesDTO.setOption(UUID.randomUUID());
		valuesDTO.setOptionText("Text");
		valuesDTOList.add(valuesDTO);

		RequirementDetailsDTO requirementDetailsDTO = new RequirementDetailsDTO();
		requirementDetailsDTO.setQuestion("questions");
		requirementDetailsDTO.setQuestionId(UUID.randomUUID());
		requirementDetailsDTO.setQuestionType("CHECKBOX");
		requirementDetailsDTO.setValue(valuesDTOList);
		mockRequirementDetailsDTOList.add(requirementDetailsDTO);

		requirementInfoDTO.setTotalCost(0);
		requirementInfoDTO.setTotalHours(0);
		requirementInfoDTO.setRequirementDetails(mockRequirementDetailsDTOList);

		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);
		UUID id = UUID.randomUUID();

		when(estimatorDao.fetchRequirementDetails(id)).thenReturn(requirementInfoDTO);

		List<RequirementDTO> requirementDTOMock = new ArrayList<>();
		RequirementDTO requirementDTO = new RequirementDTO();
		requirementDTO.setQuestion("questions");
		requirementDTO.setQuestionId(UUID.randomUUID());
		requirementDTO.setQuestionType("CHECKBOX");
		requirementDTO.setOptionText("questions text");
		requirementDTO.setOptionId(UUID.randomUUID());
		requirementDTOMock.add(requirementDTO);

		when(estimatorDao.fetchQuestionByOption(anySet())).thenReturn(requirementDTOMock);

		RequirementInfoDTO serviceResponse = estimatorServiceImpl.fetchRequirementDetails(id);
		assertEquals(requirementInfoDTO, serviceResponse);

	}

	@Test
	void testFetchRequirementDetailsError() {
		String dataError = "DataAccessException";
		try {
			RequirementInfoDTO requirementInfoDTO = new RequirementInfoDTO();
			UUID id = UUID.randomUUID();
			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			when(estimatorDao.fetchRequirementDetails(id)).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(requirementInfoDTO);

			estimatorServiceImpl.fetchRequirementDetails(id);

		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	@Test
	void testClientIdValidate() {
		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

		UUID id = UUID.randomUUID();

		when(estimatorDao.clientIdValidate(id)).thenReturn(true);

		boolean isVaid = estimatorServiceImpl.clientIdValidate(id);
		assertEquals(true, isVaid);

	}

	@Test
	void testClientIdValidateError() {
		String dataError = "DataAccessException";
		try {
			UUID id = UUID.randomUUID();
			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			when(estimatorDao.clientIdValidate(id)).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(true);

			estimatorServiceImpl.clientIdValidate(id);

		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	@Test
	void testIsValidOption() {
		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

		UUID id = UUID.randomUUID();
		Set<String> mockList = mock(Set.class);

		when(estimatorDao.isValidOption(mockList)).thenReturn(true);

		boolean isVaid = estimatorServiceImpl.isValidOption(mockList);
		assertEquals(true, isVaid);

	}

	@Test
	void testIsValidOptionError() {
		String dataError = "DataAccessException";
		try {
			Set<String> mockList = mock(Set.class);
			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			when(estimatorDao.isValidOption(mockList)).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(true);

			estimatorServiceImpl.isValidOption(mockList);

		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	@Test
	void testIsValidQuestion() {
		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

		UUID id = UUID.randomUUID();
		Set<UUID> mockUidList = mock(Set.class);

		when(estimatorDao.isValidQuestion(mockUidList.stream().map(UUID::toString).collect(Collectors.toSet())))
				.thenReturn(true);
		boolean isVaid = estimatorServiceImpl.isValidQuestion(mockUidList);
		assertEquals(true, isVaid);

	}

	@Test
	void testIsValidQuestionError() {
		String dataError = "DataAccessException";
		try {
			Set<UUID> mockUidList = mock(Set.class);
			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			when(estimatorDao.isValidQuestion(mockUidList.stream().map(UUID::toString).collect(Collectors.toSet())))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(true);

			estimatorServiceImpl.isValidQuestion(mockUidList);

		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

	@Test
	void testUserLogin() {
		estimatorServiceImpl = new EstimatorServiceImpl();
		estimatorDao = mock(EstimatorDaoImpl.class);
		ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

		LogInRequestPOJO logInRequestPOJO = new LogInRequestPOJO();

		when(estimatorDao.userLogin(logInRequestPOJO)).thenReturn(true);
		boolean isVaid = estimatorServiceImpl.userLogin(logInRequestPOJO);
		assertEquals(true, isVaid);

	}

	@Test
	void testUrLoginError() {
		String dataError = "DataAccessException";
		try {
			Set<UUID> mockUidList = mock(Set.class);
			estimatorServiceImpl = new EstimatorServiceImpl();
			estimatorDao = mock(EstimatorDaoImpl.class);
			ReflectionTestUtils.setField(estimatorServiceImpl, "estimatorDao", estimatorDao);

			LogInRequestPOJO logInRequestPOJO = new LogInRequestPOJO();

			when(estimatorDao.userLogin(logInRequestPOJO)).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(true);

			estimatorServiceImpl.userLogin(logInRequestPOJO);

		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

}
