package com.tm.test.dao;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.tm.estimator.dao.EstimatorDao;
import com.tm.estimator.dao.impl.EstimatorDaoImpl;
import com.tm.estimator.dto.ClientDetailsDTO;
import com.tm.estimator.dto.ClientKeyDTO;
import com.tm.estimator.dto.FetchRequirementDetailsDTO;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.dto.RequirementDTO;
import com.tm.estimator.dto.RequirementInfoDTO;
import com.tm.estimator.dto.RowCountDTO;
import com.tm.estimator.enums.OrderByColumns;
import com.tm.estimator.enums.SortBy;
import com.tm.estimator.pojo.RequirementDetailsPOJO;
import com.tm.estimator.pojo.request.EstimatorRequestPOJO;
import com.tm.estimator.pojo.request.LogInRequestPOJO;

@ExtendWith(MockitoExtension.class)
class EstimatorDaoTest {

	private EstimatorDao estimatorDao;

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Test
	void testFetchQuestionDetails() {

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		List<QuestionOptionDTO> questionOptionList = new ArrayList<>();

		QuestionOptionDTO questionOptionDTO = new QuestionOptionDTO();
		questionOptionDTO.setQuestionKey(0);
//		questionOptionDTO.setQuestionId(UUID.randomUUID());
		questionOptionDTO.setQuestion("questions");
		questionOptionDTO.setMaxSelection(4);
		questionOptionDTO.setCost(0);
		questionOptionDTO.setImage("image");
		questionOptionDTO.setOptionDescription("description");
		questionOptionDTO.setQuestionOrder(1);
		questionOptionDTO.setIsSkippable(false);
//		questionOptionDTO.setOptionId(UUID.randomUUID());
		questionOptionDTO.setOptionText("optionText");
		questionOptionDTO.setOptionOrder(1);
		questionOptionDTO.setOptionHours(0);
		questionOptionDTO.setIsOptionAll(false);
		questionOptionDTO.setQuestionType("CHECKBOX");

		when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<QuestionOptionDTO>>any())).thenReturn(questionOptionList);

		List<QuestionOptionDTO> questionOption = estimatorDao.fetchQuestionDetails();

		assertEquals(questionOptionList, questionOption);

	}

	@Test
	void testFetchQuestionDetailsError() {
		String dataError = "DataAccessException";
		try {
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			List<QuestionOptionDTO> questionOptionList = new ArrayList<>();

			when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
					Mockito.<BeanPropertyRowMapper<QuestionOptionDTO>>any()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(questionOptionList);

			estimatorDao.fetchQuestionDetails();

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testSaveClientDetails() {

		int value = 10;
		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
		String uuid = UUID.randomUUID().toString();

		when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.<MapSqlParameterSource>any()))
				.thenReturn(value);
		EstimatorRequestPOJO estimatorRequestPOJO = new EstimatorRequestPOJO();
		estimatorRequestPOJO.setClientMailId("jason@gmail.com");
		estimatorRequestPOJO.setClientName("jason");
		estimatorRequestPOJO.setContactNumber("4564546654");
		String responseString = estimatorDao.saveClientDetails(estimatorRequestPOJO, uuid);

		assertEquals(uuid, responseString);

	}

	@Test
	void testSaveClientDetailsWithoutSave() {

		int value = 0;
		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
		String uuid = UUID.randomUUID().toString();

		when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.<MapSqlParameterSource>any()))
				.thenReturn(value);
		EstimatorRequestPOJO estimatorRequestPOJO = new EstimatorRequestPOJO();
		estimatorRequestPOJO.setClientMailId("jason@gmail.com");
		estimatorRequestPOJO.setClientName("jason");
		estimatorRequestPOJO.setContactNumber("4564546654");
		String responseString = estimatorDao.saveClientDetails(estimatorRequestPOJO, uuid);

		assertNull(responseString);

	}

	@Test
	void testSaveClientDetailsError() {
		String dataError = "DataAccessException";
		try {
			int value = 10;
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.<MapSqlParameterSource>any()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(value);
			EstimatorRequestPOJO estimatorRequestPOJO = new EstimatorRequestPOJO();
			estimatorRequestPOJO.setClientMailId("jason@gmail.com");
			estimatorRequestPOJO.setClientName("jason");
			estimatorRequestPOJO.setContactNumber("4564546654");
			estimatorDao.saveClientDetails(estimatorRequestPOJO, UUID.randomUUID().toString());

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testfetchClientDetailsWithName() {

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		List<ClientDetailsDTO> responseList = new ArrayList<>();

		when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<ClientDetailsDTO>>any())).thenReturn(responseList);

		List<ClientDetailsDTO> clientDetailsDTOs = estimatorDao.fetchClientDetails(10, 1, OrderByColumns.CLIENTNAME,
				SortBy.ASC);

		assertEquals(responseList, clientDetailsDTOs);

	}

	@Test
	void testfetchClientDetailsWithEmail() {

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		List<ClientDetailsDTO> responseList = new ArrayList<>();

		when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<ClientDetailsDTO>>any())).thenReturn(responseList);

		List<ClientDetailsDTO> clientDetailsDTOs = estimatorDao.fetchClientDetails(10, 1, OrderByColumns.CLIENTMAIL,
				SortBy.ASC);

		assertEquals(responseList, clientDetailsDTOs);

	}

	@Test
	void testfetchClientDetailsWithCreatedAt() {

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		List<ClientDetailsDTO> responseList = new ArrayList<>();

		when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<ClientDetailsDTO>>any())).thenReturn(responseList);

		List<ClientDetailsDTO> clientDetailsDTOs = estimatorDao.fetchClientDetails(10, 1,
				OrderByColumns.CLIENTCREATEDAT, SortBy.ASC);

		assertEquals(responseList, clientDetailsDTOs);

	}

	@Test
	void testfetchClientDetailsError() {
		String dataError = "DataAccessException";
		try {
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			List<ClientDetailsDTO> responseList = new ArrayList<>();

			when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
					Mockito.<BeanPropertyRowMapper<ClientDetailsDTO>>any()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(responseList);

			estimatorDao.fetchClientDetails(10, 1, OrderByColumns.CLIENTNAME, SortBy.ASC);

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testClientSearch() {
		String clientSearch = "jason";

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		List<ClientDetailsDTO> responseList = new ArrayList<>();

		when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<ClientDetailsDTO>>any())).thenReturn(responseList);

		List<ClientDetailsDTO> clientDetailsDTOs = estimatorDao.clientSearch(10, 1, clientSearch);

		assertEquals(responseList, clientDetailsDTOs);

	}

	@Test
	void testClientSearchError() {
		String dataError = "DataAccessException";
		try {
			String clientSearch = "jason";

			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			List<ClientDetailsDTO> responseList = new ArrayList<>();

			when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
					Mockito.<BeanPropertyRowMapper<ClientDetailsDTO>>any()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(responseList);

			estimatorDao.clientSearch(10, 1, clientSearch);

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testFetchClientKey() {

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		ClientKeyDTO clientKeyDTO = new ClientKeyDTO();

		when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<ClientKeyDTO>>any())).thenReturn(clientKeyDTO);

		ClientKeyDTO clientKeyDTOResponse = estimatorDao.fetchClientKey(UUID.randomUUID());

		assertEquals(clientKeyDTO, clientKeyDTOResponse);

	}

	@Test
	void testFetchClientKeyError() {
		String dataError = "DataAccessException";
		try {

			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			ClientKeyDTO clientKeyDTO = new ClientKeyDTO();

			when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
					Mockito.<BeanPropertyRowMapper<ClientKeyDTO>>any())).thenThrow(new DataAccessException(dataError) {
					}).thenReturn(clientKeyDTO);

			estimatorDao.fetchClientKey(UUID.randomUUID());

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testSaveClientRequirement() {

		int valueInt = 10;
		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		ClientKeyDTO clientKeyDTO = new ClientKeyDTO();
		clientKeyDTO.setClientKey(valueInt);
		clientKeyDTO.setClientName("jason");
		List<RequirementDetailsPOJO> requirementDetailsPOJO = new ArrayList<>();

		when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.<MapSqlParameterSource>any()))
				.thenReturn(valueInt);

		int response = estimatorDao.saveClientRequirement(clientKeyDTO, requirementDetailsPOJO, 20, 50);

		assertEquals(valueInt, response);

	}

	@Test
	void testSaveClientRequirementError() {
		String dataError = "DataAccessException";
		int valueInt = 10;
		try {

			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			ClientKeyDTO clientKeyDTO = new ClientKeyDTO();
			clientKeyDTO.setClientKey(valueInt);
			clientKeyDTO.setClientName("jason");
			List<RequirementDetailsPOJO> requirementDetailsPOJO = new ArrayList<>();

			when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.<MapSqlParameterSource>any()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(valueInt);

			estimatorDao.saveClientRequirement(clientKeyDTO, requirementDetailsPOJO, 20, 50);

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testFetchRequirementDetails() {

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		FetchRequirementDetailsDTO fetchRequirementDetailsDTO = new FetchRequirementDetailsDTO();
		fetchRequirementDetailsDTO.setActualResult(
				"[{\"questionId\": \"9efbbcd5-5bab-11ee-b59c-06076df31120\",\"questionType\": \"CHECKBOX\",\"value\": [{\"option\": \"fdf31a3b-5bab-11eeb59c-06076df31120\",\"cost\": 15,\"hours\": 4}]}]");
		fetchRequirementDetailsDTO.setTotalCost(5);
		fetchRequirementDetailsDTO.setTotalHours(0);

		when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<FetchRequirementDetailsDTO>>any()))
				.thenReturn(fetchRequirementDetailsDTO);

		RequirementInfoDTO response = estimatorDao.fetchRequirementDetails(UUID.randomUUID());

		assertEquals(fetchRequirementDetailsDTO.getTotalCost(), response.getTotalCost());

	}

	@Test
	void testFetchRequirementDetailsError() {
		String dataError = "DataAccessException";
		try {

			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			FetchRequirementDetailsDTO fetchRequirementDetailsDTO = new FetchRequirementDetailsDTO();

			when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
					Mockito.<BeanPropertyRowMapper<FetchRequirementDetailsDTO>>any()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(fetchRequirementDetailsDTO);

			estimatorDao.fetchRequirementDetails(UUID.randomUUID());

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testFetchQuestionByOption() {

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		List<RequirementDTO> requirementDTO = new ArrayList<>();
		Set<String> setString = new HashSet<>();
		setString.add(UUID.randomUUID().toString());

		when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<RequirementDTO>>any())).thenReturn(requirementDTO);

		List<RequirementDTO> response = estimatorDao.fetchQuestionByOption(setString);

		assertEquals(requirementDTO, response);

	}

	@Test
	void testFetchQuestionByOptionError() {
		String dataError = "DataAccessException";
		try {

			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			List<RequirementDTO> requirementDTO = new ArrayList<>();
			Set<String> setString = new HashSet<>();
			setString.add(UUID.randomUUID().toString());

			when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
					Mockito.<BeanPropertyRowMapper<RequirementDTO>>any()))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(requirementDTO);

			estimatorDao.fetchQuestionByOption(setString);

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testClientIdValidate() {
		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
				Mockito.eq(Integer.class))).thenReturn(10);

		boolean response = estimatorDao.clientIdValidate(UUID.randomUUID());

		assertEquals(true, response);

	}

	@Test
	void testClientIdValidateError() {
		String dataError = "DataAccessException";
		try {
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),
					Mockito.any(MapSqlParameterSource.class), Mockito.eq(Integer.class)))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(10);
			estimatorDao.clientIdValidate(UUID.randomUUID());

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testIsValidQuestion() {
		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
				Mockito.eq(Integer.class))).thenReturn(1);

		Set<String> questionIdSet = new HashSet<>();
		questionIdSet.add(UUID.randomUUID().toString());

		boolean response = estimatorDao.isValidQuestion(questionIdSet);
		assertEquals(true, response);

	}

	@Test
	void testIsValidQuestionError() {
		String dataError = "DataAccessException";
		try {
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),
					Mockito.any(MapSqlParameterSource.class), Mockito.eq(Integer.class)))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(1);
			Set<String> questionIdSet = new HashSet<>();
			questionIdSet.add(UUID.randomUUID().toString());

			estimatorDao.isValidQuestion(questionIdSet);

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testIsValidOption() {
		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
				Mockito.eq(Integer.class))).thenReturn(1);

		Set<String> questionIdSet = new HashSet<>();
		questionIdSet.add(UUID.randomUUID().toString());

		boolean response = estimatorDao.isValidOption(questionIdSet);
		assertEquals(true, response);

	}

	@Test
	void testIsValidOptionError() {
		String dataError = "DataAccessException";
		try {
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),
					Mockito.any(MapSqlParameterSource.class), Mockito.eq(Integer.class)))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(1);
			Set<String> questionIdSet = new HashSet<>();
			questionIdSet.add(UUID.randomUUID().toString());

			estimatorDao.isValidOption(questionIdSet);

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testUserLogin() {
		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class),
				Mockito.eq(Integer.class))).thenReturn(1);

		Set<String> questionIdSet = new HashSet<>();
		questionIdSet.add(UUID.randomUUID().toString());

		LogInRequestPOJO logInRequestPojo = new LogInRequestPOJO();
		logInRequestPojo.setUserName("jason");
		logInRequestPojo.setUserPassword("jason@");
		boolean response = estimatorDao.userLogin(logInRequestPojo);
		assertEquals(true, response);

	}

	@Test
	void testUserLoginError() {
		String dataError = "DataAccessException";
		try {
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

			when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),
					Mockito.any(MapSqlParameterSource.class), Mockito.eq(Integer.class)))
					.thenThrow(new DataAccessException(dataError) {
					}).thenReturn(1);
			LogInRequestPOJO logInRequestPojo = new LogInRequestPOJO();
			logInRequestPojo.setUserName("jason");
			logInRequestPojo.setUserPassword("jason@");
			estimatorDao.userLogin(logInRequestPojo);

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testGetRowCountClientDetails() {

		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		RowCountDTO rowCount = new RowCountDTO();

		when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<RowCountDTO>>any())).thenReturn(rowCount);

		RowCountDTO response = estimatorDao.getRowCountClientDetails();

		assertEquals(rowCount, response);

	}

	@Test
	void testGetRowCountClientDetailsError() {
		String dataError = "DataAccessException";
		try {
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
			RowCountDTO rowCount = new RowCountDTO();

			when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
					Mockito.<BeanPropertyRowMapper<RowCountDTO>>any())).thenThrow(new DataAccessException(dataError) {
					}).thenReturn(rowCount);

			estimatorDao.getRowCountClientDetails();

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}

	@Test
	void testGetRowCountClientSerach() {

		String clientSearch = "jason";
		estimatorDao = new EstimatorDaoImpl();
		namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
		ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);

		RowCountDTO rowCount = new RowCountDTO();

		when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
				Mockito.<BeanPropertyRowMapper<RowCountDTO>>any())).thenReturn(rowCount);

		RowCountDTO response = estimatorDao.getRowCountClientSerach(clientSearch);

		assertEquals(rowCount, response);

	}

	@Test
	void testGetRowCountClientSerachError() {
		String dataError = "DataAccessException";
		try {
			String clientSearch = "jason";
			estimatorDao = new EstimatorDaoImpl();
			namedParameterJdbcTemplate = mock(NamedParameterJdbcTemplate.class);
			ReflectionTestUtils.setField(estimatorDao, "namedParameterJdbcTemplate", namedParameterJdbcTemplate);
			RowCountDTO rowCount = new RowCountDTO();

			when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.<MapSqlParameterSource>any(),
					Mockito.<BeanPropertyRowMapper<RowCountDTO>>any())).thenThrow(new DataAccessException(dataError) {
					}).thenReturn(rowCount);

			estimatorDao.getRowCountClientSerach(clientSearch);

		} catch (DataAccessException dataAccessException) {
			assertEquals(dataError, dataAccessException.getMessage());
		}
	}
}
