//package com.tm.test.controller;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyList;
//import static org.mockito.ArgumentMatchers.anySet;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.UUID;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.dao.DataAccessException;
//import org.springframework.test.util.ReflectionTestUtils;
//
//import com.tm.estimator.controller.ClientDetailsController;
//import com.tm.estimator.controller.EstimatorUserController;
//import com.tm.estimator.controller.QuestionOptionController;
//import com.tm.estimator.dto.ClientKeyDTO;
//import com.tm.estimator.dto.QuestionOptionDTO;
//import com.tm.estimator.dto.RequirementDetailsDTO;
//import com.tm.estimator.dto.RequirementInfoDTO;
//import com.tm.estimator.dto.ValuesDTO;
//import com.tm.estimator.enums.QuestionType;
//import com.tm.estimator.pojo.ClientDetailsPOJO;
//import com.tm.estimator.pojo.FetchClientDetailsPOJO;
//import com.tm.estimator.pojo.FetchRequirementPOJO;
//import com.tm.estimator.pojo.RequirementDetailsPOJO;
//import com.tm.estimator.pojo.ValuePOJO;
//import com.tm.estimator.pojo.request.EstimatorRequestPOJO;
//import com.tm.estimator.pojo.request.FetchClientDetailsRequestPOJO;
//import com.tm.estimator.pojo.request.FetchRequirementRequestPOJO;
//import com.tm.estimator.pojo.request.LogInRequestPOJO;
//import com.tm.estimator.pojo.request.SaveRequirementRequestPOJO;
//import com.tm.estimator.response.EstimatorResponsePOJO;
//import com.tm.estimator.service.EstimatorService;
//import com.tm.estimator.service.impl.EstimatorServiceImpl;
//
//@ExtendWith(MockitoExtension.class)
//class EstimatorClientControllerTest {
//
//	private EstimatorService estimatorService;
//
//	private ClientDetailsController clientDetailsController;
//
//	@Test
//	void testSaveClientDetailsWithResponseId() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//
//		EstimatorRequestPOJO estimatorRequestPOJO = new EstimatorRequestPOJO();
//
//		String response = "value";
//
////		when(estimatorService.saveClientDetails(estimatorRequestPOJO)).thenReturn(response);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.saveClientDetails(estimatorRequestPOJO);
//
//		assertEquals(response, responsePOJO.getResponseData());
//
//	}
//
//	@Test
//	void testSaveClientDetailsWithNullResponse() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//
//		EstimatorRequestPOJO estimatorRequestPOJO = new EstimatorRequestPOJO();
//
//		when(estimatorService.saveClientDetails(estimatorRequestPOJO)).thenReturn(null);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.saveClientDetails(estimatorRequestPOJO);
//
//		assertEquals(null, responsePOJO.getResponseData());
//
//	}
//
//	@Test
//	void testUserLoginError() {
//		String dataError = "DataAccessException";
//		try {
//			String valueString = "value";
//			EstimatorRequestPOJO estimatorRequestPOJO = new EstimatorRequestPOJO();
//			clientDetailsController = new ClientDetailsController();
//			estimatorService = mock(EstimatorServiceImpl.class);
//			ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
////			when(estimatorService.saveClientDetails(estimatorRequestPOJO))
////					.thenThrow(new DataAccessException(dataError) {
////					}).thenReturn(valueString);
//
//			clientDetailsController.saveClientDetails(estimatorRequestPOJO);
//		} catch (DataAccessException e) {
//			assertEquals(dataError, e.getMessage());
//		}
//
//	}
//
//	// TODO
//	@Test
//	void testFetchClientDetailsWithValue() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//		FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO = new FetchClientDetailsRequestPOJO();
//		fetchClientDetailsRequestPOJO.setLimit(10);
//		fetchClientDetailsRequestPOJO.setPageNo(1);
//		fetchClientDetailsRequestPOJO.setClientSearch(null);
//
//		FetchClientDetailsPOJO fetchClientDetailsPOJO = new FetchClientDetailsPOJO();
//		List<ClientDetailsPOJO> clientDetailsPOJOs = new ArrayList<>();
//		ClientDetailsPOJO clientDetailsPOJO = new ClientDetailsPOJO();
//		clientDetailsPOJO.setClientContact("46546456465");
//		clientDetailsPOJO.setClientId(UUID.randomUUID());
//		clientDetailsPOJO.setClientMailid("jason@gmail.com");
//		clientDetailsPOJO.setClientName("jason");
//		clientDetailsPOJO.setTotalCost("10");
//		clientDetailsPOJO.setTotalHours("10");
//		clientDetailsPOJOs.add(clientDetailsPOJO);
//		fetchClientDetailsPOJO.setClientDetails(clientDetailsPOJOs);
//		fetchClientDetailsPOJO.setRowCout(1);
//
//		when(estimatorService.fetchClientDetails(fetchClientDetailsRequestPOJO)).thenReturn(fetchClientDetailsPOJO);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.fetchClientDetails(fetchClientDetailsRequestPOJO);
//		assertEquals(true, responsePOJO.getIsSuccess());
//
//	}
//
//	// TODO
//	@Test
//	void testFetchClientDetailsWithNull() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//		FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO = new FetchClientDetailsRequestPOJO();
//		fetchClientDetailsRequestPOJO.setLimit(10);
//		fetchClientDetailsRequestPOJO.setPageNo(1);
//
//		FetchClientDetailsPOJO fetchClientDetailsPOJO = new FetchClientDetailsPOJO();
//
//		when(estimatorService.fetchClientDetails(fetchClientDetailsRequestPOJO)).thenReturn(fetchClientDetailsPOJO);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.fetchClientDetails(fetchClientDetailsRequestPOJO);
//		assertEquals(false, responsePOJO.getIsSuccess());
//
//	}
//
//	@Test
//	void testFetchClientDetailsWithPageLimitNull() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//		FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO = new FetchClientDetailsRequestPOJO();
//		fetchClientDetailsRequestPOJO.setClientSearch("");
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.fetchClientDetails(fetchClientDetailsRequestPOJO);
//		assertEquals(false, responsePOJO.getIsSuccess());
//
//	}
//
//	@Test
//	void testFetchClientDetailsWithSearchNull() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//		FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO = new FetchClientDetailsRequestPOJO();
//		fetchClientDetailsRequestPOJO.setLimit(10);
//		fetchClientDetailsRequestPOJO.setPageNo(1);
//		fetchClientDetailsRequestPOJO.setClientSearch(" ");
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.fetchClientDetails(fetchClientDetailsRequestPOJO);
//		assertEquals(false, responsePOJO.getIsSuccess());
//
//	}
//
//	@Test
//	void testFetchRequirementDetails() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//
//		List<ValuesDTO> value = new ArrayList<>();
//		ValuesDTO valuesDTO = new ValuesDTO();
//		valuesDTO.setCost(0);
//		valuesDTO.setHours(0);
//		valuesDTO.setOption("option");
//		valuesDTO.setOptionText("optionText");
//		value.add(valuesDTO);
//
//		List<RequirementDetailsDTO> requirementDetails = new ArrayList<>();
//		RequirementDetailsDTO requirementDetailsDTO = new RequirementDetailsDTO();
//		requirementDetailsDTO.setQuestion("question");
//		requirementDetailsDTO.setQuestionId(UUID.randomUUID());
//		requirementDetailsDTO.setQuestionType("CHECKBOX");
//		requirementDetailsDTO.setValue(value);
//		requirementDetails.add(requirementDetailsDTO);
//
//		FetchRequirementRequestPOJO requirementRequestPOJO = new FetchRequirementRequestPOJO();
//		RequirementInfoDTO requirementInfoDTO = new RequirementInfoDTO();
//
//		requirementInfoDTO.setTotalCost(1);
//		requirementInfoDTO.setTotalHours(10);
//		requirementInfoDTO.setRequirementDetails(requirementDetails);
//
//		when(estimatorService.clientIdValidate(requirementRequestPOJO.getClientId())).thenReturn(true);
//
//		when(estimatorService.fetchRequirementDetails(requirementRequestPOJO.getClientId()))
//				.thenReturn(requirementInfoDTO);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.fetchRequirementDetails(requirementRequestPOJO);
//		assertEquals(true, responsePOJO.getIsSuccess());
//
//	}
//
//	@Test
//	void testFetchRequirementDetailsWithNull() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//
//		FetchRequirementRequestPOJO requirementRequestPOJO = new FetchRequirementRequestPOJO();
//		RequirementInfoDTO requirementInfoDTO = new RequirementInfoDTO();
//
//		when(estimatorService.clientIdValidate(requirementRequestPOJO.getClientId())).thenReturn(true);
//
//		when(estimatorService.fetchRequirementDetails(requirementRequestPOJO.getClientId()))
//				.thenReturn(requirementInfoDTO);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.fetchRequirementDetails(requirementRequestPOJO);
//		assertEquals(false, responsePOJO.getIsSuccess());
//
//	}
//
//	@Test
//	void testFetchRequirementDetailsWithValidateFalse() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//
//		FetchRequirementRequestPOJO requirementRequestPOJO = new FetchRequirementRequestPOJO();
//
//		when(estimatorService.clientIdValidate(requirementRequestPOJO.getClientId())).thenReturn(false);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.fetchRequirementDetails(requirementRequestPOJO);
//		assertEquals(false, responsePOJO.getIsSuccess());
//
//	}
//
//	@Test
//	void testFetchRequirementDetailsWithError() {
//		String dataError = "DataAccessException";
//		try {
//			clientDetailsController = new ClientDetailsController();
//			estimatorService = mock(EstimatorServiceImpl.class);
//			ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//			FetchRequirementRequestPOJO requirementRequestPOJO = new FetchRequirementRequestPOJO();
//
//			when(estimatorService.clientIdValidate(requirementRequestPOJO.getClientId()))
//					.thenThrow(new DataAccessException(dataError) {
//					}).thenReturn(false);
//
//			clientDetailsController.fetchRequirementDetails(requirementRequestPOJO);
//
//		} catch (DataAccessException e) {
//			assertEquals(dataError, e.getMessage());
//		}
//
//	}
//
//	@Test
//	void testSaveClientRequirement() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//
//		SaveRequirementRequestPOJO saveRequirementRequestPOJO = new SaveRequirementRequestPOJO();
//		List<RequirementDetailsPOJO> requirementDetailsPOJOs = new ArrayList<>();
//		RequirementDetailsPOJO requirementDetailsPOJO = new RequirementDetailsPOJO();
//		List<ValuePOJO> valuePOJOs = new ArrayList<>();
//		ValuePOJO valuePOJO = new ValuePOJO();
//
//		valuePOJO.setCost(10);
//		valuePOJO.setHours(10);
//		valuePOJO.setOption("optionText");
//		valuePOJO.setOptionText("optionText");
//		valuePOJOs.add(valuePOJO);
//
//		requirementDetailsPOJO.setQuestion("question");
//		requirementDetailsPOJO.setQuestionId(UUID.randomUUID());
//		requirementDetailsPOJO.setQuestionType(QuestionType.CHECKBOX);
//		requirementDetailsPOJO.setValue(valuePOJOs);
//		requirementDetailsPOJOs.add(requirementDetailsPOJO);
//
//		saveRequirementRequestPOJO.setClientId(UUID.randomUUID());
//		saveRequirementRequestPOJO.setTotalCost(10);
//		saveRequirementRequestPOJO.setTotalHours(10);
//		saveRequirementRequestPOJO.setReqList(requirementDetailsPOJOs);
//
//		ClientKeyDTO clientKeyDTO = new ClientKeyDTO();
//		clientKeyDTO.setClientKey(1);
//		clientKeyDTO.setClientName("jason");
//
//		when(estimatorService.clientIdValidate(saveRequirementRequestPOJO.getClientId())).thenReturn(true);
//
//		when(estimatorService.saveClientRequirement(saveRequirementRequestPOJO, clientKeyDTO)).thenReturn(1);
//
//		when(estimatorService.fetchClientKey(saveRequirementRequestPOJO.getClientId())).thenReturn(clientKeyDTO);
//
//		when(estimatorService.isValidQuestion(anySet())).thenReturn(true);
//		when(estimatorService.isValidOption(anySet())).thenReturn(true);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.saveClientRequirement(saveRequirementRequestPOJO);
//		assertEquals(true, responsePOJO.getIsSuccess());
//
//	}
//
//	@Test
//	void testSaveClientRequirementWithNull() {
//		clientDetailsController = new ClientDetailsController();
//		estimatorService = mock(EstimatorServiceImpl.class);
//		ReflectionTestUtils.setField(clientDetailsController, "estimatorService", estimatorService);
//
//		SaveRequirementRequestPOJO saveRequirementRequestPOJO = new SaveRequirementRequestPOJO();
//		List<RequirementDetailsPOJO> requirementDetailsPOJOs = new ArrayList<>();
//		RequirementDetailsPOJO requirementDetailsPOJO = new RequirementDetailsPOJO();
//		List<ValuePOJO> valuePOJOs = new ArrayList<>();
//		ValuePOJO valuePOJO = new ValuePOJO();
//
//		valuePOJO.setCost(10);
//		valuePOJO.setHours(10);
//		valuePOJO.setOption("optionText");
//		valuePOJO.setOptionText("optionText");
//		valuePOJOs.add(valuePOJO);
//
//		requirementDetailsPOJO.setQuestion("question");
//		requirementDetailsPOJO.setQuestionId(UUID.randomUUID());
//		requirementDetailsPOJO.setQuestionType(QuestionType.CHECKBOX);
//		requirementDetailsPOJO.setValue(valuePOJOs);
//		requirementDetailsPOJOs.add(requirementDetailsPOJO);
//
//		saveRequirementRequestPOJO.setClientId(UUID.randomUUID());
//		saveRequirementRequestPOJO.setTotalCost(10);
//		saveRequirementRequestPOJO.setTotalHours(10);
//		saveRequirementRequestPOJO.setReqList(requirementDetailsPOJOs);
//
//		ClientKeyDTO clientKeyDTO = new ClientKeyDTO();
//		clientKeyDTO.setClientKey(1);
//		clientKeyDTO.setClientName("jason");
//
//		when(estimatorService.clientIdValidate(saveRequirementRequestPOJO.getClientId())).thenReturn(true);
//
//		when(estimatorService.saveClientRequirement(saveRequirementRequestPOJO, clientKeyDTO)).thenReturn(0);
//
//		when(estimatorService.fetchClientKey(saveRequirementRequestPOJO.getClientId())).thenReturn(clientKeyDTO);
//
//		when(estimatorService.isValidQuestion(anySet())).thenReturn(true);
//		when(estimatorService.isValidOption(anySet())).thenReturn(true);
//
//		EstimatorResponsePOJO responsePOJO = clientDetailsController.saveClientRequirement(saveRequirementRequestPOJO);
//		assertEquals(false, responsePOJO.getIsSuccess());
//
//	}
//
//}
