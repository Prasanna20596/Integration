package com.tm.test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessException;
import org.springframework.test.util.ReflectionTestUtils;
import com.tm.estimator.controller.EstimatorUserController;
import com.tm.estimator.pojo.request.LogInRequestPOJO;
import com.tm.estimator.response.EstimatorResponsePOJO;
import com.tm.estimator.service.EstimatorService;
import com.tm.estimator.service.impl.EstimatorServiceImpl;

@ExtendWith(MockitoExtension.class)
class EstimatorUserControllerTest {

	private EstimatorService estimatorService;

	private EstimatorUserController estimatorUserController;

	@Test
	void testUserLoginWithSuccess() {

		estimatorUserController = new EstimatorUserController();
		estimatorService = mock(EstimatorServiceImpl.class);
		ReflectionTestUtils.setField(estimatorUserController, "estimatorService", estimatorService);

		LogInRequestPOJO logInRequestPOJO = new LogInRequestPOJO();
		logInRequestPOJO.setUserName("jason");
		logInRequestPOJO.setUserPassword("jason@");

		when(estimatorService.userLogin(logInRequestPOJO)).thenReturn(true);

		EstimatorResponsePOJO responsePOJO = estimatorUserController.userLogin(logInRequestPOJO);

		assertEquals(true, responsePOJO.getIsSuccess());

	}

	@Test
	void testUserLoginWithoutSuccess() {

		estimatorUserController = new EstimatorUserController();
		estimatorService = mock(EstimatorServiceImpl.class);
		ReflectionTestUtils.setField(estimatorUserController, "estimatorService", estimatorService);

		LogInRequestPOJO logInRequestPOJO = new LogInRequestPOJO();
		logInRequestPOJO.setUserName("jason");
		logInRequestPOJO.setUserPassword("jason@");

		when(estimatorService.userLogin(logInRequestPOJO)).thenReturn(false);

		EstimatorResponsePOJO responsePOJO = estimatorUserController.userLogin(logInRequestPOJO);

		assertEquals(false, responsePOJO.getIsSuccess());

	}

	@Test
	void testUserLoginError() {
		String dataError = "DataAccessException";
		try {
			estimatorUserController = new EstimatorUserController();
			estimatorService = mock(EstimatorServiceImpl.class);
			ReflectionTestUtils.setField(estimatorUserController, "estimatorService", estimatorService);

			LogInRequestPOJO logInRequestPOJO = new LogInRequestPOJO();
			logInRequestPOJO.setUserName("jason");
			logInRequestPOJO.setUserPassword("jason@");

			when(estimatorService.userLogin(logInRequestPOJO)).thenThrow(new DataAccessException(dataError) {
			}).thenReturn(false);

			estimatorUserController.userLogin(logInRequestPOJO);
		} catch (DataAccessException e) {
			assertEquals(dataError, e.getMessage());
		}

	}

}
