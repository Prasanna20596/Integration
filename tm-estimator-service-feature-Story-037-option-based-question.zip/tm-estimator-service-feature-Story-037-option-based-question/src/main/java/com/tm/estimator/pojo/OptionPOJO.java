package com.tm.estimator.pojo;

/**
 * This class represents a POJO (Plain Old Java Object) for an option in the
 * Estimator application.
 * 
 * @author TTS-503-balavignesh
 */
public class OptionPOJO {

	private String optionId;
	private String optionText;
	private String image;
	private int optionOrder;
	private int optionHours;
	private Boolean isOptionAll;
	private int cost;
	private String jumpTo;
	private String optionGroupId;

	public String getOptionGroupId() {
		return optionGroupId;
	}

	public void setOptionGroupId(String optionGroupId) {
		this.optionGroupId = optionGroupId;
	}

	public String getJumpTo() {
		return jumpTo;
	}

	public void setJumpTo(String jumpTo) {
		this.jumpTo = jumpTo;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public Boolean getIsOptionAll() {
		return isOptionAll;
	}

	public void setIsOptionAll(Boolean isOptionAll) {
		this.isOptionAll = isOptionAll;
	}

	public int getOptionHours() {
		return optionHours;
	}

	public void setOptionHours(int optionHours) {
		this.optionHours = optionHours;
	}

	public int getOptionOrder() {
		return optionOrder;
	}

	public void setOptionOrder(int optionOrder) {
		this.optionOrder = optionOrder;
	}

	public String getOptionText() {
		return optionText;
	}

	public String getImage() {
		return image;
	}

	public void setOptionText(String optionText) {
		this.optionText = optionText;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getOptionId() {
		return optionId;
	}

	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}

}
