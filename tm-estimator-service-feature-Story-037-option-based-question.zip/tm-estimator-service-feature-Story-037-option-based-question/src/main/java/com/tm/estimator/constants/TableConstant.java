package com.tm.estimator.constants;

/**
 * This constant class is used for store column name of table
 * 
 * @author TTS-503-balavignesh
 */
public class TableConstant {

	private TableConstant() {
		super();
	}

	public static final String CLIENT_NAME = "client_details.client_name";
	public static final String CLIENT_MAIL = "client_details.client_mailid";
	public static final String CLIENT_CREATED_AT="client_details.createdAt";

}
