package com.tm.estimator.pojo;

import java.util.List;

public class FetchRequirementPOJO {

	private List<RequirementQuestionPOJO> requirementQuestionPOJO;

	public List<RequirementQuestionPOJO> getRequirementQuestionPOJO() {
		return requirementQuestionPOJO;
	}

	public void setRequirementQuestionPOJO(List<RequirementQuestionPOJO> requirementQuestionPOJO) {
		this.requirementQuestionPOJO = requirementQuestionPOJO;
	}

}
