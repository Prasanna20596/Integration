package com.tm.estimator.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tm.estimator.constants.MessageConstants;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.pojo.OptionPOJO;
import com.tm.estimator.pojo.QuestionDetailsPOJO;
import com.tm.estimator.pojo.request.QuestionCreationRequestPOJO;
import com.tm.estimator.response.EstimatorResponsePOJO;
import com.tm.estimator.service.EstimatorService;

/**
 * This class represents questions option controller and provides basic function
 * of fetch the questions and its option from the database
 * 
 * @author TTS-503-balavignesh
 *
 */
//@CrossOrigin(origins = { "http://tts.webredirect.org:84/", "http://localhost:4200/" })
@RestController
@RequestMapping(value = "/questions")
public class QuestionOptionController {

	@Autowired
	private EstimatorService estimatorService;

	private static final Logger LOGGER = LoggerFactory.getLogger(QuestionOptionController.class);

	/**
	 * This API is used to fetch the questions and option from the database
	 * 
	 * @return EstimatorResponsePOJO The response object indicating the result of
	 *         the operation.
	 */
	@PostMapping("/fetchQuestionOption")
	public EstimatorResponsePOJO fetchQuestionOption() {
		LOGGER.info("Fetch the Question and option details");
		EstimatorResponsePOJO estimatorResponsePOJO = new EstimatorResponsePOJO();
		List<QuestionDetailsPOJO> questionDetailsList = new ArrayList<>();
		try {
			List<QuestionOptionDTO> questionOptionDTOList = estimatorService.fetchQuestionDetails();
			if (!CollectionUtils.isEmpty(questionOptionDTOList)) {
				LOGGER.info("QuestionOption value isNotEmpty");
				// From QuestionOptionDTO list Group by using the questions code
				Map<Integer, List<QuestionOptionDTO>> collectList = questionOptionDTOList.stream()
						.collect(Collectors.groupingBy(QuestionOptionDTO::getQuestionKey));
				for (Map.Entry<Integer, List<QuestionOptionDTO>> entry : collectList.entrySet()) {
					List<QuestionOptionDTO> valueList = entry.getValue();
					ObjectMapper objectMapper = new ObjectMapper();
					// deserilaizaition feature mapping the value with its corresponding
					objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
					QuestionDetailsPOJO questionDetailsPOJO = objectMapper.convertValue(valueList.get(0),
							QuestionDetailsPOJO.class);
					// if the questions type is datepicker than the option should not required
					if (!questionDetailsPOJO.getQuestionType().equals(MessageConstants.DATEPICKER)) {
						List<OptionPOJO> optionPOJOList = objectMapper.convertValue(valueList,
								new TypeReference<List<OptionPOJO>>() {
								});
						LOGGER.info("QuestionType is not DATEPICKER");
						questionDetailsPOJO.setOptions(optionPOJOList);
					}
					questionDetailsList.add(questionDetailsPOJO);
				}
				LOGGER.debug("Question And option Details:{}", questionDetailsList);
				estimatorResponsePOJO.response(MessageConstants.QUESTION_OPTION_DETAILS, questionDetailsList, true);
			} else {
				LOGGER.error(MessageConstants.DATABASE_ERROR);
				estimatorResponsePOJO.response(MessageConstants.DATABASE_ERROR, false);
			}
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
			estimatorResponsePOJO.errorResponse(MessageConstants.NOTVALIDREQUEST);
		}
		LOGGER.debug("Question And option Details:{}", estimatorResponsePOJO);
		return estimatorResponsePOJO;
	}

	/**
	 * This API is used to update the question and the options details and
	 * corresponding transaction table insert will be done.
	 * 
	 * @param questionCreationRequestPOJO
	 * @return EstimatorResponsePOJO
	 */
	@PostMapping("/updateQuestionOptionDetails")
	public EstimatorResponsePOJO updateQuestionOptionDetails(
			@RequestBody QuestionCreationRequestPOJO questionCreationRequestPOJO) {
		LOGGER.info("updateQuestionOptionDetails API in controller");
		EstimatorResponsePOJO estimatorResponsePOJO = new EstimatorResponsePOJO();
		try {
			if (estimatorService.updateQuestionDetails(questionCreationRequestPOJO)) {
				LOGGER.info("updateQuestionOptionDetails is updated successfully");
				estimatorResponsePOJO.response("Update successfully", true);
			} else {
				LOGGER.info("updateQuestionOptionDetails is not updated");
				estimatorResponsePOJO.response(MessageConstants.NOTVALIDREQUEST, false);
			}
		} catch (Exception e) {
			LOGGER.info("Exception occurs while updating the question option Details");
			estimatorResponsePOJO.response(MessageConstants.NOTVALIDREQUEST, false);
		}
		LOGGER.debug("updateQuestionOptionDetails response controller:{}", estimatorResponsePOJO);
		return estimatorResponsePOJO;
	}

}
