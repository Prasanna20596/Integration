package com.tm.estimator.pojo;

import java.util.List;

/**
 * This class is response for fetch client Details
 * 
 * @author TTS-503-balavignesh
 */
public class FetchClientDetailsPOJO {

	private int rowCout;
	private List<ClientDetailsPOJO> clientDetails;

	public int getRowCout() {
		return rowCout;
	}

	public List<ClientDetailsPOJO> getClientDetails() {
		return clientDetails;
	}

	public void setRowCout(int rowCout) {
		this.rowCout = rowCout;
	}

	public void setClientDetails(List<ClientDetailsPOJO> clientDetails) {
		this.clientDetails = clientDetails;
	}

}
