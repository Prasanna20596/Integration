package com.tm.estimator.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tm.estimator.constants.MessageConstants;
import com.tm.estimator.dto.FetchRequirementDTO;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.dto.RequirementIdDTO;
import com.tm.estimator.pojo.ClientIdPOJO;
import com.tm.estimator.pojo.FetchClientDetailsPOJO;
import com.tm.estimator.pojo.FetchRequirementPOJO;
import com.tm.estimator.pojo.OptionPOJO;
import com.tm.estimator.pojo.QuestionDetailsPOJO;
import com.tm.estimator.pojo.RequirementQuestionPOJO;
import com.tm.estimator.pojo.RequirementPOJO;
import com.tm.estimator.pojo.request.EstimatorRequestPOJO;
import com.tm.estimator.pojo.request.FetchClientDetailsRequestPOJO;
import com.tm.estimator.pojo.request.FetchRequirementRequestPOJO;
import com.tm.estimator.pojo.request.SaveRequirementRequestPOJO;
import com.tm.estimator.response.EstimatorResponsePOJO;
import com.tm.estimator.service.EstimatorService;
import com.tm.estimator.utils.DataConvertion;

/**
 * This class represents client details controller and provides basic function
 * of save client details and fetch the client details
 * 
 * @author TTS-503-balavignesh
 */
@CrossOrigin(origins = { "http://tts.webredirect.org:84/", "http://localhost:4200/" })
@RestController
@RequestMapping(value = "/client")
public class ClientDetailsController {

	@Autowired
	private EstimatorService estimatorService;

	private static final Logger LOGGER = LoggerFactory.getLogger(ClientDetailsController.class);

	/**
	 * This API is used to save the client details
	 * 
	 * @param estimatorRequestPOJO
	 * @return EstimatorResponsePOJO The response object indicating the result of
	 *         the operation.
	 */
	@PostMapping("/saveClientDetails")
	public EstimatorResponsePOJO saveClientDetails(@RequestBody @Valid EstimatorRequestPOJO estimatorRequestPOJO) {
		LOGGER.info("Save the Client Details");
		EstimatorResponsePOJO estimatorResponsePOJO = new EstimatorResponsePOJO();
		try {
			ClientIdPOJO clientIdPOJO = estimatorService.saveClientDetails(estimatorRequestPOJO);
			if (Objects.nonNull(clientIdPOJO)) {
				estimatorResponsePOJO.response(MessageConstants.SAVECLIENTDETAILS, clientIdPOJO, true);
				LOGGER.info(MessageConstants.SAVECLIENTDETAILS);
			} else {
				LOGGER.error(MessageConstants.CLIENT_DETAILS_ERROR);
				estimatorResponsePOJO.response(MessageConstants.CLIENT_DETAILS_ERROR, false);
			}
		} catch (Exception exception) {
			estimatorResponsePOJO.errorResponse(MessageConstants.NOTVALIDREQUEST);
		}
		LOGGER.debug("SaveClientDetails Controller:{}", estimatorResponsePOJO);
		return estimatorResponsePOJO;
	}

	/**
	 * This API is used to fetch the client details from the database
	 * 
	 * @return EstimatorResponsePOJO The response object indicating the result of
	 *         the operation.
	 */
	@PostMapping("/fetchClientDetails")
	public EstimatorResponsePOJO fetchClientDetails(
			@RequestBody @Valid FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO) {
		LOGGER.info("Fetch Client Details Controller");
		EstimatorResponsePOJO estimatorResponsePOJO = new EstimatorResponsePOJO();
		try {
			if (isValidateFetchDetails(fetchClientDetailsRequestPOJO)) {
				FetchClientDetailsPOJO fetchClientDetailsPOJO = estimatorService
						.fetchClientDetails(fetchClientDetailsRequestPOJO);
				if (!Objects.isNull(fetchClientDetailsPOJO)
						&& !CollectionUtils.isEmpty(fetchClientDetailsPOJO.getClientDetails())) {
					estimatorResponsePOJO.response("Client Details", fetchClientDetailsPOJO, true);
					LOGGER.info(MessageConstants.CLIENTDETAILSRETURNED);
				} else {
					LOGGER.error(MessageConstants.CLIENT_TABLE_NO_DATA);
					estimatorResponsePOJO.response(MessageConstants.CLIENT_TABLE_NO_DATA, false);
				}
			} else {
				LOGGER.error(MessageConstants.NOTVALIDREQUEST);
				estimatorResponsePOJO.errorResponse(MessageConstants.NOTVALIDREQUEST);
			}
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
			estimatorResponsePOJO.errorResponse(MessageConstants.NOTVALIDREQUEST);
		}
		LOGGER.debug("FetchClientDetails Controller:{}", estimatorResponsePOJO.getResponseData());
		return estimatorResponsePOJO;
	}

	/**
	 * This method is used to validate the fetchClientRequestPojo
	 * 
	 * @param fetchClientDetailsPOJO
	 * @return boolean
	 */
	private boolean isValidateFetchDetails(FetchClientDetailsRequestPOJO fetchClientDetailsPOJO) {
		boolean isValid = true;
		if (fetchClientDetailsPOJO.getLimit() == 0 || fetchClientDetailsPOJO.getPageNo() == 0) {
			isValid = false;
		} else if (StringUtils.hasText(fetchClientDetailsPOJO.getClientSearch())) {
			// fetchClientDetailsPOJO.getClientSearch().trim().isEmpty()
			if (fetchClientDetailsPOJO.getClientSearch().trim().isEmpty()) {
				LOGGER.error("Client is search field");
				isValid = false;
			} else {
				LOGGER.info("Client is valid");
			}
		}
		return isValid;
	}

	/**
	 * This API is used to save the client Requirement in database
	 * 
	 * @param saveRequirementRequestPOJO
	 * @return EstimatorResponsePOJO The response object indicating the result of
	 *         the operation.
	 */
	@PostMapping("/saveClientRequirement")
	public EstimatorResponsePOJO saveClientRequirement(
			@RequestBody SaveRequirementRequestPOJO saveRequirementRequestPOJO) {
		LOGGER.info("Save client Requirement controller");
		String debugString = DataConvertion.convertJson(saveRequirementRequestPOJO);
		LOGGER.debug("save clientRequirement request:{}", debugString);
		EstimatorResponsePOJO estimatorResponsePOJO = new EstimatorResponsePOJO();
		List<QuestionDetailsPOJO> questionDetailsList = new ArrayList<>();
		try {
			if (estimatorService.clientIdValidate(saveRequirementRequestPOJO.getClientId())) {
				LOGGER.info("Valid Client Details");	
				List<QuestionOptionDTO> questionOptionDTOList = estimatorService.saveClientRequirement(
						saveRequirementRequestPOJO,
						estimatorService.fetchClientKey(saveRequirementRequestPOJO.getClientId()));
				if (!CollectionUtils.isEmpty(questionOptionDTOList)) {
					LOGGER.info("QuestionOption value isNotEmpty");
					// From QuestionOptionDTO list Group by using the questions code
					Map<Integer, List<QuestionOptionDTO>> collectList = questionOptionDTOList.stream()
							.collect(Collectors.groupingBy(QuestionOptionDTO::getQuestionKey));
					for (Map.Entry<Integer, List<QuestionOptionDTO>> entry : collectList.entrySet()) {
						List<QuestionOptionDTO> valueList = entry.getValue();
						ObjectMapper objectMapper = new ObjectMapper();
						// deserilaizaition feature mapping the value with its corresponding
						objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
						QuestionDetailsPOJO questionDetailsPOJO = objectMapper.convertValue(valueList.get(0),
								QuestionDetailsPOJO.class);
						// if the questions type is datepicker than the option should not required
						if (!questionDetailsPOJO.getQuestionType().equals(MessageConstants.DATEPICKER)) {
							List<OptionPOJO> optionPOJOList = objectMapper.convertValue(valueList,
									new TypeReference<List<OptionPOJO>>() {
									});
							LOGGER.info("QuestionType is not DATEPICKER");
							questionDetailsPOJO.setOptions(optionPOJOList);
						}
						questionDetailsList.add(questionDetailsPOJO);
					}
					LOGGER.debug("Question And option Details:{}", questionDetailsList);
					estimatorResponsePOJO.response(MessageConstants.QUESTION_OPTION_DETAILS, questionDetailsList, true);
				} else {
					LOGGER.error("Flow Completed");
					estimatorResponsePOJO.response("Flow completed", true);
				}
			} else {
				LOGGER.error(MessageConstants.PROPERCLIENT);
				estimatorResponsePOJO.errorResponse(MessageConstants.PROPERCLIENT);
			}
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
			estimatorResponsePOJO.errorResponse(MessageConstants.NOTVALIDREQUEST);
		}
		LOGGER.debug("Save clientDetails Controller:{}", estimatorResponsePOJO);
		return estimatorResponsePOJO;
	}

	/**
	 * This API is used to fetch the requirement details of client from database
	 * 
	 * @param requirementRequestPOJO
	 * @return EstimatorResponsePOJO The response object indicating the result of
	 *         the operation.
	 */
	@PostMapping("/fetchRequirementDetails")
	public EstimatorResponsePOJO fetchRequirementDetails(
			@RequestBody FetchRequirementRequestPOJO requirementRequestPOJO) {
		LOGGER.info("Fetch Requirement Details Controller");
		String debugString = DataConvertion.convertJson(requirementRequestPOJO);
		LOGGER.debug("FetchRequirement Request:{}", debugString);
		EstimatorResponsePOJO estimatorResponsePOJO = new EstimatorResponsePOJO();
		try {
			if (estimatorService.clientIdValidate(requirementRequestPOJO.getClientId())) {
				RequirementPOJO requirementPOJO = estimatorService
						.fetchRequirementDetails(requirementRequestPOJO.getClientId());
				FetchRequirementPOJO fetchRequirementPOJO = fetchRequirement(requirementPOJO);
				estimatorResponsePOJO.response("Requirement Details", fetchRequirementPOJO, true);
			} else {
				LOGGER.error(MessageConstants.PROPERCLIENT);
				estimatorResponsePOJO.errorResponse(MessageConstants.PROPERCLIENT);
			}
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
			estimatorResponsePOJO.errorResponse(MessageConstants.NOTVALIDREQUEST);
		}
		LOGGER.debug("Fetch Requirement Details Controller:{}", estimatorResponsePOJO.getResponseData());
		return estimatorResponsePOJO;
	}

	private FetchRequirementPOJO fetchRequirement(RequirementPOJO requirementPOJO) {
		FetchRequirementPOJO fetchRequirementPOJO = new FetchRequirementPOJO();
		List<RequirementQuestionPOJO> questionPojoList = new ArrayList<>();
		Map<String, List<RequirementIdDTO>> collectList = requirementPOJO.getRequirementIdDTOs().stream()
				.collect(Collectors.groupingBy(RequirementIdDTO::getClientRequirementGroupId));
		Map<String, List<FetchRequirementDTO>> collectListss = requirementPOJO.getFetchRequirementDTOs().stream()
				.collect(Collectors.groupingBy(FetchRequirementDTO::getGroupId));
		for (Map.Entry<String, List<RequirementIdDTO>> entry : collectList.entrySet()) {
			RequirementQuestionPOJO question = new RequirementQuestionPOJO();
			List<OptionPOJO> optionsPOJOs = new ArrayList<>();
			for (RequirementIdDTO requirementId : entry.getValue()) {
				List<FetchRequirementDTO> aString = collectListss.get(requirementId.getGroupId());
				question.setQuestion(aString.get(0).getQuestion());
				question.setClientGroupId(requirementId.getClientRequirementGroupId());
				OptionPOJO optionPOJO = new OptionPOJO();
				for (FetchRequirementDTO fetchRequirement : aString) {
					if (requirementId.getOptionId().equals(fetchRequirement.getOptionId())
							&& requirementId.getGroupId().equals(fetchRequirement.getGroupId())) {
						optionPOJO.setOptionText(fetchRequirement.getOptionText());
					}
				}
				optionsPOJOs.add(optionPOJO);
			}
			question.setOptions(optionsPOJOs);
			questionPojoList.add(question);
		}
		fetchRequirementPOJO.setRequirementQuestionPOJO(questionPojoList);
		return fetchRequirementPOJO;
	}
}
