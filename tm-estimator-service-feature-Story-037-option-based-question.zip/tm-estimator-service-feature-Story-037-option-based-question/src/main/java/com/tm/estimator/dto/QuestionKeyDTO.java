package com.tm.estimator.dto;

public class QuestionKeyDTO {

	private int questionKey;
	private int optionOrder;

	public int getQuestionKey() {
		return questionKey;
	}

	public void setQuestionKey(int questionKey) {
		this.questionKey = questionKey;
	}

	public int getOptionOrder() {
		return optionOrder;
	}

	public void setOptionOrder(int optionOrder) {
		this.optionOrder = optionOrder;
	}

}
