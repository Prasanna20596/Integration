package com.tm.estimator.validation;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.tm.estimator.response.EstimatorResponsePOJO;

/**
 * Global exception handler for handling validation exceptions in the Estimator
 * application. This class uses Spring's `@RestControllerAdvice` to provide
 * centralized exception handling for MethodArgumentNotValidException
 * (validation errors).
 * 
 * @author TTS-503-balavignesh
 */
@RestControllerAdvice
public class ExpectionValidation {
	/**
	 * Exception handler for MethodArgumentNotValidException (validation errors).
	 * This method responds with a custom EstimatorResponsePOJO containing
	 * validation error details.
	 * 
	 * @param ex The MethodArgumentNotValidException that occurred.
	 * @return EstimatorResponsePOJO containing validation error details.
	 */
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public EstimatorResponsePOJO handleValidationExceptions(MethodArgumentNotValidException ex) {
		EstimatorResponsePOJO responsePOJO = new EstimatorResponsePOJO();
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors()
				.forEach(error -> errors.put(((FieldError) error).getField(), error.getDefaultMessage()));
		responsePOJO.setMessage("Not Valid Request");
		responsePOJO.setResponseData(errors);
		responsePOJO.setIsSuccess(false);
		return responsePOJO;
	}
}
