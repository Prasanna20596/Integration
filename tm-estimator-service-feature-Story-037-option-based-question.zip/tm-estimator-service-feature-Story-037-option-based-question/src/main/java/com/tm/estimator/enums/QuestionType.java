package com.tm.estimator.enums;

/**
 * This is enum class which has the Question Types
 * 
 * @author TTS-503-balavignesh
 */
public enum QuestionType {

	CHECKBOX, RANGE, DATEPICKER, RADIOBUTTON
}
