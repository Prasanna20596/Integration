package com.tm.estimator.constants;

/**
 * his class contains constants representing various messages used in the
 * Estimator application.It provides messages related to saving client details,
 * error messages, field names, and more.
 * 
 * @author TTS-503-balavignesh
 */
public class MessageConstants {

	private MessageConstants() {
		super();
	}

	public static final String SAVECLIENTDETAILS = "Details Saved successfully";
	public static final String QUESTION_OPTION_DETAILS = "Question AND OPTION DETAILS";
	public static final String DATABASE_ERROR = "NO DATA IN CLIENT DETAILS";
	public static final String CLIENT_DETAILS_ERROR = "NOT A VALID DETAILS";
	public static final String NOTVALIDREQUEST = "Please give valid request";
	public static final String CLIENTNAME = "clientName";
	public static final String CLIENTMAILID = "clientMailid";
	public static final String CLIENTCONTACT = "clientContact";
	public static final String CLIENT_TABLE_NO_DATA = "NO DATA IN CLIENT DETAILS";
	public static final String CREATEDBY = "createdBy";
	public static final Object DATEPICKER = "DATEPICKER";
	public static final String REGEX = "^[+0-9()\\s-]*$";
	public static final String NOTVALIDNUMBER = "NOT VALID NUMBER";
	public static final String CLIENTDETAILSRETURNED = "fetched all client details";
	public static final String CLIENTID = "clientId";
	public static final String IS_SAVED = "isSaved";
	public static final String CLIENTKEY = "clientKey";
	public static final String REQUIREMENT = "requirementDetails";
	public static final String PROPERCLIENT = "NOT VALID CLIENT DETAILS";
	public static final String REQUIREMENT_FETCH_ERROR = "Fetch Requirement details failed";
	public static final String SAVEREQUIREMENT_VALID = "Request Data is not valid";
	public static final String QUESTIONID = "questionId";
	public static final String OPTIONID = "optionId";
	public static final String TOTALCOST = "totalCost";
	public static final String TOTALHOURS = "totalHours";
	public static final String OFFSET = "offset";
	public static final String LIMIT = "limit";
	public static final String CLIENT_SEARCH = "clientSearch";
	public static final String SORTINGBY = "sortingBy";
	public static final String SORTBY = "sortBy";
	public static final String SORTINGKEY = "CLIENTCREATEDAT";
	public static final String SORTINGKEYBY = "DESC";
	public static final String USERNAME = "userName";
	public static final String USERPASSWORD="userPassword";
	public static final String CLIENT_GROUP_ID = "clientGroupId";
	public static final String GROUP_ID = "groupId";
	public static final String OPTION_ID = "optionId";

}