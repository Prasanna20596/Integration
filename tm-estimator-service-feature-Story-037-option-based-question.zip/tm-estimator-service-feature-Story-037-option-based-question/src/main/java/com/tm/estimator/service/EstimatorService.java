package com.tm.estimator.service;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.tm.estimator.dto.ClientKeyDTO;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.pojo.ClientIdPOJO;
import com.tm.estimator.pojo.FetchClientDetailsPOJO;
import com.tm.estimator.pojo.RequirementPOJO;
import com.tm.estimator.pojo.request.EstimatorRequestPOJO;
import com.tm.estimator.pojo.request.FetchClientDetailsRequestPOJO;
import com.tm.estimator.pojo.request.SaveRequirementRequestPOJO;
import com.tm.estimator.pojo.request.LogInRequestPOJO;
import com.tm.estimator.pojo.request.QuestionCreationRequestPOJO;

/**
 * This interface defines the contract for the Estimator service. It provides
 * methods to fetch questions and option details, save client details, and fetch
 * client details. Implementations of this interface will provide specific
 * behavior for these operations.
 * 
 * 
 * @author TTS-503-balavignesh
 *
 */
@Service
public interface EstimatorService {

	/**
	 * This method Fetch All the Question and option details
	 * 
	 * @return List<QuestionOptionDTO> this will return QuestionOptionDTO list
	 */
	public List<QuestionOptionDTO> fetchQuestionDetails();

	/**
	 * This method is used to save the client details and return if success or not
	 * 
	 * @param estimatorRequestPOJO
	 * @return Integer
	 */
	public ClientIdPOJO saveClientDetails(EstimatorRequestPOJO estimatorRequestPOJO);

	/**
	 * Fetching the Client Details from database
	 * 
	 * @param FetchClientDetailsRequestPOJO
	 * @return FetchClientDetailsPOJO
	 */
	public FetchClientDetailsPOJO fetchClientDetails(FetchClientDetailsRequestPOJO fetchClientDetailsRequestPOJO);

	/**
	 * This method is used to fetch the clientKey using the clientId
	 * 
	 * @param clientId
	 * @return ClientKeyDTO
	 */
	public ClientKeyDTO fetchClientKey(UUID clientId);

	/**
	 * This method is used to save the client Requirement
	 * 
	 * @param requirementRequestPOJO
	 * @param clientKeyDTO
	 * @return Interger
	 */
	public List<QuestionOptionDTO> saveClientRequirement(SaveRequirementRequestPOJO requirementRequestPOJO, ClientKeyDTO clientKeyDTO);

	/**
	 * This method is used to fetch the client requirement
	 * 
	 * @param clientId
	 * @return RequirementInfoDTO
	 */
	public RequirementPOJO fetchRequirementDetails(UUID clientId);

	/**
	 * This method is used to validate the clientId
	 * 
	 * @param clientId
	 * @return boolean
	 */
	public boolean clientIdValidate(UUID clientId);

	/**
	 * This method is used to validate the questionId
	 * 
	 * @param questionIdSet
	 * @return boolean
	 */
	public boolean isValidQuestion(Set<UUID> questionIdSet);

	/**
	 * This method is used to validate the optionId
	 * 
	 * @param optionId
	 * @return boolean
	 */
	public boolean isValidOption(Set<String> optionId);

	/**
	 * This method is used to validate the username and password
	 * 
	 * @param logInRequestPOJO
	 * @return boolean
	 */
	public boolean userLogin(LogInRequestPOJO logInRequestPOJO);

	public boolean updateQuestionDetails(QuestionCreationRequestPOJO questionCreationRequestPOJO);


}
