package com.tm.estimator.pojo;

import java.util.List;

/**
 * This class represents a POJO (Plain Old Java Object) for an option in the
 * Estimator application.
 * 
 * @author TTS-503-balavignesh
 */
public class QuestionDetailsPOJO {

	private int questionOrder;
	private String question;
	private int maxSelection;
	private String questionType;
	private Boolean isSkippable;
	private String questionId;
	List<OptionPOJO> options;

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public int getQuestionOrder() {
		return questionOrder;
	}

	public void setQuestionOrder(int questionOrder) {
		this.questionOrder = questionOrder;
	}

	public Boolean getIsSkippable() {
		return isSkippable;
	}

	public void setIsSkippable(Boolean isSkippable) {
		this.isSkippable = isSkippable;
	}

	public String getQuestion() {
		return question;
	}

	public int getMaxSelection() {
		return maxSelection;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public void setMaxSelection(int maxSelection) {
		this.maxSelection = maxSelection;
	}

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public List<OptionPOJO> getOptions() {
		return options;
	}

	public void setOptions(List<OptionPOJO> options) {
		this.options = options;
	}

}
