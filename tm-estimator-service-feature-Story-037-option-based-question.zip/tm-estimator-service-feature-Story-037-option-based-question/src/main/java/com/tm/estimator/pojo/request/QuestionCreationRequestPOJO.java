package com.tm.estimator.pojo.request;

import java.util.List;

import com.tm.estimator.pojo.QuestionDetailsPOJO;

public class QuestionCreationRequestPOJO {

	List<QuestionDetailsPOJO> questions;

	public List<QuestionDetailsPOJO> getQuestions() {
		return questions;
	}

	public void setQuestions(List<QuestionDetailsPOJO> questions) {
		this.questions = questions;
	}

}
