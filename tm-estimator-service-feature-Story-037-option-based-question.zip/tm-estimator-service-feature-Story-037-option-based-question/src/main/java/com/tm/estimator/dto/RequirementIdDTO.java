package com.tm.estimator.dto;


public class RequirementIdDTO {

	private String questionId;
	private String optionId;
	private String groupId;
	private String clientRequirementGroupId;

	public String getOptionId() {
		return optionId;
	}

	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getClientRequirementGroupId() {
		return clientRequirementGroupId;
	}

	public void setClientRequirementGroupId(String clientRequirementGroupId) {
		this.clientRequirementGroupId = clientRequirementGroupId;
	}

}
