package com.tm.estimator.dao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.tm.estimator.constants.EstimatorQueryConstant;
import com.tm.estimator.constants.MessageConstants;
import com.tm.estimator.constants.TableConstant;
import com.tm.estimator.dao.EstimatorDao;
import com.tm.estimator.dto.ClientDTO;
import com.tm.estimator.dto.ClientDetailsDTO;
import com.tm.estimator.dto.ClientKeyDTO;
import com.tm.estimator.dto.FetchRequirementDTO;
import com.tm.estimator.dto.QuestionKeyDTO;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.dto.RequirementIdDTO;
import com.tm.estimator.dto.RowCountDTO;
import com.tm.estimator.enums.OrderByColumns;
import com.tm.estimator.enums.SortBy;
import com.tm.estimator.pojo.request.EstimatorRequestPOJO;
import com.tm.estimator.pojo.request.LogInRequestPOJO;
import com.tm.estimator.pojo.request.SaveRequirementRequestPOJO;

/**
 * Implementation of the EstimatorDao interface that provides functionality to
 * access and manipulate data related to the Estimator service in the database.
 * 
 * @author TTS-503-balavignesh
 */
@Service
public class EstimatorDaoImpl implements EstimatorDao {

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private static final Logger LOGGER = LoggerFactory.getLogger(EstimatorDaoImpl.class);

	/**
	 * This Method Fetch the Question and option in database
	 * 
	 * @return List<QuestionOptionDTO> this will return QuestionOptionDTO list
	 */
	@Override
	public List<QuestionOptionDTO> fetchQuestionDetails() {
		LOGGER.info("Fetch the Question Details in DAO");
		List<QuestionOptionDTO> questionOptionList = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			questionOptionList = namedParameterJdbcTemplate.query(EstimatorQueryConstant.FETCH_QUESTION_OPTION_DETAILS,
					mapSqlParameterSource, BeanPropertyRowMapper.newInstance(QuestionOptionDTO.class));
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			LOGGER.error("An error occurred while fetching questions and option Details in DAO layer");
			throw dataAccessException;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("An error occurred while fetching questions and option Details in DAO layer");
		}
		LOGGER.debug("FetchQuestionDetails ResponseDAO:{}", questionOptionList);
		return questionOptionList;
	}

	/**
	 * This method will save the client details in the database
	 * 
	 * @param estimatorRequestPOJO
	 * @return Integer
	 */
	@Override
	public Integer saveClientDetails(EstimatorRequestPOJO estimatorRequestPOJO, String clientId, String clientGroupId) {
		LOGGER.info("Client details saving processing in DAO layer");
		Integer response = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.CLIENTNAME, estimatorRequestPOJO.getClientName().trim());
			mapSqlParameterSource.addValue(MessageConstants.CLIENTMAILID,
					estimatorRequestPOJO.getClientMailId().trim());
			mapSqlParameterSource.addValue(MessageConstants.CLIENTCONTACT,
					estimatorRequestPOJO.getContactNumber().trim());
			mapSqlParameterSource.addValue(MessageConstants.CREATEDBY, estimatorRequestPOJO.getClientName());
			mapSqlParameterSource.addValue(MessageConstants.CLIENTID, clientId);
			mapSqlParameterSource.addValue("clientReqGroupId", clientGroupId);
			response = namedParameterJdbcTemplate.update(EstimatorQueryConstant.INSERT_CLIENT_DETAILS,
					mapSqlParameterSource);
			LOGGER.info("Saved Client Details");
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			LOGGER.error("An error occurred while saving the client details in database in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("saveClientDetails ResponseDAO:{}", response);
		return response;
	}

	/**
	 * This method is used to fetch the client details
	 * 
	 * @param limit
	 * @param offset
	 * @param sortingBy
	 * @param sortBy
	 * @return List<ClientDetailsDTO> A list of client details retrieved from the
	 *         database.
	 */
	public List<ClientDetailsDTO> fetchClientDetails(int limit, int offset, OrderByColumns sortingBy, SortBy sortBy) {
		LOGGER.info("Fetching the Client Details");
		List<ClientDetailsDTO> responseList = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.LIMIT, limit);
			mapSqlParameterSource.addValue(MessageConstants.OFFSET, offset);
			String formattedQuery = String.format(EstimatorQueryConstant.FETCHCLIENTDETAILS, columnDetails(sortingBy),
					sortBy.toString());
			responseList = namedParameterJdbcTemplate.query(formattedQuery, mapSqlParameterSource,
					BeanPropertyRowMapper.newInstance(ClientDetailsDTO.class));
			LOGGER.info("Fetched all client Details from database");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while fetching Client Details in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("fetchClientDetails ResponseDAO:{}", responseList);
		return responseList;

	}

	/**
	 * This method is used to client Details search from database using clientName
	 * or clientMailId of pagination used limit and offset
	 * 
	 * @param limit
	 * @param offset
	 * @param clientSearch
	 * @return List<ClientDetailsDTO>
	 */
	@Override
	public List<ClientDetailsDTO> clientSearch(int limit, int offset, String clientSearch) {
		LOGGER.info("clientSearch in DAO");
		List<ClientDetailsDTO> responseList = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.LIMIT, limit);
			mapSqlParameterSource.addValue(MessageConstants.OFFSET, offset);
			mapSqlParameterSource.addValue(MessageConstants.CLIENT_SEARCH, clientSearch);
			responseList = namedParameterJdbcTemplate.query(EstimatorQueryConstant.CLIENT_SEARCH, mapSqlParameterSource,
					BeanPropertyRowMapper.newInstance(ClientDetailsDTO.class));
			LOGGER.info("Fetched all client Details by clientSearch from database");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while fetching Client Details as clientSearch in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("clientSearch ResponseDAO:{}", responseList);
		return responseList;

	}

	/**
	 * This method is used to fetch the clientKey from db using clientId
	 * 
	 * @param clientId
	 * @return ClientKeyDTO
	 */
	@Override
	public ClientKeyDTO fetchClientKey(UUID clientId) {
		LOGGER.info("Fetching the ClientKey using clientId in dao layer");
		ClientKeyDTO clientKeyDTO;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.CLIENTID, clientId.toString());
			clientKeyDTO = namedParameterJdbcTemplate.queryForObject(EstimatorQueryConstant.FETCH_CLIENT_KEY,
					mapSqlParameterSource, BeanPropertyRowMapper.newInstance(ClientKeyDTO.class));
			LOGGER.info("Fetched the ClientKey using clientId in dao layer");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while fetching ClientKey using clientId in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("fetchClientKey in ResponseDAO:{}", clientKeyDTO);
		return clientKeyDTO;
	}

	/**
	 * This method is used to save the clientRequirement in database
	 * 
	 * @param clientKeyDTO
	 * @param requirementDetailsPOJO
	 * @param totalCost
	 * @param totalHours
	 * @return Integer
	 */
	@Override
	public boolean saveClientRequirement(SaveRequirementRequestPOJO saveRequirementRequestPOJO,
			ClientKeyDTO clientKeyDTO) {
		LOGGER.info("saveClientRequirement in dao layer execution");
		boolean allUpdated = false;
		try {
			List<MapSqlParameterSource> mapSqlParameterSourcesList = new ArrayList<>();
			for (UUID optionId : saveRequirementRequestPOJO.getOptionId()) {
				MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
				mapSqlParameterSource.addValue(MessageConstants.CLIENTKEY, clientKeyDTO.getClientKey());
				mapSqlParameterSource.addValue(MessageConstants.CREATEDBY, clientKeyDTO.getClientName());
				mapSqlParameterSource.addValue(MessageConstants.QUESTIONID,
						saveRequirementRequestPOJO.getQuestionId().toString());
				mapSqlParameterSource.addValue(MessageConstants.OPTIONID, optionId.toString());
				mapSqlParameterSource.addValue("updatedBy", clientKeyDTO.getClientKey());
				mapSqlParameterSource.addValue("clientRequirementGroupId",
						saveRequirementRequestPOJO.getClientGroupId().toString());
				mapSqlParameterSource.addValue(MessageConstants.GROUP_ID,
						saveRequirementRequestPOJO.getGroupId().toString());
				mapSqlParameterSourcesList.add(mapSqlParameterSource);
			}
			int[] response = namedParameterJdbcTemplate.batchUpdate(EstimatorQueryConstant.INSERT_CLIENT_REQUIREMENT,
					mapSqlParameterSourcesList.toArray(new MapSqlParameterSource[0]));

			allUpdated = Arrays.stream(response).noneMatch(i -> i == 0);

			LOGGER.info("saveClientRequirement in database processed in dao layer");
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			LOGGER.error("An error occurred while fetching ClientKey using clientId in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("SaveClientRequirement in ResponseDAO:{}", allUpdated);
		return allUpdated;
	}

	/**
	 * This method is used to fetch the requirement details from database
	 * 
	 * @param clientId
	 * @return RequirementInfoDTO
	 */
	public List<RequirementIdDTO> fetchRequirementDetails(UUID clientId) {
		LOGGER.info("fetchRequirementDetails in dao layer execution");
		List<RequirementIdDTO> requirementIdDTO = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.CLIENTID, clientId.toString());
			requirementIdDTO = namedParameterJdbcTemplate.query(EstimatorQueryConstant.FETCH_ID_REQUIREMENT,
					mapSqlParameterSource, BeanPropertyRowMapper.newInstance(RequirementIdDTO.class));
			LOGGER.info("fetchRequirementDetails in database processed in dao layer");
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			LOGGER.error("An error occurred while fetching client Requirement in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("SaveClientRequirement in ResponseDAO:{}", requirementIdDTO);
		return requirementIdDTO;
	}

	/**
	 * This method is used to validate the clientId in database
	 *
	 * @param clientId
	 * @return boolean
	 */
	@Override
	public boolean clientIdValidate(UUID clientId) {
		LOGGER.info("ClientId validate in Dao layer execution");
		boolean isValidClientId = false;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.CLIENTID, clientId.toString());
			Integer countInt = namedParameterJdbcTemplate.queryForObject(EstimatorQueryConstant.CLIENT_ID_VALIDATE,
					mapSqlParameterSource, Integer.class);
			isValidClientId = countInt != null && countInt > 0;
			LOGGER.info("checked the clientId in db");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while clientId validating in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("clientIdValidate in ResponseDAO:{}", isValidClientId);
		return isValidClientId;
	}

	/**
	 * This method is used to validate the questionId in database
	 * 
	 * @param questionIdSet
	 * @return boolean
	 */
	@Override
	public boolean isValidQuestion(Set<String> questionIdSet) {
		LOGGER.info("isValid questionOption in Dao layer execution");
		boolean isValidQuestion = false;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.QUESTIONID, questionIdSet);
			Integer countInt = namedParameterJdbcTemplate.queryForObject(EstimatorQueryConstant.IS_VALID_QUESTION,
					mapSqlParameterSource, Integer.class);
			isValidQuestion = countInt != null && countInt == questionIdSet.size();
			LOGGER.info("isValidQuestion is validated in database");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while validating isValidQuestionOption in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("isValidQuestion in ResponseDAO:{}", isValidQuestion);
		return isValidQuestion;
	}

	/**
	 * This method is used to validate the optionId in database
	 * 
	 * @param optionId
	 * @retrun boolean
	 */
	@Override
	public boolean isValidOption(Set<String> optionId) {
		LOGGER.info("isValid questionOption in Dao layer execution");
		boolean isValidOption = false;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.OPTIONID, optionId);
			Integer countInt = namedParameterJdbcTemplate.queryForObject(EstimatorQueryConstant.IS_VALID_OPTION,
					mapSqlParameterSource, Integer.class);
			isValidOption = countInt != null && countInt == optionId.size();
			LOGGER.info("isValidOption in checked in database");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while validating isValidQuestionOption in DAO layer");
			throw dataAccessException;
		}
		LOGGER.debug("isValidQuestion in ResponseDAO:{}", isValidOption);
		return isValidOption;
	}

	/**
	 * This method is used to get row count in db of clientDetails
	 * 
	 * @return RowCountDTO
	 */
	@Override
	public RowCountDTO getRowCountClientDetails() {
		LOGGER.info("getRowCount of clientDetails in DAO layer execution");
		RowCountDTO rowCount = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			rowCount = namedParameterJdbcTemplate.queryForObject(EstimatorQueryConstant.COUNT_OF_CLIENTDETAILS,
					mapSqlParameterSource, BeanPropertyRowMapper.newInstance(RowCountDTO.class));
			LOGGER.info("getRowCount is fetched from database");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred getting row count of clientDetails in DAO layer");
			throw dataAccessException;
		}
		return rowCount;

	}

	/**
	 * This method is used to count the total record of the clientSearch of client
	 * Details
	 * 
	 * @param clientSearch
	 * @return RowCountDTO
	 */
	@Override
	public RowCountDTO getRowCountClientSerach(String clientSearch) {
		LOGGER.info("getRowCountClientSerach of clientDetails in DAO layer execution");
		RowCountDTO rowCount = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.CLIENT_SEARCH, clientSearch);
			rowCount = namedParameterJdbcTemplate.queryForObject(EstimatorQueryConstant.ROW_COUNT_CLIENT_SEARCH,
					mapSqlParameterSource, BeanPropertyRowMapper.newInstance(RowCountDTO.class));
			LOGGER.info("getRowCountClientSerach is fetched from database");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred getting row count of countClientSerach in DAO layer");
			throw dataAccessException;
		}
		return rowCount;

	}

	/**
	 * This method is used to getColumn for properties using enums from request
	 * 
	 * @param orderByColumns
	 * @return String
	 */
	private String columnDetails(OrderByColumns orderByColumns) {
		LOGGER.info("columnDetails using properties in service layer");
		String sortingBy = null;
		if (OrderByColumns.CLIENTNAME.equals(orderByColumns)) {
			sortingBy = TableConstant.CLIENT_NAME;
		} else if (OrderByColumns.CLIENTMAIL.equals(orderByColumns)) {
			sortingBy = TableConstant.CLIENT_MAIL;
		} else if (OrderByColumns.CLIENTCREATEDAT.equals(orderByColumns)) {
			sortingBy = TableConstant.CLIENT_CREATED_AT;
		}
		LOGGER.debug("Fetch columnDetails: Service response :{}", sortingBy);
		return sortingBy;
	}

	/**
	 * This method is used to validate the user and password
	 *
	 * @param logInRequestPOJO
	 * @return Boolean
	 */
	@Override
	public Boolean userLogin(LogInRequestPOJO logInRequestPOJO) {
		LOGGER.info("userLogin method in dao layer");
		boolean isValid = false;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.USERNAME, logInRequestPOJO.getUserName());
			mapSqlParameterSource.addValue(MessageConstants.USERPASSWORD, logInRequestPOJO.getUserPassword());
			Integer countInt = namedParameterJdbcTemplate.queryForObject(EstimatorQueryConstant.VALIDATEUSER,
					mapSqlParameterSource, Integer.class);
			isValid = countInt != null && countInt > 0;
			LOGGER.info("validated the user");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while userLogin in dao layer");
			throw dataAccessException;
		}
		return isValid;
	}

	/**
	 * This method is used to update the option details as batch update
	 * 
	 * @param batchParametersOption
	 * @return int[]
	 */
	@Override
	public int[] updateOptionDetails(List<MapSqlParameterSource> batchParametersOption) {
		LOGGER.info("Update the optionDetails in Dao layer");
		int[] isValid = null;
		try {
			String sqlOption = "CALL update_option_details(:optionId,:optionText,:image,:optionOrder,:optionHours,:isOptionAll,:cost,:jumpTo,:optionGroupId)";
			isValid = namedParameterJdbcTemplate.batchUpdate(sqlOption,
					batchParametersOption.toArray(new MapSqlParameterSource[0]));
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while updateOptionDetails in dao layer");
			throw dataAccessException;
		}
		return isValid;
	}

	/**
	 * This method is used to update the question details as batch update
	 * 
	 * @param batchParametersOption
	 * @return int[]
	 */
	@Override
	public int[] updateQuestionDetails(List<MapSqlParameterSource> batchParametersQuestion) {
		LOGGER.info("Update the QuestionDetails in Dao layer");
		int[] isValid = null;
		try {
			String sqlQuestion = "CALL update_question_details(:questionId, :question, :maxSelection,:questionType,:questionOrder,:isSkippable,:questionGroupId)";
			isValid = namedParameterJdbcTemplate.batchUpdate(sqlQuestion,
					batchParametersQuestion.toArray(new MapSqlParameterSource[0]));
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while updateQuestionDetails in dao layer");
			throw dataAccessException;
		}
		return isValid;
	}

	/**
	 * This method is used to insert the question details value to the transaction
	 * table of it
	 *
	 * @param questionIdSet
	 * @retrun int
	 */
	@Override
	public int insertQuestionDetails(Set<String> questionIdSet, String groupId) {
		LOGGER.info("insertQuestionDetails in Dao layer");
		Integer isValid = 0;
		try {
			String sql = "Insert into question_transaction(question,max_selection,question_type,question_order,isDeleted,is_skippable,question_group_id,is_based_on_previous,question_key,createdBy,updatedBy,group_id) SELECT question,max_selection,question_type,question_order,isDeleted,is_skippable,question_group_id,is_based_on_previous,question_key,createdBy,updatedBy,:groupId from estimate_questions";
			MapSqlParameterSource questionMapSqlParameterSource = new MapSqlParameterSource();
			questionMapSqlParameterSource.addValue("questionId", questionIdSet);
			questionMapSqlParameterSource.addValue(MessageConstants.GROUP_ID, groupId);
			isValid = namedParameterJdbcTemplate.update(sql, questionMapSqlParameterSource);
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while insertQuestionDetails in dao layer");
			throw dataAccessException;
		}
		return isValid;
	}

	/**
	 * This method is used to insert the option details value to the transaction
	 * table of it
	 *
	 * @param optionIdSet
	 * @retrun int
	 */
	@Override
	public int insertOptionDetails(Set<String> optionIdSet, String groupId) {
		LOGGER.info("insertOptionDetails in Dao layer");
		Integer isValid = 0;
		try {
			String sql = "INSERT INTO option_transaction (option_id,option_text,image,option_order,option_hours,question_key,isOptionAll,cost,option_group_id,createdBy,updatedBy,jump_to,group_id) SELECT option_id,option_text,image,option_order,option_hours,question_key,isOptionAll, cost,option_group_id,createdBy,updatedBy,jump_to,:groupId from question_options";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.OPTION_ID, optionIdSet);
			mapSqlParameterSource.addValue(MessageConstants.GROUP_ID, groupId);
			isValid = namedParameterJdbcTemplate.update(sql, mapSqlParameterSource);
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while insertQuestionDetails in dao layer");
			throw dataAccessException;
		}
		return isValid;
	}

	@Override
	public Boolean isClientPresents(String clientMailId, String contactNumber) {
		boolean isValidClientId = false;
		try {
			String sql = "select count(*) from client_details where client_mailid=:clientMailId and client_contact=:contactNumber";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue("clientMailId", clientMailId);
			mapSqlParameterSource.addValue("contactNumber", contactNumber);
			Integer countInt = namedParameterJdbcTemplate.queryForObject(sql, mapSqlParameterSource, Integer.class);
			isValidClientId = countInt != null && countInt > 0;
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			LOGGER.error("An error occurred while isClientPresents in dao layer");
			throw dataAccessException;
		}
		return isValidClientId;
	}

	@Override
	public ClientDTO updateClientDetails(String clientMailId, String contactNumber) {
		ClientDTO clientDTO = null;
		try {
			MapSqlParameterSource mapSqlParameterSource;
			String clientGroupId = UUID.randomUUID().toString();
			String sql = "update client_details set client_requirement_group_id =:clientReqGroupId where client_mailid=:clientMailId and client_contact=:contactNumber";
			mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue("clientMailId", clientMailId);
			mapSqlParameterSource.addValue("contactNumber", contactNumber);
			mapSqlParameterSource.addValue("clientReqGroupId", clientGroupId);
			int count = namedParameterJdbcTemplate.update(sql, mapSqlParameterSource);
			if (count > 0) {
				String fetchClientId = "select client_id,client_requirement_group_id from client_details where client_mailid=:clientMailId and client_contact=:contactNumber";
				clientDTO = namedParameterJdbcTemplate.queryForObject(fetchClientId, mapSqlParameterSource,
						BeanPropertyRowMapper.newInstance(ClientDTO.class));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return clientDTO;
	}

	@Override
	public List<FetchRequirementDTO> fetchQuestionOptionByIds(Set<String> questionIdSet, Set<String> optionIdSet,
			Set<String> groupIdSet) {
		List<FetchRequirementDTO> fetchRequirementDTOs = null;
		try {
			String sql = "select qt.question,ot.option_text,ot.option_hours,ot.cost,qt.question_id,ot.option_id,qt.group_id from question_transaction as qt inner join option_transaction as ot on qt.question_key=ot.question_key where question_id in(:questionId) and option_id in (:optionId) and qt.group_id in (:groupId) and isDeleted=false";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue("questionId", questionIdSet.stream().collect(Collectors.toSet()));
			mapSqlParameterSource.addValue(MessageConstants.OPTION_ID,
					optionIdSet.stream().collect(Collectors.toSet()));
			mapSqlParameterSource.addValue("groupId", groupIdSet.stream().collect(Collectors.toSet()));
			fetchRequirementDTOs = namedParameterJdbcTemplate.query(sql, mapSqlParameterSource,
					BeanPropertyRowMapper.newInstance(FetchRequirementDTO.class));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fetchRequirementDTOs;
	}

	@Override
	public int updateGroupId(String groupId) {
		Integer isValid = 0;
		try {
			String sql = "Insert into group_update(group_id,createdBy,updatedBy)  values (:groupId,'ADMIN','ADMIN')";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue("groupId", groupId);
			isValid = namedParameterJdbcTemplate.update(sql, mapSqlParameterSource);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isValid;
	}

	@Override
	public Integer isValidGroupId(String groupId) {
		Integer isValid = null;
		try {
			String sql = "select count(*) from group_update where group_id=:groupId";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.GROUP_ID, groupId);
			isValid = namedParameterJdbcTemplate.queryForObject(sql, mapSqlParameterSource, Integer.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isValid;
	}

	@Override
	public int deleteRequirements(String clientGroupId) {
		int response = 0;
		try {
			String sql = "update client_requirement set isDeleted=true where client_requirement_group_id=:clientGroupId";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.CLIENT_GROUP_ID, clientGroupId);
			response = namedParameterJdbcTemplate.update(sql, mapSqlParameterSource);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public List<QuestionOptionDTO> fetchOptionBaseQuestions() {
		List<QuestionOptionDTO> questionOptionDTOs = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue("questionOrder", 1);
			// DTO check
			questionOptionDTOs = namedParameterJdbcTemplate.query(EstimatorQueryConstant.FETCH_QUESTION_OPTION_BY_ORDER,
					mapSqlParameterSource, BeanPropertyRowMapper.newInstance(QuestionOptionDTO.class));
			LOGGER.info("Fetched QuestionOption from database");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questionOptionDTOs;
	}

	@Override
	public List<QuestionKeyDTO> fetchJumpToByOptionId(Set<String> optionId) {
		List<QuestionKeyDTO> questionKeyDTOs = null;
		try {
			String sql = "SELECT DISTINCT question_key, MAX(option_order) AS option_order FROM (SELECT jump_to AS question_key, option_order FROM question_options WHERE option_id IN (:optionId) AND jump_to IS NOT NULL AND option_order IS NOT NULL) AS subquery GROUP BY question_key ORDER BY option_order DESC";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.OPTION_ID, optionId);
			// DTO check
			questionKeyDTOs = namedParameterJdbcTemplate.query(sql, mapSqlParameterSource,
					BeanPropertyRowMapper.newInstance(QuestionKeyDTO.class));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questionKeyDTOs;
	}

	@Override
	public boolean insertReturnQuestions(String clientId, String clientGroupId, Set<Integer> questionKeys,
			boolean isReturned) {
		boolean isUpdatedAll = false;
		try {
			List<MapSqlParameterSource> mapSqlParameterSourcesList = new ArrayList<>();
			String sql = "Insert into return_questions(client_id,client_group_id,question_key,isReturned) values(:clientId,:clientGroupId,:questionKey,:isReturned)";
			for (int questionKey : questionKeys) {
				MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
				mapSqlParameterSource.addValue("clientId", clientId);
				mapSqlParameterSource.addValue(MessageConstants.CLIENT_GROUP_ID, clientGroupId);
				mapSqlParameterSource.addValue("questionKey", questionKey);
				mapSqlParameterSource.addValue("isReturned", isReturned);
				mapSqlParameterSourcesList.add(mapSqlParameterSource);
			}
			int[] response = namedParameterJdbcTemplate.batchUpdate(sql,
					mapSqlParameterSourcesList.toArray(new MapSqlParameterSource[0]));

			isUpdatedAll = Arrays.stream(response).noneMatch(i -> i == 0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isUpdatedAll;
	}

	@Override
	public Integer fetchNextJumpTo(String clientGroupId) {
		int questionKeyDTOs = 0;
		try {
			String sql = "select question_key from return_questions where client_group_id =:clientGroupId and isReturned = false order by return_id desc limit 1";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.CLIENT_GROUP_ID, clientGroupId);
			// DTO check
			Integer result = namedParameterJdbcTemplate.queryForObject(sql, mapSqlParameterSource, Integer.class);
			questionKeyDTOs = Objects.requireNonNull(result, "Query nextJumpTo result is null");
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		return questionKeyDTOs;
	}

	@Override
	public int isReturnedUpdate(String clientGroupId) {
		Integer isValid = 0;
		try {
			String sql = "update return_questions set isReturned=true where client_group_id=:clientGroupId and isReturned=false order by return_id desc limit 1";
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue(MessageConstants.CLIENT_GROUP_ID, clientGroupId);
			isValid = namedParameterJdbcTemplate.update(sql, mapSqlParameterSource);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isValid;
	}

	@Override
	public List<QuestionOptionDTO> fetchQuestionOptionById(int questionKey) {
		List<QuestionOptionDTO> questionOptionDTOs = null;
		try {
			MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
			mapSqlParameterSource.addValue("questionKey", questionKey);
			// DTO check
			questionOptionDTOs = namedParameterJdbcTemplate.query(EstimatorQueryConstant.FETCH_QUESTION_OPTION_BY_KEY,
					mapSqlParameterSource, BeanPropertyRowMapper.newInstance(QuestionOptionDTO.class));
			LOGGER.info("Fetched QuestionOption from database");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questionOptionDTOs;
	}

}