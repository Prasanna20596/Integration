package com.tm.estimator.dto;

/**
 * This DTO class is used to get the clientKey and clientName using clientId
 * 
 * @author TTS-503-balavignesh
 */
public class ClientKeyDTO {

	private int clientKey;
	private String clientName;

	public String getClientName() {
		return clientName;
	}

	public int getClientKey() {
		return clientKey;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setClientKey(int clientKey) {
		this.clientKey = clientKey;
	}
}
