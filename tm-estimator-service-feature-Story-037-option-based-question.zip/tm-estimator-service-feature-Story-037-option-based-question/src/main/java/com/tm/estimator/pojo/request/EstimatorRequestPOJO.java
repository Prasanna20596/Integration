package com.tm.estimator.pojo.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * This class represents a request POJO for the Estimator application. It
 * contains fields for client name, contact number, and client email address,
 * with corresponding validation annotations for data validation.
 * 
 * @author TTS-503-balavignesh
 */
public class EstimatorRequestPOJO {

	// The maximum size of the Name should be 50
	// Null and only white space will not allow
	@NotBlank(message = "Enter the Name")
	@Size(max = 50)
	@Pattern(regexp = "^[a-zA-Z_ ]{2,50}$", message = "username must be of 2 to 50 length with no special characters and numbers")
	private String clientName;

	// The maximum size of the number should be 20 and minimum 7
	// Null and only white space will not allow
	@NotBlank(message = "Enter the Number")
	@Size(min = 7, max = 20)
	// using the PATTERN and REGEX validating the phone number of the client
	// space,Hyphen,Opening and closing parentheses,plus sign and Any numerical
	// digit from 0 to 9 are allowed
	@Pattern(regexp = "^[+0-9()\\\\s-]*$", message = "Invalid phone number format")
	private String contactNumber;

	// The maximum size of the email should be 50
	// null and only white space will not allow
	// spring email validation is added if i did't use '@' in the email it will
	// throw exception
	// In the end email should endwith eg: .com (or).org
	// It may check for the presence of special characters in the domain, ensuring
	// they are properly escaped.
	@NotBlank(message = "Enter the MailId")
	@Email(message = "Enter Proper Mail")
	@Size(max = 50)
	@Pattern(regexp = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", message = "Invalid email format")
	private String clientMailId;

	public String getClientName() {
		return clientName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getClientMailId() {
		return clientMailId;
	}

	public void setClientMailId(String clientMailId) {
		this.clientMailId = clientMailId;
	}

}
