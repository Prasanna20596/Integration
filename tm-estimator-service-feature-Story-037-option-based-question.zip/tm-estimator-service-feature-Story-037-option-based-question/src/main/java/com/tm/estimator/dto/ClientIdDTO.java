package com.tm.estimator.dto;

public class ClientIdDTO {

	private String clientId;
	private String clientRequirementGroupId;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientRequirementGroupId() {
		return clientRequirementGroupId;
	}

	public void setClientRequirementGroupId(String clientRequirementGroupId) {
		this.clientRequirementGroupId = clientRequirementGroupId;
	}

}
