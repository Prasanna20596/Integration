package com.tm.estimator.dto;

import java.util.UUID;

public class RequirementDTO {

	private UUID questionId;
	private UUID optionId;
	private String question;
	private String optionText;
	private String questionType;
	
	

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public UUID getQuestionId() {
		return questionId;
	}

	public UUID getOptionId() {
		return optionId;
	}

	public String getQuestion() {
		return question;
	}

	public String getOptionText() {
		return optionText;
	}

	public void setQuestionId(UUID questionId) {
		this.questionId = questionId;
	}

	public void setOptionId(UUID optionId) {
		this.optionId = optionId;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public void setOptionText(String optionText) {
		this.optionText = optionText;
	}

}
