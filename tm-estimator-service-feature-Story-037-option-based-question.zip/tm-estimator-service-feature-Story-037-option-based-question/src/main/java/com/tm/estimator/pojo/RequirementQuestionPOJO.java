package com.tm.estimator.pojo;

import java.util.List;

public class RequirementQuestionPOJO {

	private String clientGroupId;
	private String question;
	private List<OptionPOJO> options;

	public String getClientGroupId() {
		return clientGroupId;
	}

	public void setClientGroupId(String clientGroupId) {
		this.clientGroupId = clientGroupId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public List<OptionPOJO> getOptions() {
		return options;
	}

	public void setOptions(List<OptionPOJO> options) {
		this.options = options;
	}

}
