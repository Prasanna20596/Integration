package com.tm.estimator.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.GsonBuilder;

public class DataConvertion {

	private DataConvertion() {
		super();
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(DataConvertion.class);

	/**
	 * This method is convert the request into json
	 *
	 * @param object
	 * @return String
	 */
	public static String convertJson(Object object) {
		LOGGER.info("Convert Request pojo to json in service layer execution");
		String responseString = null;
		try {
			responseString = new GsonBuilder().create().toJson(object);
			LOGGER.info("Request Pojo object is converted in to json");
		} catch (Exception exception) {
			LOGGER.error("An error occurred while converting request pojo to json");
			throw exception;
		}
		LOGGER.debug("Convert the request pojos into json :{}", responseString);
		return responseString;
	}
}
