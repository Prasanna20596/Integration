package com.tm.estimator.dto;

public class QuestionIdDTO {

	private int questionKey;
	private String questionId;

	public int getQuestionKey() {
		return questionKey;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionKey(int questionKey) {
		this.questionKey = questionKey;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

}
