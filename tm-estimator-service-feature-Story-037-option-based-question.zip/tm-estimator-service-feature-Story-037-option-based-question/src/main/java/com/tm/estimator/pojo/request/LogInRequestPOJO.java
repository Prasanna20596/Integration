package com.tm.estimator.pojo.request;

import javax.validation.constraints.NotBlank;

/**
 * This class is used to get request from user for validate the user and
 * password
 * 
 * @author TTS-503-balavignesh
 */
public class LogInRequestPOJO {

	@NotBlank(message = "Please Enter User Name")
	private String userName;
	@NotBlank(message = "Please Enter User Password")
	private String userPassword;

	public String getUserName() {
		return userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

}
