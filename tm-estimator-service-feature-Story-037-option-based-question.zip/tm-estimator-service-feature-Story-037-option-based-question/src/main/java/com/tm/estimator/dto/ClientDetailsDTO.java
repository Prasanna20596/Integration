package com.tm.estimator.dto;

import java.util.UUID;

/**
 * This class represents a DTO (Data Transfer Object) for a question and its
 * associated options in the Estimator application.
 * 
 * @author TTS-503-balavignesh
 */
public class ClientDetailsDTO {

	private UUID clientId;
	private String clientMailid;
	private String clientName;
	private String clientContact;
	private Integer totalCost;
	private Integer totalHours;

	public UUID getClientId() {
		return clientId;
	}

	public String getClientMailid() {
		return clientMailid;
	}

	public String getClientName() {
		return clientName;
	}

	public String getClientContact() {
		return clientContact;
	}

	public Integer getTotalCost() {
		return totalCost;
	}

	public Integer getTotalHours() {
		return totalHours;
	}

	public void setClientId(UUID clientId) {
		this.clientId = clientId;
	}

	public void setClientMailid(String clientMailid) {
		this.clientMailid = clientMailid;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setClientContact(String clientContact) {
		this.clientContact = clientContact;
	}

	public void setTotalCost(Integer totalCost) {
		this.totalCost = totalCost;
	}

	public void setTotalHours(Integer totalHours) {
		this.totalHours = totalHours;
	}

}
