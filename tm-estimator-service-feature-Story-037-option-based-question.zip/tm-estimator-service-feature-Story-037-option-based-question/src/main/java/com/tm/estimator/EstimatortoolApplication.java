package com.tm.estimator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class EstimatortoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstimatortoolApplication.class, args);
	}

}
