package com.tm.estimator.dto;


import com.tm.estimator.pojo.OptionPOJO;

/**
 * This class represents a DTO (Data Transfer Object) for a questions and its
 * associated options in the Estimator application.
 * 
 * @author TTS-503-balavignesh
 */
public class QuestionOptionDTO extends OptionPOJO {

	private String questionId;
	private String question;
	private int maxSelection;
	private String questionType;
	private Boolean isSkippable;
	private String optionDescription;
	private int questionOrder;
	private int questionKey;
	private String questionGroupId;



	public String getQuestionGroupId() {
		return questionGroupId;
	}

	public void setQuestionGroupId(String questionGroupId) {
		this.questionGroupId = questionGroupId;
	}

	public int getQuestionKey() {
		return questionKey;
	}

	public void setQuestionKey(int questionKey) {
		this.questionKey = questionKey;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestion() {
		return question;
	}

	public int getMaxSelection() {
		return maxSelection;
	}

	public String getQuestionType() {
		return questionType;
	}

	public Boolean getIsSkippable() {
		return isSkippable;
	}

	public String getOptionDescription() {
		return optionDescription;
	}

	public int getQuestionOrder() {
		return questionOrder;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public void setMaxSelection(int maxSelection) {
		this.maxSelection = maxSelection;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public void setIsSkippable(Boolean isSkippable) {
		this.isSkippable = isSkippable;
	}

	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}

	public void setQuestionOrder(int questionOrder) {
		this.questionOrder = questionOrder;
	}

}
