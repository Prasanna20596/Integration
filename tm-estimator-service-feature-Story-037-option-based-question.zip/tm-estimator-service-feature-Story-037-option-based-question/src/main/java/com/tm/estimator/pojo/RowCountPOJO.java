package com.tm.estimator.pojo;

/**
 * This class is to transfer data from DAO to POJO
 * 
 * @author TTS-503-balavignesh
 */
public class RowCountPOJO {

	private int rowCount;

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

}
