package com.tm.estimator.constants;

/**
 * This class contains constants representing SQL queries related to the
 * Estimator application. It provides queries for inserting client details and
 * fetching questions and option details.
 * 
 * @author TTS-503-balavignesh
 */
public class EstimatorQueryConstant {

	private EstimatorQueryConstant() {
		super();
	}

	public static final String INSERT_CLIENT_DETAILS = "INSERT INTO client_details(client_name, client_contact, client_mailid,client_id,createdBy,client_requirement_group_id) VALUES (:clientName, :clientContact, :clientMailid,:clientId,:createdBy,:clientReqGroupId)";

	public static final String FETCH_QUESTION_OPTION_DETAILS = "SELECT  estimate_questions.question_key,estimate_questions.question_id,estimate_questions.question,estimate_questions.max_selection,estimate_questions.question_order,estimate_questions.is_skippable,question_options.option_id,question_options.option_text,question_options.image,question_type.question_type,question_options.option_order,question_options.option_hours,question_options.isOptionAll,question_options.cost,question_options.jump_to from estimate_questions inner join question_options on estimate_questions.question_key=question_options.question_key inner join question_type on estimate_questions.question_type=question_type.type_id order by estimate_questions.question_order asc,question_options.option_order asc";

	public static final String FETCHCLIENTDETAILS = "SELECT client_details.client_key,client_id,client_name,client_contact,client_mailid,total_cost,total_hours  FROM client_details LEFT JOIN client_requirement on client_details.client_key=client_requirement.client_key ORDER BY %s %s LIMIT :limit OFFSET :offset";

	public static final String COUNT_OF_CLIENTDETAILS = "select count(*) as rowCount from client_details";

	public static final String INSERT_CLIENT_REQUIREMENT = "Insert into client_requirement(client_key,createdBy,updatedBy,client_requirement_group_id,question_id,option_id,group_id) values (:clientKey,:createdBy,:updatedBy,:clientRequirementGroupId,:questionId,:optionId,:groupId)";

	public static final String FETCH_CLIENT_KEY = "select client_key,client_name from client_details where client_id = :clientId";

	public static final String FETCHQUESTION_BY_OPTION_QUERY = "select estimate_questions.question_type,estimate_questions.question,question_options.option_text,estimate_questions.question_id,question_options.option_id from estimate_questions left join question_options on estimate_questions.question_key=question_options.question_key where question_options.option_id IN(:optionId)or estimate_questions.question_type=3";

	public static final String FETCH_ID_REQUIREMENT = "select question_id,option_id,group_id,client_requirement.client_requirement_group_id from client_details inner join client_requirement on client_details.client_key=client_requirement.client_key where client_id=:clientId ORDER BY client_requirement.updatedAt DESC";

	public static final String CLIENT_ID_VALIDATE = "select count(*) from client_details where client_id=:clientId";

	public static final String IS_VALID_QUESTION = "select count(*) from estimate_questions where estimate_questions.question_id IN(:questionId)";

	public static final String IS_VALID_OPTION = "select count(*) from question_options where question_options.option_id IN(:optionId)";

	public static final String CLIENT_SEARCH = "SELECT client_details.client_key,client_id,client_name,client_contact,client_mailid,total_cost,total_hours  FROM client_details LEFT JOIN client_requirement on client_details.client_key=client_requirement.client_key WHERE client_name LIKE CONCAT('%!', :clientSearch, '%')  escape '!' OR client_mailid LIKE CONCAT('%!', :clientSearch, '%') escape '!' ORDER BY client_details.createdAt DESC, client_name DESC, client_mailid DESC LIMIT :limit OFFSET :offset";

	public static final String ROW_COUNT_CLIENT_SEARCH = "select count(*) as rowCount from client_details WHERE client_name LIKE CONCAT('%!', :clientSearch, '%')escape '!' OR client_mailid LIKE CONCAT('%!', :clientSearch, '%')  escape '!'";

	public static final String VALIDATEUSER = "select count(*) from user_details where user_name=:userName and user_password=:userPassword";

	public static final String QUESTION_INSERT = "INSERT INTO estimate_questions (question, max_selection, question_type,question_order,is_skippable,question_id,isDeleted) VALUES (:questions,:maxSelection,:questionType,:questionOrder,:isSkippable,:questionId,:isDeleted)";

	public static final String OPTION_INSERT = "INSERT INTO question_options(option_text,image,option_order,option_hours,isOptionAll,cost,question_key,option_id) VALUES (:optionText,:image,:optionOrder,:optionHours,:isOptionAll,:cost,:questionKey,:optionId)";

	public static final String FETCH_QUESTION_ID_KEY = "SELECT question_key,question_id FROM estimate_questions WHERE question_id IN(:questionId)";

	public static final String FETCH_QUESTION_OPTION_BY_ORDER = "SELECT  estimate_questions.question_key,estimate_questions.question_id,estimate_questions.question,estimate_questions.max_selection,estimate_questions.question_order,estimate_questions.is_skippable,question_options.option_id,question_options.option_text,question_options.image,question_type.question_type,question_options.option_order,question_options.option_hours,question_options.isOptionAll,question_options.cost,question_options.jump_to from estimate_questions inner join question_options on estimate_questions.question_key=question_options.question_key inner join question_type on estimate_questions.question_type=question_type.type_id where estimate_questions.question_order=:questionOrder order by estimate_questions.question_order asc,question_options.option_order asc";

	public static final String FETCH_QUESTION_OPTION_BY_KEY = "SELECT  estimate_questions.question_key,estimate_questions.question_id,estimate_questions.question,estimate_questions.max_selection,estimate_questions.question_order,estimate_questions.is_skippable,question_options.option_id,question_options.option_text,question_options.image,question_type.question_type,question_options.option_order,question_options.option_hours,question_options.isOptionAll,question_options.cost,question_options.jump_to from estimate_questions inner join question_options on estimate_questions.question_key=question_options.question_key inner join question_type on estimate_questions.question_type=question_type.type_id where estimate_questions.question_key=:questionKey order by estimate_questions.question_order asc,question_options.option_order asc";
}