package com.tm.estimator.pojo.request;

import java.util.UUID;

import javax.validation.constraints.NotNull;

/**
 * This class is used request pojo fetch the client requirement using clientId
 * 
 * @author TTS-503-balavignesh
 */
public class FetchRequirementRequestPOJO {

	@NotNull(message = "Enter clientId")
	private UUID clientId;

	public UUID getClientId() {
		return clientId;
	}

	public void setClientId(UUID clientId) {
		this.clientId = clientId;
	}

}
