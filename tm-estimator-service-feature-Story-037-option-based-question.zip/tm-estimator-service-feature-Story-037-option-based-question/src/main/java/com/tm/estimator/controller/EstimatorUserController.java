package com.tm.estimator.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tm.estimator.constants.MessageConstants;
import com.tm.estimator.pojo.request.LogInRequestPOJO;
import com.tm.estimator.response.EstimatorResponsePOJO;
import com.tm.estimator.service.EstimatorService;
import com.tm.estimator.utils.DataConvertion;

/**
 * This class is used to create user and valid the user by login
 * 
 * @author TTS-503-balavignesh
 */
@CrossOrigin(origins = { "http://tts.webredirect.org:84/", "http://localhost:4200/" })
@RestController
@RequestMapping(value = "/user")
public class EstimatorUserController {

	@Autowired
	private EstimatorService estimatorService;

	private static final Logger LOGGER = LoggerFactory.getLogger(EstimatorUserController.class);

	/**
	 * This method is used to validate the user and password and give valid response
	 * to the user
	 * 
	 * 
	 * @param logInRequestPOJO
	 * @return EstimatorResponsePOJO
	 */
	@PostMapping("/userLogin")
	public EstimatorResponsePOJO userLogin(@RequestBody LogInRequestPOJO logInRequestPOJO) {
		LOGGER.info("This user login starts execution");
		EstimatorResponsePOJO estimatorResponsePOJO = new EstimatorResponsePOJO();
		String userLoginRequestString = DataConvertion.convertJson(logInRequestPOJO);
		try {
			LOGGER.debug("Question And option Details:{}", userLoginRequestString);
			if (estimatorService.userLogin(logInRequestPOJO)) {
				estimatorResponsePOJO.response("User Details is valid", true);
				LOGGER.info("User Details is valid");
			} else {
				estimatorResponsePOJO.response(MessageConstants.NOTVALIDREQUEST, false);
				LOGGER.info("User Details is not valid one please check the user and password");
			}
		} catch (Exception e) {
			LOGGER.error("Error occurs in 'SignIN' in controller");
			estimatorResponsePOJO.response(MessageConstants.NOTVALIDREQUEST, false);
		}
		String convertValueString = DataConvertion.convertJson(estimatorResponsePOJO);
		LOGGER.debug("UserLogin Response:{}", convertValueString);
		return estimatorResponsePOJO;
	}

}
