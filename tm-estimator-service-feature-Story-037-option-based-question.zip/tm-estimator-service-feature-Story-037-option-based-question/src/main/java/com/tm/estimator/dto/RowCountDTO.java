package com.tm.estimator.dto;

/**
 * This class is used to fetch the row cout from database
 * 
 * @author TTS-503-balavignesh
 */
public class RowCountDTO {

	private int rowCount;

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}
	
	
	
	
}
