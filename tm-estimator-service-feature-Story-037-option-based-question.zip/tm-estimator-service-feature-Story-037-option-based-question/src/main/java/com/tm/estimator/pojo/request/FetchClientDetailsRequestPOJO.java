package com.tm.estimator.pojo.request;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import com.tm.estimator.enums.OrderByColumns;
import com.tm.estimator.enums.SortBy;

/**
 * This class is used to fetchClientDetails request pojo to get with limit of
 * records
 * 
 * @author TTS-503-balavignesh
 */
public class FetchClientDetailsRequestPOJO {

	@Min(value = 1, message = "Enter limit")
	private int limit;
	@Min(value = 1, message = "Enter pageNo")
	private int pageNo;
	@Size(min = 1, max = 60, message = "Min value should be given and Max should be 50")
	private String clientSearch;
	private OrderByColumns sortingBy;
	private SortBy sortBy;

	public int getLimit() {
		return limit;
	}

	public int getPageNo() {
		return pageNo;
	}

	public String getClientSearch() {
		return clientSearch;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public void setClientSearch(String clientSearch) {
		this.clientSearch = clientSearch;
	}

	public OrderByColumns getSortingBy() {
		return sortingBy;
	}

	public void setSortingBy(OrderByColumns sortingBy) {
		this.sortingBy = sortingBy;
	}

	public SortBy getSortBy() {
		return sortBy;
	}

	public void setSortBy(SortBy sortBy) {
		this.sortBy = sortBy;
	}

}
