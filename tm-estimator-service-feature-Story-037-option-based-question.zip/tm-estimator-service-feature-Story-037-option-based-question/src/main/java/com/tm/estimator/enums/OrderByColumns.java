package com.tm.estimator.enums;

/**
 * This enum class is used to get column equivalent using the key
 * 
 * @author TTS-503-balavignesh
 */
public enum OrderByColumns {

	CLIENTNAME,CLIENTMAIL,CLIENTCREATEDAT;
}
