package com.tm.estimator.pojo;

import java.util.List;

import com.tm.estimator.dto.FetchRequirementDTO;
import com.tm.estimator.dto.RequirementIdDTO;

public class RequirementPOJO {

	private List<RequirementIdDTO> requirementIdDTOs;

	private List<FetchRequirementDTO> fetchRequirementDTOs;

	public List<RequirementIdDTO> getRequirementIdDTOs() {
		return requirementIdDTOs;
	}

	public void setRequirementIdDTOs(List<RequirementIdDTO> requirementIdDTOs) {
		this.requirementIdDTOs = requirementIdDTOs;
	}

	public List<FetchRequirementDTO> getFetchRequirementDTOs() {
		return fetchRequirementDTOs;
	}

	public void setFetchRequirementDTOs(List<FetchRequirementDTO> fetchRequirementDTOs) {
		this.fetchRequirementDTOs = fetchRequirementDTOs;
	}

}
