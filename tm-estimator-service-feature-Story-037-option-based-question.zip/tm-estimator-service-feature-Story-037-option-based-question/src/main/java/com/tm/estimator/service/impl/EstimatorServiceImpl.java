package com.tm.estimator.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tm.estimator.constants.MessageConstants;
import com.tm.estimator.dao.EstimatorDao;
import com.tm.estimator.dto.ClientDTO;
import com.tm.estimator.dto.ClientDetailsDTO;
import com.tm.estimator.dto.ClientKeyDTO;
import com.tm.estimator.dto.FetchRequirementDTO;
import com.tm.estimator.dto.QuestionKeyDTO;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.dto.RequirementIdDTO;
import com.tm.estimator.enums.OrderByColumns;
import com.tm.estimator.enums.SortBy;
import com.tm.estimator.pojo.ClientDetailsPOJO;
import com.tm.estimator.pojo.ClientIdPOJO;
import com.tm.estimator.pojo.FetchClientDetailsPOJO;
import com.tm.estimator.pojo.OptionPOJO;
import com.tm.estimator.pojo.QuestionDetailsPOJO;
import com.tm.estimator.pojo.RequirementPOJO;
import com.tm.estimator.pojo.RowCountPOJO;
import com.tm.estimator.pojo.request.EstimatorRequestPOJO;
import com.tm.estimator.pojo.request.FetchClientDetailsRequestPOJO;
import com.tm.estimator.pojo.request.SaveRequirementRequestPOJO;
import com.tm.estimator.pojo.request.LogInRequestPOJO;
import com.tm.estimator.pojo.request.QuestionCreationRequestPOJO;
import com.tm.estimator.service.EstimatorService;

/**
 * Implementation of the EstimatorService interface that provides functionality
 * This class uses an EstimatorDao to interact with the data source.
 * 
 * @author TTS-503-balavignesh
 */
@Service
public class EstimatorServiceImpl implements EstimatorService {

	@Autowired
	private EstimatorDao estimatorDao;

	private static final Logger LOGGER = LoggerFactory.getLogger(EstimatorServiceImpl.class);

	/**
	 * This Method will Fetch the details of the Question and Options
	 * 
	 * @return List<QuestionOptionDTO> this will return QuestionOptionDTO list
	 */
	@Override
	public List<QuestionOptionDTO> fetchQuestionDetails() {
		LOGGER.info("FetchQuestionDetails: Fetch Question and Option details in service layer");
		List<QuestionOptionDTO> questionOptionDTOList = null;
		try {
			questionOptionDTOList = estimatorDao.fetchQuestionDetails();
			LOGGER.info("List of QuestionOptionDTO is return from DAO");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while fetching questions and option Details in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("FetchQuestionDetails :{}", questionOptionDTOList);
		return questionOptionDTOList;
	}

	/**
	 * This Method will save the client details
	 * 
	 * @param estimatorRequestPOJO
	 * @return Integer
	 */
	@Override
	public ClientIdPOJO saveClientDetails(EstimatorRequestPOJO estimatorRequestPOJO) {
		LOGGER.info("saveClientDetails: Processing for saving in service layer");
		ClientIdPOJO clientIdPOJO = new ClientIdPOJO();
		try {
			boolean isValid = estimatorDao.isClientPresents(estimatorRequestPOJO.getClientMailId(),
					estimatorRequestPOJO.getContactNumber());
			if (isValid) {
				ClientDTO clientDTO = estimatorDao.updateClientDetails(estimatorRequestPOJO.getClientMailId(),
						estimatorRequestPOJO.getContactNumber());
				ObjectMapper objectMapper = new ObjectMapper();
				clientIdPOJO = objectMapper.convertValue(clientDTO, ClientIdPOJO.class);
			} else {
				String clientId = UUID.randomUUID().toString();
				String clientGroupIdId = UUID.randomUUID().toString();
				int response = estimatorDao.saveClientDetails(estimatorRequestPOJO, clientId, clientGroupIdId);
				if (response > 0) {
					clientIdPOJO.setClientId(clientId);
					clientIdPOJO.setClientRequirementGroupId(clientGroupIdId);
				} else {
					LOGGER.info("Client details not saved properly");
				}
			}
			LOGGER.info("Saved the client details");
		} catch (Exception dataAccessException) {
			dataAccessException.printStackTrace();
			LOGGER.error("An error occurred while saving the client details in database in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("SaveClientDetails: Service response :{}", clientIdPOJO);
		return clientIdPOJO;
	}

	/**
	 * Fetch Client Details from the database
	 *
	 * @param FetchClientDetailsRequestPOJO
	 * @return FetchClientDetailsPOJO
	 */
	@Override
	public FetchClientDetailsPOJO fetchClientDetails(FetchClientDetailsRequestPOJO fetchClientDetails) {
		LOGGER.info("Fetching Client Details");
		List<ClientDetailsDTO> clientDetailsList = null;
		ObjectMapper objectMapper = new ObjectMapper();
		FetchClientDetailsPOJO fetchClientDetailsPOJO = new FetchClientDetailsPOJO();
		try {
			if (StringUtils.hasText(fetchClientDetails.getClientSearch()) && fetchClientDetails.getLimit() > 0
					&& fetchClientDetails.getPageNo() > 0) {
				clientDetailsList = estimatorDao.clientSearch(fetchClientDetails.getLimit(),
						fetchClientDetails.getLimit() * (fetchClientDetails.getPageNo() - 1),
						fetchClientDetails.getClientSearch());
			} else if (isValidSorting(fetchClientDetails) && fetchClientDetails.getLimit() > 0
					&& fetchClientDetails.getPageNo() > 0) {
				clientDetailsList = estimatorDao.fetchClientDetails(fetchClientDetails.getLimit(),
						fetchClientDetails.getLimit() * (fetchClientDetails.getPageNo() - 1),
						fetchClientDetails.getSortingBy(), fetchClientDetails.getSortBy());
			} else if (fetchClientDetails.getLimit() > 0 && fetchClientDetails.getPageNo() > 0) {
				clientDetailsList = estimatorDao.fetchClientDetails(fetchClientDetails.getLimit(),
						fetchClientDetails.getLimit() * (fetchClientDetails.getPageNo() - 1),
						OrderByColumns.valueOf(MessageConstants.SORTINGKEY), SortBy.DESC);
				LOGGER.info("using limit from param");
			}
			LOGGER.info("Fetched the clientDetails list from DAO");
			if (!CollectionUtils.isEmpty(clientDetailsList)) {
				fetchClientDetailsPOJO.setClientDetails(
						objectMapper.convertValue(clientDetailsList, new TypeReference<List<ClientDetailsPOJO>>() {
						}));
				if (StringUtils.hasText(fetchClientDetails.getClientSearch())) {
					fetchClientDetailsPOJO.setRowCout(objectMapper
							.convertValue(estimatorDao.getRowCountClientSerach(fetchClientDetails.getClientSearch()),
									RowCountPOJO.class)
							.getRowCount());
				} else {
					fetchClientDetailsPOJO.setRowCout(objectMapper
							.convertValue(estimatorDao.getRowCountClientDetails(), RowCountPOJO.class).getRowCount());
				}
			}
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while fetchingClientdetails in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("Fetch Client Details: Service response :{}", clientDetailsList);
		return fetchClientDetailsPOJO;

	}

	/**
	 * This method is used to validate the enum of orderbycolumns and sortby
	 * 
	 * @param fetchClientDetails
	 * @return boolean
	 */
	private boolean isValidSorting(FetchClientDetailsRequestPOJO fetchClientDetails) {
		LOGGER.info("isValidSortingBy in service layer");
		boolean isValid = false;
		isValid = EnumSet.of(OrderByColumns.CLIENTNAME, OrderByColumns.CLIENTMAIL)
				.contains(fetchClientDetails.getSortingBy())
				&& EnumSet.of(SortBy.DESC, SortBy.ASC).contains(fetchClientDetails.getSortBy());
		LOGGER.debug("isValidSorting service response :{}", isValid);
		return isValid;
	}

	/**
	 * This method is used to fetch the clientkey using the clientId
	 * 
	 * @param clientId
	 * @retrun ClientKeyDTO
	 */
	@Override
	public ClientKeyDTO fetchClientKey(UUID clientId) {
		LOGGER.info("Fetching clientKey using clientId service Layer");
		ClientKeyDTO clientKeyDTO = null;
		try {
			clientKeyDTO = estimatorDao.fetchClientKey(clientId);
			LOGGER.info("Fetched the clientkey in service");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while fetching clientKey using clientId in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("Fetch Clientkey using clientId: Service response :{}", clientKeyDTO);
		return clientKeyDTO;
	}

	/**
	 * This method is used to save the client Requirement
	 *
	 * @param requirementRequestPOJO
	 * @param clientKey
	 * @return Integer
	 */
	@Override
	public List<QuestionOptionDTO> saveClientRequirement(SaveRequirementRequestPOJO requirementRequestPOJO,
			ClientKeyDTO clientKey) {
		LOGGER.info("saveClientRequirement service layer execution");
		List<QuestionOptionDTO> questionOptionDTOs = null;
		try {
			if (estimatorDao.isValidGroupId(requirementRequestPOJO.getGroupId().toString()) > 0) {
				if (!CollectionUtils.isEmpty(requirementRequestPOJO.getOptionId())
						&& StringUtils.hasText(requirementRequestPOJO.getQuestionId().toString())) {
					if (estimatorDao.saveClientRequirement(requirementRequestPOJO, clientKey)) {
						List<QuestionKeyDTO> questionKeyList = estimatorDao.fetchJumpToByOptionId(requirementRequestPOJO
								.getOptionId().stream().map(UUID::toString).collect(Collectors.toSet()));
						// if null return flow will complete
						questionOptionDTOs = fetchQuestionBasedRequirement(questionKeyList, requirementRequestPOJO);
					}
				} else {
					questionOptionDTOs = estimatorDao.fetchOptionBaseQuestions();
				}
			} else {
				// TODO return the status
				estimatorDao.deleteRequirements(requirementRequestPOJO.getClientGroupId().toString());
				LOGGER.info("requirement reverted back if requirement is exist");
			}
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while fetching client details in service layer");
			dataAccessException.printStackTrace();
			throw dataAccessException;
		}
		return questionOptionDTOs;
	}

	private List<QuestionOptionDTO> fetchQuestionBasedRequirement(List<QuestionKeyDTO> questionKeyList,
			SaveRequirementRequestPOJO requirementRequestPOJO) {
		List<QuestionOptionDTO> questionOptionDTOs = null;
		if (!CollectionUtils.isEmpty(questionKeyList)) {
			questionOptionDTOs = fetchQuestion(
					questionKeyList.stream().map(QuestionKeyDTO::getQuestionKey).collect(Collectors.toList()),
					requirementRequestPOJO);
		} else {
			Integer jumpToQuestion = estimatorDao.fetchNextJumpTo(requirementRequestPOJO.getClientGroupId().toString());
			if (jumpToQuestion != null) {
				estimatorDao.isReturnedUpdate(requirementRequestPOJO.getClientGroupId().toString());
				questionOptionDTOs = estimatorDao.fetchQuestionOptionById(jumpToQuestion);
			} else {
				LOGGER.info("This question options is completed using jumpTo");
			}
		}
		return questionOptionDTOs;
	}

	private List<QuestionOptionDTO> fetchQuestion(List<Integer> questionKeyList,
			SaveRequirementRequestPOJO requirementRequestPOJO) {
		List<QuestionOptionDTO> questionOptionDTOs = null;
		Set<Integer> questionKeySet = new LinkedHashSet<>();
		if (questionKeyList.size() > 1) {
			for (int i = 0; i < questionKeyList.size() - 1; i++) {
				questionKeySet.add(questionKeyList.get(i));
			}
			estimatorDao.insertReturnQuestions(requirementRequestPOJO.getClientId().toString(),
					requirementRequestPOJO.getClientGroupId().toString(), questionKeySet, false);
		}
		questionOptionDTOs = estimatorDao.fetchQuestionOptionById(questionKeyList.get(questionKeyList.size() - 1));
		return questionOptionDTOs;
	}

	/**
	 * This method is used to fetch the client requirement
	 * 
	 * @param clientId
	 * @return RequirementInfoDTO
	 */
	@Override
	public RequirementPOJO fetchRequirementDetails(UUID clientId) {
		LOGGER.info("Fetch Requirement details service");
		RequirementPOJO requirementPOJO = new RequirementPOJO();
		try {
			List<RequirementIdDTO> requirementIdDTO = estimatorDao.fetchRequirementDetails(clientId);
			if (!Objects.isNull(requirementIdDTO)) {
				Set<String> groupIdSet = new HashSet<>();
				Set<String> optionIdSet = new HashSet<>();
				Set<String> questionIdSet = new HashSet<>();
				for (RequirementIdDTO requirementIds : requirementIdDTO) {
					groupIdSet.add(requirementIds.getGroupId());
					optionIdSet.add(requirementIds.getOptionId());
					questionIdSet.add(requirementIds.getQuestionId());
				}
				List<FetchRequirementDTO> requirementDTO = estimatorDao.fetchQuestionOptionByIds(questionIdSet,
						optionIdSet, groupIdSet);
				requirementPOJO.setFetchRequirementDTOs(requirementDTO);
				requirementPOJO.setRequirementIdDTOs(requirementIdDTO);
			}
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while fetching the requirement details of client in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("Fetching Requirement Map: Service response :{}", requirementPOJO);
		return requirementPOJO;
	}

	/**
	 * This method is used to validate the clientId
	 *
	 * @param clientId
	 * @return boolean
	 */
	@Override
	public boolean clientIdValidate(UUID clientId) {
		LOGGER.info("clientIdValidating in service layer execution");
		boolean isValidClientId = false;
		try {
			isValidClientId = estimatorDao.clientIdValidate(clientId);
			LOGGER.info("ClientId is validated in database in service layer");
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while validating the clientId in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("isValidClientID in service layer response:{}", isValidClientId);
		return isValidClientId;
	}

	/**
	 * This method is used to validate the questionIdSet
	 *
	 * @param questionIdSet
	 * @return boolean
	 */
	@Override
	public boolean isValidQuestion(Set<UUID> questionIdSet) {
		LOGGER.info("isValidQuestion in service layer execution");
		boolean isValidQuestionOption = false;
		try {
			isValidQuestionOption = estimatorDao
					.isValidQuestion(questionIdSet.stream().map(UUID::toString).collect(Collectors.toSet()));
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while validating the questionIdSet in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("ValidQuestonId set validating in service layer :{}", isValidQuestionOption);
		return isValidQuestionOption;
	}

	/**
	 * This method is to validate the optionId
	 * 
	 * @param optionIdSet
	 * @return boolean
	 */
	@Override
	public boolean isValidOption(Set<String> optionIdSet) {
		LOGGER.info("Valid option in service layer execution");
		boolean isValidQuestionOption = false;
		try {
			isValidQuestionOption = estimatorDao.isValidOption(optionIdSet);
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while validating the optionIdSet in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("isValidOption set response in service:{}", isValidQuestionOption);
		return isValidQuestionOption;
	}

	/**
	 * This method is used to validate the user and password
	 *
	 * @param logInRequestPOJO
	 * @return boolean
	 */
	@Override
	public boolean userLogin(LogInRequestPOJO logInRequestPOJO) {
		LOGGER.info("In userLogin user login method");
		boolean isValid = false;
		try {
			isValid = estimatorDao.userLogin(logInRequestPOJO);
		} catch (DataAccessException dataAccessException) {
			LOGGER.error("An error occurred while validating user in service layer");
			throw dataAccessException;
		}
		LOGGER.debug("userLogin set response in service:{}", isValid);
		return isValid;

	}

	@Transactional
	@Override
	public boolean updateQuestionDetails(QuestionCreationRequestPOJO questionCreationRequestPOJO) {
		LOGGER.info("updateQuestionDetails service");
		boolean isValid = false;
		try {
			List<String> questionIdList = new ArrayList<>();
			List<String> optionIdList = new ArrayList<>();
			List<MapSqlParameterSource> batchParametersOption = new ArrayList<>();
			List<MapSqlParameterSource> batchParametersQuestion = new ArrayList<>();
			for (QuestionDetailsPOJO questionDetails : questionCreationRequestPOJO.getQuestions()) {
				MapSqlParameterSource mapSqlParameterSourceQuestion = new MapSqlParameterSource();
				mapSqlParameterSourceQuestion.addValue("questionId", questionDetails.getQuestionId());
				mapSqlParameterSourceQuestion.addValue("question", questionDetails.getQuestion());
				mapSqlParameterSourceQuestion.addValue("maxSelection", questionDetails.getMaxSelection());
				mapSqlParameterSourceQuestion.addValue("questionType", questionDetails.getQuestionType());
				mapSqlParameterSourceQuestion.addValue("questionOrder", questionDetails.getQuestionOrder());
				mapSqlParameterSourceQuestion.addValue("isSkippable", questionDetails.getIsSkippable());
				mapSqlParameterSourceQuestion.addValue("questionGroupId", UUID.randomUUID().toString());
				batchParametersQuestion.add(mapSqlParameterSourceQuestion);
				questionIdList.add(questionDetails.getQuestionId());
				for (OptionPOJO option : questionDetails.getOptions()) {
					MapSqlParameterSource mapSqlParameterSourceOption = new MapSqlParameterSource();
					mapSqlParameterSourceOption.addValue("optionId", option.getOptionId());
					mapSqlParameterSourceOption.addValue("optionText", option.getOptionText());
					mapSqlParameterSourceOption.addValue("image", option.getImage());
					mapSqlParameterSourceOption.addValue("optionOrder", option.getOptionOrder());
					mapSqlParameterSourceOption.addValue("optionHours", option.getOptionHours());
					mapSqlParameterSourceOption.addValue("isOptionAll", option.getIsOptionAll());
					mapSqlParameterSourceOption.addValue("cost", option.getCost());
					mapSqlParameterSourceOption.addValue("jumpTo", option.getJumpTo());
					mapSqlParameterSourceOption.addValue("optionGroupId", UUID.randomUUID().toString());
					batchParametersOption.add(mapSqlParameterSourceOption);
					optionIdList.add(option.getOptionId());
				}
			}
			int[] optionsResponse = estimatorDao.updateQuestionDetails(batchParametersQuestion);
			int[] questionResponse = estimatorDao.updateOptionDetails(batchParametersOption);
			if (Arrays.stream(questionResponse).anyMatch(v -> v == 0)
					|| Arrays.stream(optionsResponse).anyMatch(v -> v == 0)) {
				LOGGER.error("Batch update failed. Rolling back transaction.");
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			} else {
				String groupId = UUID.randomUUID().toString();
				if (estimatorDao.updateGroupId(groupId) > 0) {
					estimatorDao.insertOptionDetails(optionIdList.stream().collect(Collectors.toSet()), groupId);
					estimatorDao.insertQuestionDetails(questionIdList.stream().collect(Collectors.toSet()), groupId);
					isValid = true;
					LOGGER.info("Batch update successfully in DAO.");
				}
			}
		} catch (Exception e) {
			isValid = false;
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			LOGGER.error("Error occurs in update Question Details in service");
		}
		LOGGER.debug("Response in update QuestionDetails in service layer{}:", isValid);
		return isValid;
	}
}
