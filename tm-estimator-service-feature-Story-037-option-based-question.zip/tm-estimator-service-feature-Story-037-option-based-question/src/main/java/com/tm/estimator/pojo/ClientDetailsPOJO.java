package com.tm.estimator.pojo;

import java.util.UUID;

/**
 * This class is used to used to transfer data from DAO to POJO for response
 * 
 * @author TTS-503-balavignesh
 */
public class ClientDetailsPOJO {

	private UUID clientId;
	private String clientMailid;
	private String clientName;
	private String clientContact;
	private String totalCost;
	private String totalHours;

	public String getTotalCost() {
		return totalCost;
	}

	public String getTotalHours() {
		return totalHours;
	}

	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}

	public void setTotalHours(String totalHours) {
		this.totalHours = totalHours;
	}

	public UUID getClientId() {
		return clientId;
	}

	public String getClientMailid() {
		return clientMailid;
	}

	public String getClientName() {
		return clientName;
	}

	public String getClientContact() {
		return clientContact;
	}

	public void setClientId(UUID clientId) {
		this.clientId = clientId;
	}

	public void setClientMailid(String clientMailid) {
		this.clientMailid = clientMailid;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setClientContact(String clientContact) {
		this.clientContact = clientContact;
	}

}
