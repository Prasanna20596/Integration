package com.tm.estimator.dao;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;

import com.tm.estimator.dto.ClientDTO;
import com.tm.estimator.dto.ClientDetailsDTO;
import com.tm.estimator.dto.ClientKeyDTO;
import com.tm.estimator.dto.FetchRequirementDTO;
import com.tm.estimator.dto.QuestionKeyDTO;
import com.tm.estimator.dto.QuestionOptionDTO;
import com.tm.estimator.dto.RequirementIdDTO;
import com.tm.estimator.dto.RowCountDTO;
import com.tm.estimator.enums.OrderByColumns;
import com.tm.estimator.enums.SortBy;
import com.tm.estimator.pojo.request.EstimatorRequestPOJO;
import com.tm.estimator.pojo.request.LogInRequestPOJO;
import com.tm.estimator.pojo.request.SaveRequirementRequestPOJO;

/**
 * This interface defines the contract for accessing and manipulating data
 * related to the Estimator service in the database.
 * 
 * @author TTS-503-balavignesh
 */
@Service
public interface EstimatorDao {

	/**
	 * This method Fetch the Question and option data from the database
	 * 
	 * @return List<QuestionOptionDTO> this will return QuestionOptionDTO list
	 */
	public List<QuestionOptionDTO> fetchQuestionDetails();

	/**
	 * This Method will save the client details in the database
	 * 
	 * @param estimatorRequestPOJO
	 * @return Integer
	 */
	public Integer saveClientDetails(EstimatorRequestPOJO estimatorRequestPOJO, String clientId, String clientGroupId);

	/**
	 * Fetch the Client Details from database
	 * 
	 * @param limit
	 * @param offset
	 * @param sortingBy
	 * @param sortBy
	 * @return List<ClientDetailsDTO> A list of client details retrieved from the
	 *         database.
	 */
	public List<ClientDetailsDTO> fetchClientDetails(int limit, int offset, OrderByColumns sortingBy, SortBy sortBy);

	/**
	 * This method is used to fetch the clientKey from db using clientId
	 * 
	 * @param clientId
	 * @return ClientKeyDTO
	 */
	public ClientKeyDTO fetchClientKey(UUID clientId);

	/**
	 * This method is used to save the clientRequirement in database
	 * 
	 * @param clientKeyDTO
	 * @param requirementPOJO
	 * @return Integer
	 */
	public boolean saveClientRequirement(SaveRequirementRequestPOJO saveRequirementRequestPOJO,
			ClientKeyDTO clientKeyDTO);

	/**
	 * This method is used to fetch the client requirement from database
	 * 
	 * @param clientId
	 * @return RequirementInfoDTO
	 */
	public List<RequirementIdDTO> fetchRequirementDetails(UUID clientId);

	/**
	 * This method is used to validate the clientId in database
	 * 
	 * @param clientId
	 * @return boolean
	 */
	public boolean clientIdValidate(UUID clientId);

	/**
	 * This method is used to validate the questionID in database
	 * 
	 * @param questionIdSet
	 * @return boolean
	 */
	public boolean isValidQuestion(Set<String> questionIdSet);

	/**
	 * This method is used to validate the optionId in database
	 * 
	 * @param optionId
	 * @return boolean
	 */
	public boolean isValidOption(Set<String> optionId);

	/**
	 * This method is used to get row count in db of clientDetails
	 * 
	 * @return RowCountDTO
	 */
	public RowCountDTO getRowCountClientDetails();

	/**
	 * This method is used to client Details seach from database using clientName or
	 * clientMailId of pagination used limit and offset
	 * 
	 * @param limit
	 * @param offset
	 * @param clientSearch
	 * @return List<ClientDetailsDTO>
	 */
	List<ClientDetailsDTO> clientSearch(int limit, int offset, String clientSearch);

	/**
	 * This method is used to count the total record of the clientSearch of client
	 * Details
	 * 
	 * @param clientSearch
	 * @return RowCountDTO
	 */
	RowCountDTO getRowCountClientSerach(String clientSearch);

	/**
	 * This method is used to validate the user and password
	 * 
	 * @param signInRequestPOJO
	 * @return Boolean
	 */
	public Boolean userLogin(LogInRequestPOJO signInRequestPOJO);

	public int[] updateQuestionDetails(List<MapSqlParameterSource> batchParametersQuestion);

	public int[] updateOptionDetails(List<MapSqlParameterSource> batchParametersOption);

	public int insertOptionDetails(Set<String> optionSet, String groupId);

	public int insertQuestionDetails(Set<String> questionSet, String groupId);

	public Boolean isClientPresents(String clientMailId, String contactNumber);

	public ClientDTO updateClientDetails(String clientMailId, String contactNumber);

	public List<FetchRequirementDTO> fetchQuestionOptionByIds(Set<String> questionIdSet, Set<String> optionIdSet,
			Set<String> groupIdSet);

	public int updateGroupId(String groupId);

	public Integer isValidGroupId(String groupId);

	public int deleteRequirements(String clientGroupId);

	public List<QuestionOptionDTO> fetchOptionBaseQuestions();

	public List<QuestionKeyDTO> fetchJumpToByOptionId(Set<String> optionId);

	public boolean insertReturnQuestions(String clientId, String clientGroupId, Set<Integer> questionKeys,
			boolean isReturned);

	public Integer fetchNextJumpTo(String clientGroupId);

	public int isReturnedUpdate(String clientId);

	public List<QuestionOptionDTO> fetchQuestionOptionById(int questionKey);

}