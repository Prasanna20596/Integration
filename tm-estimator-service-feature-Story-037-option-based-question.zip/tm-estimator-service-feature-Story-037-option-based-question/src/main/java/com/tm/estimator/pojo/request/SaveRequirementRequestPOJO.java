package com.tm.estimator.pojo.request;

import java.util.Set;
import java.util.UUID;

import javax.validation.constraints.NotNull;

/**
 * This Class is used to save the client Requirement
 * 
 * @author TTS-503-balavignesh
 */
public class SaveRequirementRequestPOJO {

	@NotNull(message = "Enter clientId")
	private UUID clientId;

	@NotNull(message = "Enter ClientGroupId")
	private UUID clientGroupId;

	@NotNull(message = "Enter questionId")
	private UUID questionId;

	@NotNull(message = "Enter optionId")
	private Set<UUID> optionId;

	@NotNull(message = "Enter groupId")
	private UUID groupId;

	public Set<UUID> getOptionId() {
		return optionId;
	}

	public void setOptionId(Set<UUID> optionId) {
		this.optionId = optionId;
	}

	public UUID getClientId() {
		return clientId;
	}

	public void setClientId(UUID clientId) {
		this.clientId = clientId;
	}

	public UUID getClientGroupId() {
		return clientGroupId;
	}

	public void setClientGroupId(UUID clientGroupId) {
		this.clientGroupId = clientGroupId;
	}

	public UUID getQuestionId() {
		return questionId;
	}

	public void setQuestionId(UUID questionId) {
		this.questionId = questionId;
	}

	public UUID getGroupId() {
		return groupId;
	}

	public void setGroupId(UUID groupId) {
		this.groupId = groupId;
	}

}
