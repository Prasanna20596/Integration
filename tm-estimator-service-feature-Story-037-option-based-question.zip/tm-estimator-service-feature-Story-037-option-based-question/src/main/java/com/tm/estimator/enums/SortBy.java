package com.tm.estimator.enums;

/**
 * This class is to get order by sort type
 * 
 * @author TTS-503-balavignesh
 */
public enum SortBy {

	ASC, DESC;
}
