#Project :
Estimator-Tool

#Java Version
java 8

#Mysql Version
version 8.0.32

#Run Application with Application (or) server
java -Dserver.port=8080 -jar <path/to/jar>

#Maven Version
version - 3.9.4
