package com.artrepublic.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.artrepublic.entity.Roles;

public interface RoleRepository extends JpaRepository<Roles, Integer>{
	
	 @Query("SELECT roles.roleId FROM Roles roles WHERE roles.roleName = :roleName")
	 Integer findRoleIdByRoleName(@Param("roleName") String roleName);

}
