package com.artrepublic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.entity.ArtistInfo;

public interface ArtistRepository extends JpaRepository<ArtistInfo, Integer> {
	
	ArtistInfo findByUserUserId(int userId);
	
	@Query("SELECT new com.artrepublic.dto.ArtistUserDTO(artist.profilePicture, user.name, user.email,artist.bio,"
	 		+ " artist.contactNo, artist.address) FROM ArtistInfo artist JOIN artist.user user"
	 		+ " WHERE user.email = :email")
    ArtistUserDTO findArtistDetailsByEmail(@Param("email") String email);
	
	@Query("SELECT new com.artrepublic.dto.ArtistUserDTO(artist.profilePicture, user.name, user.email,artist.bio,"
	 		+ " artist.contactNo, artist.address) FROM ArtistInfo artist JOIN artist.user user"
	 		+ " WHERE user.name = :name")
    ArtistUserDTO findArtistDetailsByName(@Param("name") String name);
	
	List<ArtistInfo> findAllByUserEmailIsNot(String email);
			
}
