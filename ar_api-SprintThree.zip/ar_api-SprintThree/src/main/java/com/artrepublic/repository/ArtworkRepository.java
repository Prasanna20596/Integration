package com.artrepublic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.artrepublic.dto.ArtistArtworkDTO;
import com.artrepublic.dto.ArtworksDTO;
import com.artrepublic.entity.Artworks;

public interface ArtworkRepository extends JpaRepository<Artworks, Integer> {
	
	@Query("SELECT new com.artrepublic.dto.ArtworksDTO(artwork.artworkId, artwork.artworkTitle," +
			"artwork.description, artwork.artworkImage, artwork.active,collection.title) FROM Artworks artwork " +
	        "JOIN artwork.collection collection JOIN collection.artistInfo artist " +
	        "JOIN artist.user user WHERE user.email = :email")
	List<ArtworksDTO> findByArtworksByArtistEmail(@Param("email") String email);	
	
	@Query("SELECT new com.artrepublic.dto.ArtworksDTO(artwork.artworkId, artwork.artworkTitle," +
	        "artwork.description, artwork.artworkImage, artwork.active, collection.title) FROM Artworks artwork " +
	        "JOIN artwork.collection collection JOIN collection.artistInfo artist " +
	        "JOIN artist.user user WHERE artwork.artworkId = :artworkId AND user.email = :email")
	ArtworksDTO findArtworkByIdAndArtistEmail(@Param("artworkId") int artworkId, @Param("email") String email);
	
	@Query("SELECT COUNT(artwork) FROM Artworks artwork JOIN artwork.collection collection "
			  + "JOIN collection.artistInfo artist JOIN artist.user user WHERE user.email = :email "
			  + "AND artwork.active = true")
    int countArtworksByArtworkIdAndArtistEmail(@Param("email") String email);
	
	@Query("SELECT COUNT(artwork) FROM Artworks artwork JOIN artwork.collection collection "
			  + "JOIN collection.artistInfo artist JOIN artist.user user WHERE user.name = :name "
			  + "AND artwork.active = true")
    int countArtworksByArtworkIdAndArtistName(@Param("name") String name);
	
	@Query("SELECT new com.artrepublic.dto.ArtistArtworkDTO(artwork.artworkId,artwork.artworkTitle, artwork.artworkImage,"
			+ " user.name) FROM Artworks artwork JOIN artwork.collection collection "
			+ "JOIN collection.artistInfo artist JOIN artist.user user WHERE user.name = :name")
	List<ArtistArtworkDTO> findByArtworksByArtistName(@Param("name") String name);
	
	@Query("SELECT new com.artrepublic.dto.ArtistArtworkDTO(artwork.artworkId,artwork.artworkTitle,"
			+ "artwork.artworkImage, user.name) FROM Artworks artwork "
			+ "JOIN artwork.collection collection JOIN collection.artistInfo artist " 
	        + "JOIN artist.user user WHERE user.email <> :email")
	List<ArtistArtworkDTO> findAllArtworksWithoutCurrentArtist(@Param("email") String email);

}
