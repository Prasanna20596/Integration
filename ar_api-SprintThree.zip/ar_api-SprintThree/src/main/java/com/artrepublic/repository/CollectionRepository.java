package com.artrepublic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.artrepublic.dto.CollectionArtworkImageDTO;
import com.artrepublic.dto.CollectionTitleDTO;
import com.artrepublic.dto.CollectionsDTO;
import com.artrepublic.entity.Collections;

public interface CollectionRepository extends JpaRepository<Collections, Integer>{
	
	  @Query("SELECT new com.artrepublic.dto.CollectionsDTO(collection.collectionId, collection.title, "
	  		    + "collection.description, collection.active) FROM Collections collection "
	            + "JOIN collection.artistInfo artist JOIN artist.user user WHERE user.email = :email")
	  List<CollectionsDTO> findCollectionDetailsByEmail(@Param("email") String email);
	  
	  @Query("SELECT new com.artrepublic.dto.CollectionTitleDTO(collection.title) FROM Collections collection JOIN collection.artistInfo"
	  		    + " artist JOIN artist.user user WHERE user.email = :email AND collection.active=true")
	  List<CollectionTitleDTO> findCollectionTitleListByEmail(@Param("email") String email);
	  
	  @Query("SELECT collection FROM Collections collection JOIN collection.artistInfo artist "
	  		    + "JOIN artist.user user WHERE user.email = :email AND collection.title = :title")
	  Collections findCollectionByArtistEmailAndTitle(@Param("email") String email, @Param("title") String title);
	  
	  @Query("SELECT COUNT(collection) FROM Collections collection JOIN collection.artistInfo artist "
	  		+ "JOIN artist.user user WHERE user.email = :email AND collection.active=true")
	  int findCollectionCountByArtistEmail(@Param("email") String email);
	  
	  @Query("SELECT COUNT(collection) FROM Collections collection JOIN collection.artistInfo artist "
		  		+ "JOIN artist.user user WHERE user.name = :name AND collection.active=true")
	  int findCollectionCountByArtistName(@Param("name") String name);
	  
	  @Query("SELECT new com.artrepublic.dto.CollectionArtworkImageDTO(collection.title, artwork.artworkImage, " +
		        "(SELECT COUNT(artwork) FROM Artworks artwork WHERE artwork.collection = collection)) " +
		        "FROM Artworks artwork JOIN artwork.collection collection " +
		        "JOIN collection.artistInfo artist JOIN artist.user user WHERE user.name = :name " +
		        "AND artwork.createdAt = (SELECT MAX(artwork.createdAt) FROM Artworks artwork WHERE artwork.collection = collection)")
	  List<CollectionArtworkImageDTO> findByCollectionByArtistName(@Param("name") String name);	

}