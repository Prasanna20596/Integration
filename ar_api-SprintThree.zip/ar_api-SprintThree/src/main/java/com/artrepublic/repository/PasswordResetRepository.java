package com.artrepublic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.artrepublic.entity.PasswordReset;

public interface PasswordResetRepository extends JpaRepository<PasswordReset, Integer>{

	@Query("SELECT password From PasswordReset password where password.email = :email ORDER BY password.resetDate DESC" )
	List<PasswordReset> findLatestResetByEmail(@Param("email") String email);

}
