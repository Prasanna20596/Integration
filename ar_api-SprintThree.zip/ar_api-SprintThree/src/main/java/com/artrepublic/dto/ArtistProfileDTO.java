package com.artrepublic.dto;

public class ArtistProfileDTO {

	private int artistId;
	private String profilePicture;
	private String name;
	private int collectionCount;
	private int artworkCount;

	public int getArtistId() {
		return artistId;
	}

	public void setArtistId(int artistId) {
		this.artistId = artistId;
	}

	public String getProfilePicture() {
		return profilePicture;
	}

	public void setProfilePicture(String profilePicture) {
		this.profilePicture = profilePicture;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCollectionCount() {
		return collectionCount;
	}

	public void setCollectionCount(int collectionCount) {
		this.collectionCount = collectionCount;
	}

	public int getArtworkCount() {
		return artworkCount;
	}

	public void setArtworkCount(int artworkCount) {
		this.artworkCount = artworkCount;
	}
	
}
