package com.artrepublic.dto;

public class ArtistArtworkDTO {

	private int artworkId;
	private String artworkTitle;
	private String artworkImage;
	private String name;
	private long artworkCount;

	public ArtistArtworkDTO(int artworkId, String artworkTitle, String artworkImage, String name) {
		super();
		this.artworkId = artworkId;
		this.artworkTitle = artworkTitle;
		this.artworkImage = artworkImage;
		this.name = name;
	}

	public int getArtworkId() {
		return artworkId;
	}
	
	public void setArtworkId(int artworkId) {
		this.artworkId = artworkId;
	}



	public String getArtworkTitle() {
		return artworkTitle;
	}

	public void setArtworkTitle(String artworkTitle) {
		this.artworkTitle = artworkTitle;
	}

	public String getArtworkImage() {
		return artworkImage;
	}

	public void setArtworkImage(String artworkImage) {
		this.artworkImage = artworkImage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getArtworkCount() {
		return artworkCount;
	}

	public void setArtworkCount(long artworkCount) {
		this.artworkCount = artworkCount;
	}

}
