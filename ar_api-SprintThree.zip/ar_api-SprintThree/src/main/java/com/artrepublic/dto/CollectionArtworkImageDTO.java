package com.artrepublic.dto;

public class CollectionArtworkImageDTO {

	private String title;
	private String artworkImage;
	private int collectionCount;
	private long collectionArtworkCount;

	public CollectionArtworkImageDTO(String title, String artworkImage, long collectionArtworkCount) {
		this.title = title;
		this.artworkImage = artworkImage;
		this.collectionArtworkCount = collectionArtworkCount;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getArtworkImage() {
		return artworkImage;
	}

	public void setArtworkImage(String artworkImage) {
		this.artworkImage = artworkImage;
	}

	public int getCollectionCount() {
		return collectionCount;
	}

	public void setCollectionCount(int collectionCount) {
		this.collectionCount = collectionCount;
	}

	public long getCollectionArtworkCount() {
		return collectionArtworkCount;
	}

	public void setCollectionArtworkCount(long collectionArtworkCount) {
		this.collectionArtworkCount = collectionArtworkCount;
	}

}
