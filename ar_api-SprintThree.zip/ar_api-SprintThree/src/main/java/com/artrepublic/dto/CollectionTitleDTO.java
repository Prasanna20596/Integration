package com.artrepublic.dto;

public class CollectionTitleDTO {

	private String title;

	public CollectionTitleDTO(String title) {
		super();
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
