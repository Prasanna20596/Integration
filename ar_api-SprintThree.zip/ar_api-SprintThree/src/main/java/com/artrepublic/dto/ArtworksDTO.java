package com.artrepublic.dto;

public class ArtworksDTO {

	private int artworkId;
	private String artworkTitle;
	private String description;
	private String artworkImage;
	private boolean active;
	private String title;
	private int artworkCount;
	
	public ArtworksDTO(int artworkId, String artworkTitle, String description, String artworkImage, boolean active,
			String title) {
		super();
		this.artworkId = artworkId;
		this.artworkTitle = artworkTitle;
		this.description = description;
		this.artworkImage = artworkImage;
		this.active = active;
		this.title = title;
	}

	public int getArtworkId() {
		return artworkId;
	}

	public void setArtworkId(int artworkId) {
		this.artworkId = artworkId;
	}

	public String getArtworkTitle() {
		return artworkTitle;
	}

	public void setArtworkTitle(String artworkTitle) {
		this.artworkTitle = artworkTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getArtworkImage() {
		return artworkImage;
	}

	public void setArtworkImage(String artworkImage) {
		this.artworkImage = artworkImage;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getArtworkCount() {
		return artworkCount;
	}

	public void setArtworkCount(int artworkCount) {
		this.artworkCount = artworkCount;
	}

}
