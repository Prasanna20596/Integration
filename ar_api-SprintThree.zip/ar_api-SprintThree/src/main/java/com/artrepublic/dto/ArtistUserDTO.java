package com.artrepublic.dto;

public class ArtistUserDTO {

	private int artistId;
	private String profilePicture;
	private String name;
	private String email;
	private String bio;
	private long contactNo;
	private String address;
	private boolean active;
	private String joinDateFormatted;
	
	public ArtistUserDTO(String profilePicture, String name, String email, String bio, long contactNo, String address) {
		super();
		this.profilePicture = profilePicture;
		this.name = name;
		this.email = email;
		this.bio = bio;
		this.contactNo = contactNo;
		this.address = address;
	}

	public ArtistUserDTO() {
		
	}

	public int getArtistId() {
		return artistId;
	}

	public void setArtistId(int artistId) {
		this.artistId = artistId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getProfilePicture() {
		return profilePicture;
	}

	public void setProfilePicture(String profilePicture) {
		this.profilePicture = profilePicture;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public long getContactNo() {
		return contactNo;
	}

	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getJoinDateFormatted() {
		return joinDateFormatted;
	}

	public void setJoinDateFormatted(String joinDateFormatted) {
		this.joinDateFormatted = joinDateFormatted;
	}

}