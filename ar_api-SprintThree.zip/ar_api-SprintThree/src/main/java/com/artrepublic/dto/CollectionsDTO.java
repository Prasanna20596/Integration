package com.artrepublic.dto;

public class CollectionsDTO {

	private int collectionId;
	private String title;
	private String description;
	private boolean active;
	private int collectionCount;

	public CollectionsDTO(int collectionId, String title, String description, boolean active) {
		this.collectionId = collectionId;
		this.title = title;
		this.description = description;
		this.active = active;
	}

	public int getCollectionId() {
		return collectionId;
	}

	public void setCollectionId(int collectionId) {
		this.collectionId = collectionId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getCollectionCount() {
		return collectionCount;
	}

	public void setCollectionCount(int collectionCount) {
		this.collectionCount = collectionCount;
	}

}