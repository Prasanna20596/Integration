package com.artrepublic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.artrepublic.dto.ArtistArtworkDTO;
import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.dto.ArtworksDTO;
import com.artrepublic.dto.CollectionTitleDTO;
import com.artrepublic.dto.CollectionsDTO;
import com.artrepublic.service.ArtistService;

/**This controller class serves as a rest controller for handling artist-related HTTP requests.
 * It provides endpoints for update the artist profile, collection management,artwork management 
 *  based on artist from artist service business logic.
 * Cross-origin resource sharing (CORS) is enabled to allow communication with a front-end 
 *  application running at http://localhost:3000.
 */
@RestController
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
public class ArtistController {

	@Autowired
	private ArtistService artistService;
	
	/**Handles Get request for retrieve the artist profile details
	 * @param email
	 * @return ArtistUserDTO
	 */
	@PreAuthorize("hasRole('Artist')")
	@GetMapping("/profile")
	public ResponseEntity<ArtistUserDTO> getArtistProfileDetailsByEmail(String email){
		return artistService.getArtistProfileDetailsByEmail(email);
	}
	
	/**Handles Put request for update the artist profile details
	 * @param profilePicture
	 * @param bio
	 * @param address
	 * @param contactNo
	 * @param name
	 * @param email
	 * @return String
	 */
	@PreAuthorize("hasRole('Artist')")
	@PutMapping("/updateartistprofile")
    public ResponseEntity<String> updateArtistProfileDetails(@RequestParam(required = false) MultipartFile profilePicture,
                                                      @RequestParam String bio, @RequestParam String address,
                                                      @RequestParam long contactNo, @RequestParam String name,
                                                      @RequestParam String email) {
        return artistService.updateArtistProfileDetails(profilePicture, bio, address, contactNo, name, email);
    }
	
	/**Handles Post request for save the artist collection details
	 * @param title
	 * @param description
	 * @param active
	 * @param email
	 * @return String
	 */
	@PreAuthorize("hasRole('Artist')")
	@PostMapping("/savecollection")
	public ResponseEntity<String> saveCollectionDetails(@RequestParam String title,
			                       @RequestParam String description,@RequestParam boolean active,String email){		
		return artistService.saveCollectionsDetails(title, description, active, email);
	}
	
	/**Handles Get request for retrieve the artist collection details
	 * @param email
	 * @return CollectionsDTO
	 */
	@PreAuthorize("hasRole('Artist')")
	@GetMapping("/viewcollection")
	public ResponseEntity<List<CollectionsDTO>> getCollectionDetailsByArtistEmail(String email){
		return artistService.getCollectionDetailsByArtistEmail(email);
	}
	
	/**Handles Get request for retrieve the artist collection details by collectionId
	 * @param collectionId
	 * @return CollectionsDTO
	 */
	@PreAuthorize("hasRole('Artist')")
	@GetMapping("/collection/{collectionId}")
	public ResponseEntity<CollectionsDTO> getCollectionDetailsById(@PathVariable int collectionId) {
		return artistService.getCollectionDetailsById(collectionId);
	}
	
	/**Handles Put request for update the artist collection details by collectionId
	 * @param collectionId
	 * @param title
	 * @param description
	 * @param active
	 * @return String
	 */
	@PreAuthorize("hasRole('Artist')")
	@PutMapping("/updatecollection/{collectionId}")
	public ResponseEntity<String> updateCollectionDetailsById(@PathVariable int collectionId, 
			                   @RequestParam String title , @RequestParam String description, 
			                   @RequestParam boolean active ){
		return artistService.updateCollectionDetailsById(collectionId, title, description, active);
	}
	
	/**Handles Put request for enable/disable the artist collection by collectionId
	 * @param collectionId
	 * @return String
	 */
	@PreAuthorize("hasRole('Artist')")
	@PutMapping("/updatecollectionstatus/{collectionId}")
	public ResponseEntity<String> enableAndDisableCollectionById(@PathVariable int collectionId) {
		return artistService.enableAndDisableCollectionById(collectionId);
	}
	
	/**Handles Get request for retrieve the title lists by artist
	 * @param email
	 * @return CollectionTitleDTO
	 */
	@PreAuthorize("hasRole('Artist')")
	@GetMapping("/collectiontitle")
	public ResponseEntity<List<CollectionTitleDTO>> getCollectionTitleByEmail(String email){
		return artistService.getCollectionTitleListByEmail(email);
	}
	
	/**Handles Post request for save the artist artwork
	 * @param artworkTitle
	 * @param description
	 * @param active
	 * @param title
	 * @param email
	 * @param artworkImage
	 * @return String
	 */
	@PreAuthorize("hasRole('Artist')")
	@PostMapping("/saveartwork")
	public ResponseEntity<String> saveArtworkDetails(@RequestParam String artworkTitle, 
			                    @RequestParam String description, @RequestParam boolean active,
			                    @RequestParam String title,String email,
			                    @RequestParam MultipartFile artworkImage){
		return artistService.saveArtworkDetails(artworkTitle, description, active, artworkImage, email, title);
	}
	
	/**Handles Get request for retreive the artist artwork details
	 * @param email
	 * @return ArtworksDTO
	 */
	@PreAuthorize("hasRole('Artist')")
	@GetMapping("/artworks")
	public ResponseEntity<List<ArtworksDTO>> getArtworksByArtistEmail(String email){
		return artistService.getArtworksByArtistEmail(email);
	}
	
	/**Handles Get request for retrieve the artist artworks details by artworkId
	 * @param artworkId
	 * @param email
	 * @return ArtworksDTO
	 */
	@PreAuthorize("hasRole('Artist')")
	@GetMapping("/artwork/{artworkId}")
	public ResponseEntity<ArtworksDTO> getArtworkByIdAndArtistEmail(@PathVariable int artworkId, String email){
		return artistService.getArtworkByIdAndArtistEmail(artworkId, email);
	}
	
	/**Handles Put request for update the artist artwork details by artworkId
	 * @param artworkId
	 * @param artworkTitle
	 * @param description
	 * @param active
	 * @param title
	 * @param email
	 * @param artworkImage
	 * @return String
	 */
	@PreAuthorize("hasRole('Artist')")
	@PutMapping("/updateartwork/{artworkId}")
	public ResponseEntity<String> updateArtworkDetailsById(@PathVariable int artworkId, @RequestParam String artworkTitle, 
			                    @RequestParam String description, @RequestParam boolean active,
			                    @RequestParam String title,String email,
			                    @RequestParam(required = false) MultipartFile artworkImage){
		return artistService.updateArtworkDetailsById(artworkId, artworkTitle, description, active, artworkImage,
				        email, title);
	}
	
	/**Handles Put request for enable/disable the artist artwork by artworkId
	 * @param artworkId
	 * @return String
	 */
	@PreAuthorize("hasRole('Artist')")
	@PutMapping("/updateartworkstatus/{artworkId}")
	public ResponseEntity<String> enableAndDisableArtworkById(@PathVariable int artworkId) {
		return artistService.enableAndDisableArtworkById(artworkId);
	}	
	
	/**Handles Get request for retrieve all artist artworks
	 * @param email
	 * @return ArtistArtworkDTO
	 */
	@PreAuthorize("hasRole('Artist')")
	@GetMapping("/artistartworks")
	public ResponseEntity<List<ArtistArtworkDTO> > getAllArtworks(String email){
		return artistService.getAllArtworks(email);	
	}
	
}
