package com.artrepublic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.artrepublic.dto.ArtistArtworkDTO;
import com.artrepublic.dto.ArtistProfileDTO;
import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.dto.CollectionArtworkImageDTO;
import com.artrepublic.service.ArtrepublicService;

/**This controller class serves as a rest controller for handling general HTTP requests for admin and artist.
 * It provides endpoints for get the artist details,retrieve the collection and artwork details 
 *  based on artist from artrepublic service business logics.
 * Cross-origin resource sharing (CORS) is enabled to allow communication with a front-end 
 *  application running at http://localhost:3000.
 */
@RestController
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
public class ArtrepublicController {

	@Autowired
	private ArtrepublicService artrepublicService;
	
	/**Handles Get request for retrieve the artist details and collection counts,artwork counts
	 * @param email
	 * @return ArtistProfileDTO
	 */
	@PreAuthorize("hasAnyRole('Owner','Artist')")
	@GetMapping("/artists")
	public ResponseEntity<List<ArtistProfileDTO>> getArtistDetailsWithoutCurrentArtist(String email){
		return artrepublicService.getArtistDetailsWithoutCurrentArtist(email);
	}
	
	/**Handles Get request for retrieve the artist basic details by name
	 * @param name
	 * @return ArtistUserDTO
	 */
	@PreAuthorize("hasAnyRole('Owner','Artist')")
	@GetMapping("/{name}")
	public ResponseEntity<ArtistUserDTO> getArtistProfileAndCollectionAndArtwork(@PathVariable String name){
		return artrepublicService.getArtistProfileDetailsByName(name);
	}
	
	/**Handles Get request for retrieve the artist artworks by name
	 * @param name
	 * @return ArtistArtworkDTO
	 */
	@PreAuthorize("hasAnyRole('Owner','Artist')")
	@GetMapping("/{name}/artworks")
	public ResponseEntity<List<ArtistArtworkDTO>> getArtworkDetailsAndCountByArtistName(@PathVariable String name){
		return artrepublicService.getArtworkDetailsAndCountByArtistName(name);
	}
	
	/**Handles Get request for retrieve the artist collections by name
	 * @param name
	 * @return CollectionArtworkImageDTO
	 */
	@PreAuthorize("hasAnyRole('Owner','Artist')")
	@GetMapping("/{name}/collections")
	public ResponseEntity<List<CollectionArtworkImageDTO>> getCollectionDetailsAndCountByArtistName(@PathVariable String name){
		return artrepublicService.getCollectionDetailsAndCountByArtistName(name);
	}
	
}
