package com.artrepublic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.entity.Roles;
import com.artrepublic.pojo.RequestPojo;
import com.artrepublic.service.AdminService;

/**This controller class serves as a rest controller for handling admin-related HTTP requests.
 * It provides endpoints for save rolls,admins and manage the artists from admin service 
 *  business logic.
 * Cross-origin resource sharing (CORS) is enabled to allow communication with a front-end application running
 *  at http://localhost:3000.
 */
@RestController
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	/**Handles Post request for save the roll details
	 * @param roles
	 * @return String
	 */
	@PostMapping("/saverole")
	public ResponseEntity<String> saveRollDetails(@RequestBody Roles roles) {
		return adminService.saveRollDetails(roles);
	}
	
	/**Handles Post request for save the admin details
	 * @param requestPojo
	 * @return String
	 */
	@PostMapping("/saveadmin")
	public ResponseEntity<String> saveAdminDetails(@RequestBody RequestPojo requestPojo) {
		return adminService.saveAdminDetails(requestPojo);
	}
	
	/**Handles Post request for save the artist details
	 * @param requestPojo
	 * @return String
	 */
	@PreAuthorize("hasRole('Owner')")
	@PostMapping("/saveartist")
	public ResponseEntity<String> saveArtistDetails(@RequestBody RequestPojo requestPojo){
		return adminService.saveArtistDetails(requestPojo);
	}
	
	/**Handles Get request for retrieve the all artist details
	 * @return ArtistUserDTO
	 */
	@PreAuthorize("hasRole('Owner')")
	@GetMapping("/viewartist")
	public ResponseEntity<List<ArtistUserDTO>> getAllArtistDetails(){
		return adminService.getAllArtistDetails();
	}
	
	/**Handles Put request for enable/disable the artist
	 * @param artistId
	 * @return String
	 */
	@PreAuthorize("hasRole('Owner')")
    @PutMapping("/updateartiststatus/{artistId}")
	public ResponseEntity<String> enableAndDisableArtistById(@PathVariable int artistId){
		return adminService.enableAndDisableArtistById(artistId);
	}

}
