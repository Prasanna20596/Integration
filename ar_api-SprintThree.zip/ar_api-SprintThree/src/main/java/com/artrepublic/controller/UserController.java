package com.artrepublic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.artrepublic.request.TokenRefreshRequest;
import com.artrepublic.response.TokenRefreshResponse;
import com.artrepublic.request.LoginRequest;
import com.artrepublic.response.LoginResponse;
import com.artrepublic.service.UserService;

/** This controller class serves as a rest controller for handling user-related HTTP requests.
 * It provides endpoints for user authentication, token refresh, forget password,
 *  OTP validation, and password reset from user service business logic.
 *  Cross-origin resource sharing (CORS) is enabled to allow communication with a front-end application running
 * at http://localhost:3000.
 */
@RestController
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
public class UserController {

	@Autowired
	private UserService userService;
	
	/**Handles Post request for user login authentication
	 * @param loginRequest
	 * @return LoginResponse
	 */
	@PostMapping("/")
	public ResponseEntity<LoginResponse> getLoginResponse(@RequestBody LoginRequest loginRequest) {
		return userService.getLoginResponse(loginRequest);
	}
	
	/**Handles Post request for refreshing access token
	 * @param tokenRefreshRequest
	 * @return TokenRefreshResponse
	 */
	@PostMapping("/refreshtoken")
	public TokenRefreshResponse getRefreshTokenResponse(@RequestBody TokenRefreshRequest tokenRefreshRequest) {
		return userService.getTokenRefreshResponse(tokenRefreshRequest);
	}

	/**Handles Post request for sending forget password emails
	 * @param email
	 * @return String
	 */
	@PostMapping("/forgetpassword/{email}")
	public ResponseEntity<String> getForgetPasswordMail(@PathVariable String email) {
		return userService.forgetpasswordByEmail(email);
	}
	
	/**Handles Post request for validating otp
	 * @param email
	 * @param enterOtp
	 * @return String
	 */
	@PostMapping("/validateOTP")
	public ResponseEntity<String> validateOTPByEmail(String email,@RequestParam int enterOtp){
		return userService.validateOTPByEmail(email, enterOtp);
	}
	
	/**Handles Post request for resetting the passwords	
	 * @param email
	 * @param password
	 * @param confirmPassword
	 * @return String
	 */
	@PostMapping("/resetpassword")
	public ResponseEntity<String> passwordResetByEmail(String email,@RequestParam String password,
                                                             @RequestParam String confirmPassword){
		return userService.passwordResetByEmail(email, password, confirmPassword);
	}

}
