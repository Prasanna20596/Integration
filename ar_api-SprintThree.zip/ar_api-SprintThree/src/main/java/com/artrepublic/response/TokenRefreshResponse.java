package com.artrepublic.response;

public class TokenRefreshResponse {

	private String newToken;
	private String refreshMessage;

	public TokenRefreshResponse(String newToken, String refreshMessage) {
		this.newToken = newToken;
		this.refreshMessage = refreshMessage;
	}

	public String getNewToken() {
		return newToken;
	}

	public void setNewToken(String newToken) {
		this.newToken = newToken;
	}

	public String getRefreshMessage() {
		return refreshMessage;
	}

	public void setRefreshMessage(String refreshMessage) {
		this.refreshMessage = refreshMessage;
	}

}
