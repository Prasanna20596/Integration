package com.artrepublic.service;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.artrepublic.request.TokenRefreshRequest;
import com.artrepublic.response.TokenRefreshResponse;
import com.artrepublic.request.LoginRequest;
import com.artrepublic.response.LoginResponse;

public interface UserService {
	
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException;
	
	public ResponseEntity<LoginResponse> getLoginResponse(LoginRequest loginRequest);
	
	public TokenRefreshResponse getTokenRefreshResponse(TokenRefreshRequest refreshRequest);
		
	public ResponseEntity<String> forgetpasswordByEmail(String email);
	
	public ResponseEntity<String> validateOTPByEmail(String email,int enterOtp);
	
	public ResponseEntity<String> passwordResetByEmail(String email, String password,String confirmPassword);
	
}
