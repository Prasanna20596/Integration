package com.artrepublic.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.artrepublic.dto.ArtistArtworkDTO;
import com.artrepublic.dto.ArtistProfileDTO;
import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.dto.CollectionArtworkImageDTO;

public interface ArtrepublicService {

	  public ResponseEntity<List<ArtistProfileDTO>> getArtistDetailsWithoutCurrentArtist(String email);
	  
	  public ResponseEntity<ArtistUserDTO> getArtistProfileDetailsByName(String name);
	  
	  public ResponseEntity<List<CollectionArtworkImageDTO>> getCollectionDetailsAndCountByArtistName(String name);
	  
	  public ResponseEntity<List<ArtistArtworkDTO>> getArtworkDetailsAndCountByArtistName(String name);
	  
}
