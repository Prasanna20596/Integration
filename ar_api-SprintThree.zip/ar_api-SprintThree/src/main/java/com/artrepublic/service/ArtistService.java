package com.artrepublic.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.artrepublic.dto.ArtistArtworkDTO;
import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.dto.ArtworksDTO;
import com.artrepublic.dto.CollectionTitleDTO;
import com.artrepublic.dto.CollectionsDTO;

public interface ArtistService {
	
	public ResponseEntity<ArtistUserDTO> getArtistProfileDetailsByEmail(String email);
	
	public ResponseEntity<String> updateArtistProfileDetails(MultipartFile profilePicture, String bio, 
			               String address, long contactNo, String name, String email);
	
	public ResponseEntity<String> saveCollectionsDetails(String title, String description, boolean active,
	                                                          String email);

    public ResponseEntity<List<CollectionsDTO>> getCollectionDetailsByArtistEmail(String email);
    
    public ResponseEntity<CollectionsDTO> getCollectionDetailsById(int collectionId);
    
    public ResponseEntity<String> updateCollectionDetailsById(int collectionId, String title,
	         String description, boolean active);
    
    public ResponseEntity<String> enableAndDisableCollectionById(int collectionId);
    
    public ResponseEntity<List<CollectionTitleDTO>> getCollectionTitleListByEmail(String email);
    
    public ResponseEntity<String> saveArtworkDetails(String artworkTitle, String description,
	        boolean active, MultipartFile artworkImage, String email, String title); 
    
    public ResponseEntity<List<ArtworksDTO>> getArtworksByArtistEmail(String email);
    
    public ResponseEntity<ArtworksDTO> getArtworkByIdAndArtistEmail(int artworkId, String email);
    
    public ResponseEntity<String> updateArtworkDetailsById(int artworkId, String artworkTitle, String description,
    		  boolean active, MultipartFile artworkImage, String email, String title);
    
    public ResponseEntity<String> enableAndDisableArtworkById(int artworkId);
    
    public ResponseEntity<List<ArtistArtworkDTO>> getAllArtworks(String email);
    
}
