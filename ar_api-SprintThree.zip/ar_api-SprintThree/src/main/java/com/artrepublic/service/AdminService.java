package com.artrepublic.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.entity.Roles;
import com.artrepublic.pojo.RequestPojo;

public interface AdminService {

	ResponseEntity<String> saveRollDetails(Roles roles);
	
	ResponseEntity<String> saveAdminDetails(RequestPojo requestPojo);
	
    public ResponseEntity<String> saveArtistDetails(RequestPojo requestPojo);
    
    public ResponseEntity<List<ArtistUserDTO>> getAllArtistDetails();
	
	public ResponseEntity<String> enableAndDisableArtistById(int artistId);
	
	
}
