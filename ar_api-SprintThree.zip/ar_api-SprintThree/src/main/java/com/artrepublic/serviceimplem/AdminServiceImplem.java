package com.artrepublic.serviceimplem;

import java.io.File;
import java.io.FileInputStream;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.entity.ArtistInfo;
import com.artrepublic.entity.Roles;
import com.artrepublic.entity.User;
import com.artrepublic.pojo.RequestPojo;
import com.artrepublic.repository.ArtistRepository;
import com.artrepublic.repository.RoleRepository;
import com.artrepublic.repository.UserRepository;
import com.artrepublic.service.AdminService;


/** This class provides the implementation of the Adminservice interface.
 * It contains methods to handle admin-related operations such as managing roles,artist and send 
 * the login credential for registered artist.
 * Additionally, it handles the processing of profile pictures for presentation.
 * @author prasanna
 */
@Service
public class AdminServiceImplem implements AdminService {

	private static final Logger logger = LoggerFactory.getLogger(AdminServiceImplem.class);
	
	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private ArtistRepository artistRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private JavaMailSender javaMailSender;

	@Value("${spring.mail.username}")
	private String sender;
	
	@Value("${file.upload-artistDirectory}")
	private String artistDirectory;

	/**
	 *This method is used to save the password as encrypt type in database 
	 *
	 *@param password
	 *@return string
	 */
	public String getEncodedPassword(String password) {
		logger.info("Password is converted as encrypt");
		return passwordEncoder.encode(password);
	}

	/**
	 *This method receives a Roles object, sets the role name with a prefix to save 
	 *the roll details in database    
	 *
	 *@param roles
	 *@return string
	 */
	public ResponseEntity<String> saveRollDetails(Roles roles) {
		logger.info("Received request to save the role details");
		try {
			roles.setRoleName("ROLE_" + roles.getRoleName());
			roleRepository.save(roles);
			logger.info("Role details are added");
			return ResponseEntity.ok("Role details are added...!");
		} catch (Exception e) {
			logger.error("An error occurred while adding role details");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to add!..");
		}	
	}
	
	/**
	 *This method receives a RequestPojo object, and find the role id based on passed role
	 *from Roles to save the admin details and admin role details in database    
	 *
	 *@param requestPojo
	 *@return string
	 */
	public ResponseEntity<String> saveAdminDetails(RequestPojo requestPojo) {
		logger.info("Received request to save the admin details");
		try {
			Roles roles = new Roles();
			User user = new User();

			user.setName(requestPojo.getName());
			user.setEmail(requestPojo.getEmail());
			user.setPassword(getEncodedPassword(requestPojo.getPassword()));
			user.setActive(requestPojo.isActive());

			String roleName = "ROLE_Owner";
			Integer roleId = roleRepository.findRoleIdByRoleName(roleName);

			roles.setRoleId(roleId);

			user.setRoles(roles);

			userRepository.save(user);
			logger.info("Admin user details added successfully");
			return ResponseEntity.ok("User details are added...");
		} catch (Exception e) {
			logger.error("An error occurred while adding admin user details");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to add user details!..");
		}
	}

	/**
	 *This method receives a RequestPojo object, and find the role id based on passed role
	 *from Roles to save the admin details and admin role details in database.
	 *
	 *@param requestPojo
	 *@return string
	 */
	public ResponseEntity<String> saveArtistDetails(RequestPojo requestPojo) {
		logger.info("Received request to save the artist basic and user details");
		try {
			ArtistInfo artist = new ArtistInfo();
			User user = new User();
			Roles roles = new Roles();

			artist.setBio(requestPojo.getBio());
			artist.setProfilePicture(requestPojo.getProfilePicture());
			artist.setGender(requestPojo.getGender());
			artist.setAddress(requestPojo.getAddress());
			artist.setContactNo(requestPojo.getContactNo());
			artist.setJoinDate(new Date());

			user.setActive(requestPojo.isActive());
			user.setName(requestPojo.getName());
			user.setEmail(requestPojo.getEmail());

			String randomPassword = generateRandomPassword(12);
			user.setPassword(getEncodedPassword(randomPassword));
			System.out.println("DB saved password is: "+randomPassword);

			String roleName = "ROLE_Artist";
			Integer roleId = roleRepository.findRoleIdByRoleName(roleName);

			roles.setRoleId(roleId);

			user.setRoles(roles);
			user.setUserId(requestPojo.getRoleId());

			artist.setUser(user);

			if (userRepository.existsByEmail(requestPojo.getEmail())) {
				logger.warn("Email is already exist");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is already exist");
				
			} else {
				userRepository.save(user);
				artistRepository.save(artist);
				String mailResult = sendSuccessAndLoginCredentialMail(requestPojo, randomPassword);
				logger.info("Artist basic and user details are successfully added");
				return ResponseEntity.ok(mailResult);
			}
		} catch (Exception e) {
			logger.error("An error occurred while adding artist basic and user details");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to add");
		}
	}

	/**
	 *This method used to generate the 12 digit random password for login purpose
	 *
	 *@param length
	 *@return string
	 */
	public String generateRandomPassword(int length) {
		logger.info("Received request to generate the random password for login");
		try {
			String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*-";
			SecureRandom secureRandom = new SecureRandom();
			StringBuilder password = new StringBuilder(length);
			for (int i = 0; i < length; i++) {
				int randomIndex = secureRandom.nextInt(characters.length());
				password.append(characters.charAt(randomIndex));
			}
			logger.info("Random password is successfully generated");
			return password.toString();
		} catch (Exception e) {
			logger.error("An error occured while generating the random password");
			return "Unable to generate!..";
		}
	}

	/**
	 *This method receives a RequestPojo object and random password to send the email with name,
	 *email,password for that user and get the password form generateRandomPassword method to
	 *return it     
	 *
	 *@param requestPojo,randomPassword
	 *@return string
	 */
	public String sendSuccessAndLoginCredentialMail(RequestPojo requestPojo, String randomPassword) {
		logger.info("Received request to send the email at user email");
		try {
			SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
			simpleMailMessage.setFrom(sender);
			simpleMailMessage.setTo(requestPojo.getEmail());
			simpleMailMessage.setSubject("Welcome to artrepublic!.. ");
			simpleMailMessage.setText("Hi " + requestPojo.getName() + ", Your details added in artrepublic"
			        + "\n" + "\n" + "Email: " + requestPojo.getEmail() 
			        + "\n" + "\n" + "Password: " + randomPassword);
			javaMailSender.send(simpleMailMessage);
			logger.info("Email sent successfully to that email");
			return "Artist Details are added & Mail is successfully sended ";
		} catch (Exception e) {
			logger.error("An error occurred while sending mail");
			return "Error while sending mail";
		}
	}

	/**
	 *This method is used to retrieve the artist basic and user details
	 *
	 *@return ArtistUserDTO
	 */
	public ResponseEntity<List<ArtistUserDTO>> getAllArtistDetails() {
		logger.info("Received request to get all artist details");
	    try {
	        List<ArtistInfo> artistInfos = artistRepository.findAll();
	        List<ArtistUserDTO> artistUserDTOs = new ArrayList<>();
	        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM-dd-yyyy");

	        for (ArtistInfo artistInfo : artistInfos) {
	            ArtistUserDTO artistUserDTO = new ArtistUserDTO();

	            artistUserDTO.setArtistId(artistInfo.getArtistId());
	            artistUserDTO.setProfilePicture(artistInfo.getProfilePicture());
	            artistUserDTO.setBio(artistInfo.getBio());
	            artistUserDTO.setAddress(artistInfo.getAddress());
	            artistUserDTO.setName(artistInfo.getUser().getName());
	            artistUserDTO.setEmail(artistInfo.getUser().getEmail());
	            artistUserDTO.setContactNo(artistInfo.getContactNo());
	            artistUserDTO.setActive(artistInfo.getUser().isActive());

	            if (artistInfo.getJoinDate() != null) {
	                artistUserDTO.setJoinDateFormatted(dateFormat.format(artistInfo.getJoinDate()));
	            }
	            processProfilePicture(artistUserDTO);

	            artistUserDTOs.add(artistUserDTO);
	        }
	        logger.info("Retrieved all artist details successfully");
	        return ResponseEntity.ok(artistUserDTOs);
	    } catch (Exception e) {
	    	logger.error("An error occurred while getting all artist details");
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}

	
	/**
	 * This method receive the ArtistUserDTO object to get the profilepicture based on name and covert that picture as
	 *  base64.
	 * 
	 * @param artistUserDTO
	 */
	private void processProfilePicture(ArtistUserDTO artistUserDTO) {
	    String profilePictureName=artistUserDTO.getProfilePicture();
		if (profilePictureName != null && !profilePictureName.isEmpty()) {	
	        String profilePicturePath = artistDirectory + profilePictureName;
	        try {
	            FileInputStream fileInputStream = new FileInputStream(new File(profilePicturePath));
	            byte[] image = IOUtils.toByteArray(fileInputStream);
	            String base64ProfileImage = Base64.getEncoder().encodeToString(image);
	            artistUserDTO.setProfilePicture(base64ProfileImage);
	            logger.info("Profile picture processed successfully");
	        } catch (Exception e) {
	        	logger.error("An error occurred while processing profile picture for artist");
	        }    
	    } else {
	    	logger.info("No profile picture found for artist");
	        artistUserDTO.setProfilePicture(null);
	    }
	}
	
	/**
	 * This method is used to enable and disable the artist
	 * 
	 * @param artistId
	 * @return String
	 *
	 */
	public ResponseEntity<String> enableAndDisableArtistById(int artistId) {
		logger.info("Received request to enable/disable artist");
		try {
			Optional<ArtistInfo> existingArtist = artistRepository.findById(artistId);
			if (existingArtist.isPresent()) {
				ArtistInfo artistInfo=existingArtist.get();
				User existingUser = artistInfo.getUser();
				existingUser.setActive(!existingUser.isActive());
				userRepository.save(existingUser);
				String statusMessage=existingUser.isActive() ? "Artist is active" : "Artist is inactive";
				logger.info(statusMessage);
				return ResponseEntity.ok(statusMessage);
			} else {
				logger.warn("Artis not found for that ID");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Artist not found");
			}
		} catch (Exception e) {
			logger.error("An error occur while enable/disable the artist");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to change!...");
		}
	}

}
