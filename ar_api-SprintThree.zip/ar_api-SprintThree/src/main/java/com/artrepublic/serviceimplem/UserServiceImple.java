package com.artrepublic.serviceimplem;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.artrepublic.entity.PasswordReset;
import com.artrepublic.entity.User;
import com.artrepublic.entity.UserLoginDetails;
import com.artrepublic.repository.PasswordResetRepository;
import com.artrepublic.repository.UserRepository;
import com.artrepublic.request.LoginRequest;
import com.artrepublic.request.TokenRefreshRequest;
import com.artrepublic.response.LoginResponse;
import com.artrepublic.response.TokenRefreshResponse;
import com.artrepublic.service.UserService;
import com.artrepublic.util.JwtUtil;

/** This class provides the implementation of the UserService & UserDetailsService interfaces.
 * 
 * It contains methods related to user management and password resets functionalities
 * 
 * It utilizes Spring Security, JWT tokens, and email services for secure user authentication. 
 */
@Service
public class UserServiceImple implements UserService, UserDetailsService {

	private static final Logger logger = LoggerFactory.getLogger(UserServiceImple.class);
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordResetRepository passwordResetRepository;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private JavaMailSender javaMailSender;

	@Value("${spring.mail.username}")
	private String sender;

	/**
	 *This method is used to save the password as encrypt type in database 
	 *
	 *@param password
	 *@return string
	 */
	public String getEncodedPassword(String password) {
		logger.info("Password is converted as encrypt");
		return passwordEncoder.encode(password);
	}

    /** This method is used to load the user details based on user email
     *
     *@param email
     */
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
    	logger.info("Attempting to load user by username: {}", email);
    	try { 
            User user = userRepository.findByEmail(email);
            if (user == null) {
                logger.warn("User not found");
                throw new UsernameNotFoundException("Email not found");
            }
            logger.info("User loaded successfully");
            return new UserLoginDetails(user);
        } catch (Exception e) {
            logger.error("An error occurred while loading user by username");
            throw new UsernameNotFoundException("Error loading user by username", e);
        }
    }

	/** This method is used to generate the token with correct email and password, else return
	 * the error messages
	 * 
	 * @param loginRequest
	 * @return loginResponse
	 *
	 */
	public ResponseEntity<LoginResponse> getLoginResponse(LoginRequest loginRequest) {
		logger.info("Received request to login the user email");
	    try {
	        User user = userRepository.findByEmail(loginRequest.getEmail());
	        UserDetails userDetails = loadUserByUsername(loginRequest.getEmail());

	        if (user.isActive()) {
	            if (passwordEncoder.matches(loginRequest.getPassword(), userDetails.getPassword())) {
	                String token = jwtUtil.generateToken(userDetails);

	                String roleName = user.getRoles().getRoleName();
	                if (roleName.startsWith("ROLE_")) {
	                    roleName = roleName.substring("ROLE_".length());
	                }

	                LoginResponse loginResponse = new LoginResponse();
	                loginResponse.setToken(token);
	                loginResponse.setEmail(loginRequest.getEmail());
	                loginResponse.setRole(roleName);
	                loginResponse.setName(user.getName());
	                loginResponse.setSuccess(true);
	                loginResponse.setErrorMessage("-");
	                logger.info("Login response generated successfully");
	                return ResponseEntity.ok(loginResponse);
	            } else {
	            	logger.warn("Invalid credentials for login email");
	                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new LoginResponse("Invalid Credential"));
	            }
	        } else {
	        	logger.warn("Account disabled for login email");
	            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new LoginResponse("Your account is disabled"));
	        }
	    } catch (Exception e) {
	    	 logger.error("An error occurred while generating login response");
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new LoginResponse("Internal Server Error"));
	    }
	}

	/** This method is used to generate the refresh token once token is expired
	 * 
	 * @param refreshRequest
	 * @return newToken
	 *
	 */
	public TokenRefreshResponse getTokenRefreshResponse(TokenRefreshRequest refreshRequest) {
		logger.info("Received request for refresh token in refresh response ");
		try {
			String newToken = jwtUtil.getNewAccessToken(refreshRequest);
			logger.info("Token refreshed successfully");
			return new TokenRefreshResponse(newToken,null);
		} catch (Exception e) {
			logger.error("Error occurred while refreshing token");
			return new TokenRefreshResponse(null,"Error to refreshing token");
		}
	}

	/** This method used to generate the otp with 6 digits for reset password
	 * 
	 * @return Integer
	 * @throws Exception
	 */
	private Integer generateOTP() throws Exception {
		logger.info("Received request for otp generation");
	    try {
	        Random random = new Random();
	        int otp = 100000 + random.nextInt(899999);
	        logger.info("Otp generated");
	        return otp;
	    } catch (Exception e) {
	    	logger.error("An error occurred while generating otp");
	        throw new Exception(e); 
	    }
	}

	/** This method is used to send the user name with otp once user is forget the password
	 * @param email
	 * @param otp
	 * @param name
	 * @return String
	 */
	public String sendForgetPasswordMail(String email, int otp, String name) {
		logger.info("Received request to send the forget mail with otp");
		try {
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			mimeMessage.setFrom(new InternetAddress(sender));
			mimeMessage.setRecipients(MimeMessage.RecipientType.TO, email);
			mimeMessage.setSubject("Reset your Artrepubllic password");
			String htmlContent = "Hello, " + name + "<p>Your OTP is: <strong>" + otp + "</strong></p>";
			mimeMessage.setContent(htmlContent, "text/html;");
			javaMailSender.send(mimeMessage);
			logger.info("OTP has been sended your email");
			return "OTP has been sended your email";
		} catch (Exception e) {
			logger.error("An error occurred while sending the mail");
			return "Error while sending mail";
		}
	}

	/** This method is used to save the reset password request details in database and send the
	 * credential to email process.
	 * @param email
	 * @return String
	 */
	public ResponseEntity<String> forgetpasswordByEmail(String email) {
		logger.info("Received request to reset password for email");
		try {
			if (!userRepository.existsByEmail(email)) {
				logger.warn("Email not found");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is not found");
			} else {
				User user = userRepository.findByEmail(email);
				if (user.isActive()) {
					UserDetails userDetails = loadUserByUsername(email);
					PasswordReset passwordReset = new PasswordReset();

					String token = jwtUtil.generateToken(userDetails);
					Integer otp = generateOTP();

					passwordReset.setEmail(email);
					passwordReset.setOtp(otp);
					passwordReset.setToken(token);
					passwordReset.setUser(user);
					passwordReset.setResetDate(LocalDateTime.now());

					passwordResetRepository.save(passwordReset);

					String name = user.getName();
					String mailResult= sendForgetPasswordMail(email, otp, name);
					
					logger.info("Password reset email sent successfully");
					return ResponseEntity.ok(mailResult);
				} else {
					logger.warn("User account is disabled");
					return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Your account is disabled");
				}
			}
		} catch (Exception e) {
			 logger.error("Error occurred while processing forget password request");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unable to connet server!..");
		}
	}

	/** This method is used to validate the enter otp and shared otp is same or not and also check
	 * the token for that otp 
	 * @param email
	 * @param enterOtp
	 * @return String
	 */
	public ResponseEntity<String> validateOTPByEmail(String email, int enterOtp) {
		logger.info("Received request to validate OTP for email");
		try {
			List<PasswordReset> resetEntries = passwordResetRepository.findLatestResetByEmail(email);
			if (!resetEntries.isEmpty()) {
				PasswordReset latestResetEntry = resetEntries.get(0);
				Integer storedOtp = latestResetEntry.getOtp();
				String token = latestResetEntry.getToken();

				UserDetails userDetails = loadUserByUsername(email);
				if (jwtUtil.validateToken(token, userDetails)) {

					if (storedOtp != null && storedOtp == enterOtp) {
						logger.info("OTP is verified successfully");
						return ResponseEntity.ok("OTP is verified");
					} else {
						logger.warn("Invalid OTP");
						return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid OTP");
					}
				} else {
					logger.warn("Unable to validate	");
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to validate");
				}
			} else {
				logger.warn("No reset data found for that email");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No reset data found for the email");
			}
		} catch (Exception e) {
			logger.error("Error occurred while validating OTP");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("OTP is expired");
		}
	}

	/**This method is used to validate the password and confirm password are same and check the
	 *token is valid. 
	 * Once valid to save the updated password details based on email in database
	 * @param email
	 * @param password
	 * @param confirmPassword
	 * @return String
	 */
	public ResponseEntity<String> passwordResetByEmail(String email, String password, String confirmPassword) {
		logger.info("Received request to reset password for email");
		try {
			List<PasswordReset> resetEntries = passwordResetRepository.findLatestResetByEmail(email);
			if (!resetEntries.isEmpty()) {
				PasswordReset latestResetEntry = resetEntries.get(0);
				String token = latestResetEntry.getToken();

				UserDetails userDetails = loadUserByUsername(email);
				if (jwtUtil.validateToken(token, userDetails)) {
					User user = userRepository.findByEmail(email);

					if (password.equals(confirmPassword)) {
						user.setPassword(passwordEncoder.encode(password));
						userRepository.save(user);
						logger.info("Password was successfully updated");
						return ResponseEntity.ok("Password was successfully updated.");
					} else {
						logger.warn("Password and confirm password do not match");
						return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Password and confirm password do not match!..");
					}
				} else {
					logger.warn("Error while updating the password");
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error while updating the password");
				}
			} else {
				logger.warn("No reset data found for that email");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No reset data found for the email");
			}
		} catch (Exception e) {
			logger.error("Error occurred while processing password reset");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Your session is expired");
		}

	}

}
