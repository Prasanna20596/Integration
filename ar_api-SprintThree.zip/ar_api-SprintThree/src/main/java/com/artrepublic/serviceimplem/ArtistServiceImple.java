package com.artrepublic.serviceimplem;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.artrepublic.dto.ArtistArtworkDTO;
import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.dto.ArtworksDTO;
import com.artrepublic.dto.CollectionTitleDTO;
import com.artrepublic.dto.CollectionsDTO;
import com.artrepublic.entity.ArtistInfo;
import com.artrepublic.entity.Artworks;
import com.artrepublic.entity.Collections;
import com.artrepublic.entity.User;
import com.artrepublic.repository.ArtistRepository;
import com.artrepublic.repository.ArtworkRepository;
import com.artrepublic.repository.CollectionRepository;
import com.artrepublic.repository.UserRepository;
import com.artrepublic.service.ArtistService;

/** This class provides the implementation of the ArtistService interface.
 * It contains methods to handle artist-related operations such as displaying
 * artist details, updating profile information, managing collections, and handling artworks.
 * 
 * @author prasanna
 */

@Service
public class ArtistServiceImple implements ArtistService {

	private static final Logger logger = LoggerFactory.getLogger(ArtistServiceImple.class);
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ArtistRepository artistRepository;
	
	@Autowired
	private CollectionRepository collectionRepository;
	
	@Autowired
	private ArtworkRepository artworkRepository;
	
	@Value("${file.upload-artistDirectory}")
	private String artistDirectory;
	
	@Value("${file.upload-collectionDirectory}")
	private String collectionDirectory;

	@Value("${file.upload-artworkDirectory}")
	private String artworkDirectory;
	
	/**This method is used to dispaly the artist details based on email
	 * 
	 * @param email
	 * @return artistUserDTO
	 *
	 */
	public ResponseEntity<ArtistUserDTO> getArtistProfileDetailsByEmail(String email){
		logger.info("Received request to display the artist details based on email");
		try {
			ArtistUserDTO artistUserDTO=artistRepository.findArtistDetailsByEmail(email);
			if (artistUserDTO!=null) {
				String profilePictureName=artistUserDTO.getProfilePicture();
				if (profilePictureName!=null && !profilePictureName.isEmpty()) {
					String profilePicturePath=artistDirectory+profilePictureName;
					try {
						FileInputStream fileInputStream=new FileInputStream(new File(profilePicturePath));
						byte[] image=IOUtils.toByteArray(fileInputStream);
						String base64ProfileImage=Base64.getEncoder().encodeToString(image);
						artistUserDTO.setProfilePicture(base64ProfileImage);
					} catch (Exception e) {
						System.out.println(e);
					}
				} else {
					artistUserDTO.setProfilePicture(null);
				}
				logger.info("Your details is successfully displayed");
				return ResponseEntity.ok(artistUserDTO);	
			}else {
				logger.warn("Unable to find the email");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
		} catch (Exception e) {
			logger.error("An error occurred while fetch the details on email");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}
	
	/** This method is used to update the profile details artist itself.
	 * 
	 * @param profilePicture
	 * @param bio
	 * @param address
	 * @param contactNo
	 * @param email
	 * @return String
	 *
	 */
	public ResponseEntity<String> updateArtistProfileDetails(MultipartFile profilePicture, String bio, String address,
			                long contactNo, String name, String email) {
		logger.info("Received request to update the artist profile details");
		try {
			User existingUser = userRepository.findByEmail(email);
			if (existingUser != null) {
				ArtistInfo existingArtist = artistRepository.findByUserUserId(existingUser.getUserId());
				if (profilePicture != null && !profilePicture.isEmpty()) {
					String originalFilename = profilePicture.getOriginalFilename();
					String filePath = Paths.get(artistDirectory, originalFilename).toString();
					Files.copy(profilePicture.getInputStream(), Paths.get(filePath),StandardCopyOption.REPLACE_EXISTING);
					existingArtist.setProfilePicture(originalFilename);
				}
				
				existingArtist.setBio(bio);
				existingArtist.setAddress(address);
				existingArtist.setContactNo(contactNo);

				existingUser.setName(name);

				artistRepository.save(existingArtist);
				userRepository.save(existingUser);

				logger.info("Your details are successfully updated");
				return ResponseEntity.ok("Your details are updated");
			} else {
				logger.warn("An error occur due to unable to find the details");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
			}
		} catch (Exception e) {
			logger.error("An error occurred while update your details");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to update artist details");
		}
	}
	
	/**This method is used to save the collection details based on artist
	 *
	 *@param title
	 *@param description
	 *@param active
	 *@param email
	 *@return String
	 */
	public ResponseEntity<String> saveCollectionsDetails(String title, String description, boolean active,
			                                            String email) {
		logger.info("Received request to save the collection details");
	    try {
		    User user = userRepository.findByEmail(email);
		    ArtistInfo artistInfo = artistRepository.findByUserUserId(user.getUserId());
		    
		    Collections collections=new Collections();
		    
		    collections.setTitle(title);
		    collections.setDescription(description);
		    collections.setActive(active);
		    collections.setArtistInfo(artistInfo);
		    
		    collectionRepository.save(collections);
		    
		    logger.info("Collection details are added in artist based");
		    return ResponseEntity.ok("Collection details are created");
	     } catch (Exception e) {
	    	 logger.error("An error occurred while save the collection details");
		    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to create collection");
	     }
	}
	
	/** This method is used to get the collection details based on artist email
	 *
	 *@param email
	 *@return collectionsDTOList
	 */
	public ResponseEntity<List<CollectionsDTO>> getCollectionDetailsByArtistEmail(String email) {
		logger.info("Received request to get collection details for artist");
		try {
	        List<CollectionsDTO> collectionsDTOList = collectionRepository.findCollectionDetailsByEmail(email);
	        if (collectionsDTOList != null && !collectionsDTOList.isEmpty()) {
	        	logger.info("Collection details retrieved successfully for artist");
	            return ResponseEntity.ok(collectionsDTOList);
			} else {
				logger.warn("No collection details found for artist");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
	    } catch (Exception e) {
	    	logger.error("An error occurred while getting collection details for artist");
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}

	/**This method used to retrieve the collection details based on collection id in artist
	 * email based
	 * 
	 * @param collectionId
	 * @return collectionsDTO
	 *
	 */
	public ResponseEntity<CollectionsDTO> getCollectionDetailsById(int collectionId) {
		logger.info("Received request to get collection details based on id for artist");
	    try {
	        Optional<Collections> optionalCollection = collectionRepository.findById(collectionId);
	        if (optionalCollection.isPresent()) {
	            Collections collection = optionalCollection.get();
	            CollectionsDTO collectionsDTO = new CollectionsDTO(
	                    collection.getCollectionId(),
	                    collection.getTitle(),
	                    collection.getDescription(),
	                    collection.isActive()
	            );
	            logger.info("Collection details retrieved successfully based on id for artist");
	            return ResponseEntity.ok(collectionsDTO);
	        } else {
	        	logger.warn("No collection details found for artist");
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        }
	    } catch (Exception e) {
	    	logger.error("An error occurred while getting collection details based on id for artist");
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}
	
	/** This method is used to update the collection details based on collection id
	 * 
	 * @param collectionId
	 * @param title
	 * @param description
	 * @param active
	 * @return String
	 *
	 */
	public ResponseEntity<String> updateCollectionDetailsById(int collectionId, String title, 
			          String description, boolean active) {
		logger.info("Received request to update the collection details based on id for artist");
		try {
			Collections existingCollections = collectionRepository.findById(collectionId).get();
			if (existingCollections != null) {
				
				existingCollections.setTitle(title);
				existingCollections.setDescription(description);
				existingCollections.setActive(active);
				
				collectionRepository.save(existingCollections);

				logger.info("Collection details are updated based on id for artist");
				return ResponseEntity.ok("Collection details are updated...!");
			} else {
				logger.warn("No collection details found for that collecrion id");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Given collection id is not available");
			}
		} catch (Exception e) {
			logger.error("An error occurred while updating collection details based on id for artist");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to update the details");
		}
	} 
	
	/**This method is used to enable/disable the collection based on artist email
	 * 
	 * @param collectionId
	 * @return String
	 *
	 */
	public ResponseEntity<String> enableAndDisableCollectionById(int collectionId) {
		logger.info("Received request to enable/disable collection for artist");
	    try {
	        Optional<Collections> optionalCollection = collectionRepository.findById(collectionId);
	        if (optionalCollection.isPresent()) {
	            Collections collection = optionalCollection.get();
	            collection.setActive(!collection.isActive());
	            collectionRepository.save(collection);
	            String statusMessage=collection.isActive() ? "Collection is active" : "Collection is inactive";
	            logger.info(statusMessage);
	            return ResponseEntity.ok(statusMessage);
	        } else {
	        	logger.warn("Collection not found for that id");
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Collection not found");
	        }
	    } catch (Exception e) {
	    	logger.error("An error occur while enable/disable the collection");
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to change!");
	    }
	}

	/**This method is used to get the collection titles based on artist email
	 * 
	 * @param email
	 * @return collectionTitleDTOList
	 *
	 */
	public ResponseEntity<List<CollectionTitleDTO>> getCollectionTitleListByEmail(String email) {
		logger.info("Received request to get the collection title for artist");
		try {
	        List<CollectionTitleDTO> collectionTitleDTOList = collectionRepository.findCollectionTitleListByEmail(email);
	        if (!collectionTitleDTOList.isEmpty()) {
	        	logger.info("Collection title list retrieved successfully for artist");
	            return ResponseEntity.ok(collectionTitleDTOList);
	        } else {
	            logger.warn("No collection titles found for artist");
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        }
	    } catch (Exception e) {
	    	logger.error("An error occurred while getting collection titles for artist");	
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}
	
	/** This method is used to save the artwork details based on artist email
	 * 
	 * @param artworkTitle
	 * @param description
	 * @param active
	 * @param artworkImage
	 * @param email
	 * @param title
	 * @return String
	 *
	 */
	public ResponseEntity<String> saveArtworkDetails(String artworkTitle, String description,
			     boolean active,MultipartFile artworkImage, String email, String title) {
		logger.info("Received request to save the artwork details for artist");
		try {
			Collections existingCollection=collectionRepository.findCollectionByArtistEmailAndTitle(email, title);
			if (existingCollection != null) {

				Artworks artwork = new Artworks();
				artwork.setArtworkTitle(artworkTitle);
				artwork.setDescription(description);
				artwork.setActive(active);
				artwork.setCreatedAt(new Date());
				artwork.setUpdatedAt(new Date());

				String artworkImageName = storeArtworkImages(artworkImage, null);

				artwork.setArtworkImage(artworkImageName);
				artwork.setCollections(existingCollection);

				artworkRepository.save(artwork);
				
				logger.info("Artwork details are successfully added");
				return ResponseEntity.ok("Artwork details are created!");
			} else {
				logger.warn("No collection details found for that artist");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Unable to find collection details!");
			}
		} catch (Exception e) {
			logger.error("An error occur while save the artwork details for artist");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to add!");
		}
	}
	
	/** This method is used to store the artwork images in artwork directory
	 * 
	 * @param artworkImage
	 * @param existingArtworkImage
	 * @return String
	 * @throws Exception
	 */
	public String storeArtworkImages(MultipartFile artworkImage, String existingArtworkImage) throws Exception {
		try {
			if (artworkImage != null && !artworkImage.isEmpty()) {
				String originalFilename = artworkImage.getOriginalFilename();
				String filePath = Paths.get(artworkDirectory, originalFilename).toString();
				Files.copy(artworkImage.getInputStream(), Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
				logger.info("Artwork image stored successfully in artwork directory");
				return originalFilename;
			} else {
				 logger.warn("No new artwork image provided. Using existing artwork image");
				return existingArtworkImage;
			}
		} catch (Exception e) {
			logger.error("An error occurred while storing artwork image");
			throw new Exception("Could not store the file. Please try again!", e);
		}
	}
	
	/** This method is used to retrieve the artworks based on artist email
	 * 
	 * @param email
	 * @return artworksDTOList
	 *
	 */
	public ResponseEntity<List<ArtworksDTO>> getArtworksByArtistEmail(String email) {
		logger.info("Received request to get artwork details for artist");
	    try {
	        List<ArtworksDTO> artworksDTOList = artworkRepository.findByArtworksByArtistEmail(email);
	        if (!artworksDTOList.isEmpty()) {
	            for (ArtworksDTO artworksDTO : artworksDTOList) {
	                String base64Artwork = getBase64ArtworkImage(artworksDTO.getArtworkImage());
	                artworksDTO.setArtworkImage(base64Artwork);
	            }
	            logger.info("Artwork details retrieved successfully for artist");
	            return ResponseEntity.ok(artworksDTOList);
	        } else {
	        	logger.warn("No artwork details found for artist");
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        }
	    } catch (Exception e) {
	    	logger.error("An error occurred while getting artwork details for artist");
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}
	
	/** This method is used to get the artwork details based on artwork id and artist email
	 * 
	 * @param artworkId
	 * @param email
	 * @return artworksDTO
	 *
	 */
	public ResponseEntity<ArtworksDTO> getArtworkByIdAndArtistEmail(int artworkId, String email) {
		logger.info("Received request to get artwork details based on id for artist");
		try {
			ArtworksDTO artworksDTO=artworkRepository.findArtworkByIdAndArtistEmail(artworkId, email);
			String artworkImageName=artworksDTO.getArtworkImage();
			String base64Image = getBase64ArtworkImage(artworkImageName);
		    artworksDTO.setArtworkImage(base64Image);
		    logger.info("Artwork details retrieved successfully based on id for artist");
			return ResponseEntity.ok(artworksDTO);
		} catch (Exception e) {
			logger.error("An error occurred while getting artwork details based on id for artist");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}	
	}
	
	/**This method is used to update the artwork details based on artworkId and artist email
	 * 
	 * @param artworkId
	 * @param artworkTitle
	 * @param description
	 * @param active
	 * @param artworkImage
	 * @param email
	 * @param title
	 * @return String
	 *
	 */
	public ResponseEntity<String> updateArtworkDetailsById(int artworkId, String artworkTitle, String description,
			     boolean active, MultipartFile artworkImage, String email, String title) {
		logger.info("Received request to update the artwork details for artist");
		try {
			Collections existingCollection=collectionRepository.findCollectionByArtistEmailAndTitle(email, title);
			Artworks existArtworks= artworkRepository.findById(artworkId).get();
			if (existArtworks!=null) {
				
				String artworkImageName=storeArtworkImages(artworkImage, existArtworks.getArtworkImage());
				
				existArtworks.setArtworkTitle(artworkTitle);
				existArtworks.setDescription(description);
				existArtworks.setArtworkImage(artworkImageName);
				
				existArtworks.setCollections(existingCollection);
				
				artworkRepository.save(existArtworks);
				logger.info("Artwork details are successfully updated on that id for artist");
				return ResponseEntity.ok("Artwork details are updated..!");
			}else {
				logger.warn("No artwork details found for artist");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Unable to find artwork!...");
			}		
		} catch (Exception e) {
			logger.error("An error occurred while updating the artwork details for artist");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to update artwork details!...");
		}
	}
	
	/** This method is used to enable/disable the artwork based on artist email for public view
	 * 
	 * @param artworkId
	 * @return String
	 *
	 */
	public ResponseEntity<String> enableAndDisableArtworkById(int artworkId) {
		logger.info("Received request to enable/disable the artwork for artist");
		try {
			Optional<Artworks> existingArtwork = artworkRepository.findById(artworkId);
			if (existingArtwork.isPresent()) {
				Artworks artworks=existingArtwork.get();
				artworks.setActive(!artworks.isActive());
				artworkRepository.save(artworks);
				String statusMessage=artworks.isActive() ? "Artwork is active" : "Artwork is inactive";
				logger.info(statusMessage);
				return ResponseEntity.ok(statusMessage);
			}else {
				logger.warn("No artwork details found for artist");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Artwork not found");
			}	
		} catch (Exception e) {
			logger.error("An error occurred while enable/disable the artwork for artist");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to change!");
		}
	}

	/**This method is used to get the all artworks without current artist artwork
	 * 
	 * @param email
	 * @return artistArtworkDTOList
	 *
	 */
	public ResponseEntity<List<ArtistArtworkDTO>> getAllArtworks(String email) {
		logger.info("Received request to retrieve artworks without current artist artwork");
		try {
			List<ArtistArtworkDTO> artistArtworkDTOList = artworkRepository.findAllArtworksWithoutCurrentArtist(email);
			artistArtworkDTOList.forEach(artistArtworkDTO -> {
				String base64Artwork = getBase64ArtworkImage(artistArtworkDTO.getArtworkImage());
				artistArtworkDTO.setArtworkImage(base64Artwork);
			});
			logger.info("Artwork details retrieved successfully without current artist");
			return ResponseEntity.ok(artistArtworkDTOList);
		} catch (Exception e) {
			logger.error("An error occurred while getting allartworks for artist");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
		
	}
	
	/**This method is used to processing the artwork image in based 64 process from artwork
	 * directory
	 * @param artworkImageName
	 * @return String
	 */
	private String getBase64ArtworkImage(String artworkImageName) {
		logger.info("Received request to base 64 encoding for artwork image");
	    if (artworkImageName != null && !artworkImageName.isEmpty()) {
	        String thumbnailPath = artworkDirectory + artworkImageName;
	        try {
	            FileInputStream fileInputStream = new FileInputStream(new File(thumbnailPath));
	            byte[] image = IOUtils.toByteArray(fileInputStream);
	            logger.info("Base64 encoding created successfully for artwork image");
	            return Base64.getEncoder().encodeToString(image);
	        } catch (Exception e) {
	        	logger.error("An error occurred while creating Base64 encoding for artwork image");
	            System.out.println(e);
	        }
	    }else {
	        logger.warn("Artwork image name is null or empty. Unable to create Base64 encoding.");
	    }
		return null;
	}   
		
}

