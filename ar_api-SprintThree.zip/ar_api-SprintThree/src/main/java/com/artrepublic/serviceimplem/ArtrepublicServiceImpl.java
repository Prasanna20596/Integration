package com.artrepublic.serviceimplem;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.artrepublic.dto.ArtistArtworkDTO;
import com.artrepublic.dto.ArtistProfileDTO;
import com.artrepublic.dto.ArtistUserDTO;
import com.artrepublic.dto.CollectionArtworkImageDTO;
import com.artrepublic.entity.ArtistInfo;
import com.artrepublic.entity.Roles;
import com.artrepublic.entity.User;
import com.artrepublic.repository.ArtistRepository;
import com.artrepublic.repository.ArtworkRepository;
import com.artrepublic.repository.CollectionRepository;
import com.artrepublic.repository.UserRepository;
import com.artrepublic.service.ArtrepublicService;
	
/**This class provides the implementation of the ArtrepublicService interface.
 * It contains methods to retrieve artist details, profile information,collection details
 *  and artwork details.
 * Additionally, it handles the processing of profile pictures and artwork images for presentation.
 * 
 */
@Service
public class ArtrepublicServiceImpl implements ArtrepublicService{	

	private static final Logger logger = LoggerFactory.getLogger(ArtrepublicServiceImpl.class);
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ArtistRepository artistRepository;
	
	@Autowired
	private CollectionRepository collectionRepository;
	
	@Autowired
	private ArtworkRepository artworkRepository;

	@Value("${file.upload-artistDirectory}")
	private String artistDirectory;
	
	@Value("${file.upload-artworkDirectory}")
	private String artworkDirectory;
	
	/**This method is used to retrieve the all artistdetails for admin and also display the
	 * remaining artist details without current artist details
	 * 
	 * @param email
	 * @return artistProfileDTOs
	 */
	public ResponseEntity<List<ArtistProfileDTO>> getArtistDetailsWithoutCurrentArtist(String email){
		logger.info("Received request to get all artist details for admin & artist	");
		try {
			User user=userRepository.findByEmail(email);
			Roles userRole=user.getRoles();	
			List<ArtistInfo> artistInfos;
			if (userRole!=null && userRole.getRoleName().equals("ROLE_ADMIN")){
				artistInfos=artistRepository.findAll();
			}else {
				artistInfos=artistRepository.findAllByUserEmailIsNot(email);
			}
			List<ArtistProfileDTO> artistProfileDTOs = new ArrayList<>();
			for (ArtistInfo artistInfo : artistInfos) {
				if (artistInfo.getUser().isActive()) {
					 ArtistProfileDTO artistProfileDTO = new ArtistProfileDTO();

					 artistProfileDTO.setArtistId(artistInfo.getArtistId());
		             artistProfileDTO.setProfilePicture(artistInfo.getProfilePicture());
		             artistProfileDTO.setName(artistInfo.getUser().getName());

		             int collectionCount = collectionRepository.findCollectionCountByArtistEmail(artistInfo.getUser().getEmail());
		             artistProfileDTO.setCollectionCount(collectionCount);
		            
		             int artworkCount = artworkRepository.countArtworksByArtworkIdAndArtistEmail(artistInfo.getUser().getEmail());
		             artistProfileDTO.setArtworkCount(artworkCount);
		            
		             processProfilePicture(artistProfileDTO);   
		            
		             artistProfileDTOs.add(artistProfileDTO);
			    }
			}
			logger.info("Artist details retrieved successfully");
			return ResponseEntity.ok(artistProfileDTOs);
		} catch (Exception e) {
			logger.error("An error occurred while getting artist details");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
	}
	
	/** This method is used to get the artist profile details based on name
	 * 
	 * @param name
	 * @return artistUserDTO
	 */
	public ResponseEntity<ArtistUserDTO> getArtistProfileDetailsByName(String name){
		logger.info("Received request to get profile details based on artist name");
		try {
			ArtistUserDTO artistUserDTO=artistRepository.findArtistDetailsByName(name);
			if (artistUserDTO!=null) {
				String profilePictureName=artistUserDTO.getProfilePicture();
				logger.info("Received request to get collection details for artist");
				if (profilePictureName!=null && !profilePictureName.isEmpty()) {
					String profilePicturePath=artistDirectory+profilePictureName;
					try {
						FileInputStream fileInputStream=new FileInputStream(new File(profilePicturePath));
						byte[] image=IOUtils.toByteArray(fileInputStream);
						String base64ProfileImage=Base64.getEncoder().encodeToString(image);
						artistUserDTO.setProfilePicture(base64ProfileImage);
						logger.info("Base64 encoding created successfully for profile picture");
					} catch (Exception e) {
						logger.error("An error occurred while converting Base64 encoding for profile picture");
					}
				} else {
					 logger.warn("No new profile picture provided. Using existing profile picture");
					artistUserDTO.setProfilePicture(null);
				}
				logger.info("Artist profile details retrieved successfully based on artist name");
				return ResponseEntity.ok(artistUserDTO);	
			} else {
				logger.warn("Artist profile details not found for artist name	");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
		} catch (Exception e) {
			logger.error("An error occurred while getting artist profile details based on artist name");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}
	
	/** This method is used to processing the artist profile picture as based 64 process 
	 * based artist from artistDirectory.
	 * 
	 * @param artistProfileDTO
	 */
	private void processProfilePicture(ArtistProfileDTO artistProfileDTO) {
		logger.info("Received request to base 64 encoding for artist profile picture");
		String profilePictureName = artistProfileDTO.getProfilePicture();
		if (profilePictureName != null && !profilePictureName.isEmpty()) {
			String profilePicturePath = artistDirectory + profilePictureName;
			try {
				FileInputStream fileInputStream = new FileInputStream(new File(profilePicturePath));
				byte[] image = IOUtils.toByteArray(fileInputStream);
				String base64ProfileImage = Base64.getEncoder().encodeToString(image);
				artistProfileDTO.setProfilePicture(base64ProfileImage);
				logger.info("Base64 encoding created successfully for artist profile picture");
			} catch (Exception e) {
				logger.error("An error occurred while creating Base64 encoding for artist profile picture");
			}
		} else {
			logger.warn("No new profile picture is provided. Using existing artist profile picture");
			artistProfileDTO.setProfilePicture(null);
		}
	}
	
	/** This method is used to retreive the collection details and count with latest artwork 
	 * image based on artist name
	 * 
	 * @param name
	 * @return collectionArtworkImageDTOList
	 */
	public ResponseEntity<List<CollectionArtworkImageDTO>> getCollectionDetailsAndCountByArtistName(String name) {
		logger.info("Received request to get collection details based on artist name");
		try {
			List<CollectionArtworkImageDTO> collectionArtworkImageDTOList = collectionRepository
					.findByCollectionByArtistName(name);
			if (collectionArtworkImageDTOList != null && !collectionArtworkImageDTOList.isEmpty()) {
				int collectionCount = collectionRepository.findCollectionCountByArtistName(name);
				for (CollectionArtworkImageDTO collectionArtworkImageDTO : collectionArtworkImageDTOList) {
					String base64Artwork = getBase64ArtworkImage(collectionArtworkImageDTO.getArtworkImage());
					collectionArtworkImageDTO.setArtworkImage(base64Artwork);
					collectionArtworkImageDTO.setCollectionCount(collectionCount);
				}
				logger.info("Collection details retrieved successfully based on artist name");
				return ResponseEntity.ok(collectionArtworkImageDTOList);
			} else {
				logger.warn("No collection details found based on artist name");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
		} catch (Exception e) {
			logger.error("An error occurred while getting collection details based on artist name");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

	/** This method is used to get the artwork details with count and image based on artist name
	 * 
	 *@param name
	 *@return artistArtworkDTOs
	 */
	public ResponseEntity<List<ArtistArtworkDTO>> getArtworkDetailsAndCountByArtistName(String name) {
		logger.info("Received request to get artwork details based on artist name");
		try {
	        List<ArtistArtworkDTO> artistArtworkDTOs = artworkRepository.findByArtworksByArtistName(name);
	        if (artistArtworkDTOs != null && !artistArtworkDTOs.isEmpty()) {
	            int artworkCount = artworkRepository.countArtworksByArtworkIdAndArtistName(name);
	            for (ArtistArtworkDTO artistArtworkDTO : artistArtworkDTOs) {
	                String base64Artwork = getBase64ArtworkImage(artistArtworkDTO.getArtworkImage());
	                artistArtworkDTO.setArtworkImage(base64Artwork);
	                artistArtworkDTO.setArtworkCount(artworkCount);
	            }
	            logger.info("Artwork details retrieved successfully based on artist name");
	            return ResponseEntity.ok(artistArtworkDTOs);
	        } else {
	        	logger.warn("No artwork details found based on artist name");
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        }
	    } catch (Exception e) {
	    	logger.error("An error occurred while getting artwork details based on artist name");
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}
	
	/** This method is used to processing the artwork image in based 64 process from artwork
	 * directory
	 * 
	 * @param artworkImageName
	 * @return String
	 */
	private String getBase64ArtworkImage(String artworkImageName) {
		logger.info("Received request to base 64 encoding for artwork image");
	    if (artworkImageName != null && !artworkImageName.isEmpty()) {
	        String thumbnailPath = artworkDirectory + artworkImageName;
	        try {
	            FileInputStream fileInputStream = new FileInputStream(new File(thumbnailPath));
	            byte[] image = IOUtils.toByteArray(fileInputStream);
	            logger.info("Base64 encoding created successfully for artwork image");
	            return Base64.getEncoder().encodeToString(image);
	        } catch (Exception e) {
	        	logger.error("An error occurred while creating Base64 encoding for artwork image");
	        }
	    }else {
	    	logger.warn("Artwork image name is null or empty. Unable to create Base64 encoding.");
		}
		return null;
	}    

}
