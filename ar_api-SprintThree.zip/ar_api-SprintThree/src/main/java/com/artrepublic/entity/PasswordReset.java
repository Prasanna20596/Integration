package com.artrepublic.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class PasswordReset {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int resetId;
	private String email;
	private String token;
	private int otp;
	private LocalDateTime resetDate;
	
	@OneToOne
	@JoinColumn(name = "userId")
	private User user;

	public int getResetId() {
		return resetId;
	}

	public void setResetId(int resetId) {
		this.resetId = resetId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public LocalDateTime getResetDate() {
		return resetDate;
	}

	public void setResetDate(LocalDateTime resetDate) {
		this.resetDate = resetDate;
	}
	
}
