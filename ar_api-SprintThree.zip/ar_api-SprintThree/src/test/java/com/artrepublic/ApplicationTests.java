package com.artrepublic;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTests {

}
